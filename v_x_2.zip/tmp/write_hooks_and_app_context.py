import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

use_scoped_data_ts = """import { useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { useFilterStore } from '../context/FilterStore';
import {
  ActionType,
  canAccessEntity,
  canAccessUniverse,
  canPerformAction,
  filterComments,
  filterControls,
  filterEngagements,
  filterEntities,
  filterIssues,
  filterObservations,
  filterUniverses,
  filterWorkpapers,
} from '../lib/access';
import {
  AuditCapItem,
  AuditControl,
  AuditEngagement,
  AuditEntity,
  AuditIssue,
  AuditObservation,
  AuditUniverse,
  ReviewComment,
  WorkingPaper,
} from '../types';

export function useScopedData() {
  const {
    currentUser,
    rawUniverses,
    rawEntities,
    rawEngagements,
    rawControls,
    rawWorkpapers,
    rawObservations,
    rawIssues,
    rawComments,
    rawCapItems,
    selectedUniverseId,
    setSelectedUniverseId,
    ledger,
    ledgerAsOf,
  } = useApp();

  const filter = useFilterStore();

  // 1. Scoped Universes
  const scopedUniverses = useMemo(() => {
    return filterUniverses(rawUniverses, currentUser);
  }, [rawUniverses, currentUser]);

  // Universe assignment rule: if tagged to exactly 1 universe, user sees only that universe and no switcher
  const hasMultipleUniverses = scopedUniverses.length > 1;
  const effectiveUniverseId = useMemo(() => {
    if (scopedUniverses.length === 1) return scopedUniverses[0].id;
    if (selectedUniverseId && scopedUniverses.some((u) => u.id === selectedUniverseId)) {
      return selectedUniverseId;
    }
    return scopedUniverses[0]?.id || null;
  }, [scopedUniverses, selectedUniverseId]);

  // 2. Scoped Entities (within effective universe if selected)
  const scopedEntities = useMemo(() => {
    return filterEntities(rawEntities, currentUser, effectiveUniverseId || undefined);
  }, [rawEntities, currentUser, effectiveUniverseId]);

  const allowedEntityIds = useMemo(() => {
    return new Set(scopedEntities.map((e) => e.id));
  }, [scopedEntities]);

  // 3. Scoped Engagements
  const scopedEngagements = useMemo(() => {
    return filterEngagements(rawEngagements, currentUser, allowedEntityIds);
  }, [rawEngagements, currentUser, allowedEntityIds]);

  // 4. Scoped Controls
  const scopedControls = useMemo(() => {
    return filterControls(rawControls, currentUser, allowedEntityIds);
  }, [rawControls, currentUser, allowedEntityIds]);

  // 5. Scoped Workpapers
  const scopedWorkpapers = useMemo(() => {
    return filterWorkpapers(rawWorkpapers, currentUser, allowedEntityIds);
  }, [rawWorkpapers, currentUser, allowedEntityIds]);

  const allowedWorkpaperIds = useMemo(() => {
    return new Set(scopedWorkpapers.map((w) => w.id));
  }, [scopedWorkpapers]);

  // 6. Scoped Observations
  const scopedObservations = useMemo(() => {
    return filterObservations(rawObservations, currentUser, allowedEntityIds);
  }, [rawObservations, currentUser, allowedEntityIds]);

  // 7. Scoped Issues
  const scopedIssues = useMemo(() => {
    return filterIssues(rawIssues, currentUser, allowedEntityIds);
  }, [rawIssues, currentUser, allowedEntityIds]);

  // 8. Scoped Comments
  const scopedComments = useMemo(() => {
    return filterComments(rawComments, currentUser, allowedWorkpaperIds);
  }, [rawComments, currentUser, allowedWorkpaperIds]);

  // 9. Scoped CAP Items (§ 3.4)
  const scopedCapItems = useMemo(() => {
    return rawCapItems.filter((cap) => {
      if (currentUser.role === 'admin' || currentUser.role === 'cia') return true;
      return allowedEntityIds.has(cap.entityId);
    });
  }, [rawCapItems, currentUser.role, allowedEntityIds]);

  // --- Cross-Filtered Data (applying reactive filters on top of scoped data) ---
  const filteredEngagements = useMemo(() => {
    return scopedEngagements.filter((eng) => {
      if (filter.status && eng.status !== filter.status && eng.stage !== filter.status) return false;
      if (filter.ownerId && eng.leadAuditorId !== filter.ownerId && eng.reviewerId !== filter.ownerId) return false;
      if (filter.department) {
        const entity = scopedEntities.find((e) => e.id === eng.entityId);
        if (entity && entity.department.toLowerCase() !== filter.department.toLowerCase()) {
          return false;
        }
      }
      if (filter.searchQuery.trim()) {
        const q = filter.searchQuery.toLowerCase();
        const matchesTitle = eng.title.toLowerCase().includes(q);
        const matchesId = eng.id.toLowerCase().includes(q);
        if (!matchesTitle && !matchesId) return false;
      }
      return true;
    });
  }, [scopedEngagements, scopedEntities, filter.status, filter.ownerId, filter.department, filter.searchQuery]);

  const filteredIssues = useMemo(() => {
    return scopedIssues.filter((iss) => {
      if (filter.department && iss.department.toLowerCase() !== filter.department.toLowerCase()) return false;
      if (filter.severity && iss.severity !== filter.severity) return false;
      if (filter.status && iss.status !== filter.status) return false;
      if (filter.ownerId && iss.ownerId !== filter.ownerId) return false;
      if (filter.searchQuery.trim()) {
        const q = filter.searchQuery.toLowerCase();
        if (!iss.title.toLowerCase().includes(q) && !iss.description.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [scopedIssues, filter.department, filter.severity, filter.status, filter.ownerId, filter.searchQuery]);

  const filteredWorkpapers = useMemo(() => {
    return scopedWorkpapers.filter((wp) => {
      if (filter.status && wp.status !== filter.status) return false;
      if (filter.ownerId && wp.preparerId !== filter.ownerId && wp.reviewerId !== filter.ownerId) return false;
      if (filter.searchQuery.trim()) {
        const q = filter.searchQuery.toLowerCase();
        if (!wp.title.toLowerCase().includes(q) && !wp.refCode.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [scopedWorkpapers, filter.status, filter.ownerId, filter.searchQuery]);

  const filteredCapItems = useMemo(() => {
    return scopedCapItems.filter((cap) => {
      if (filter.department && cap.department.toLowerCase() !== filter.department.toLowerCase()) return false;
      if (filter.severity && cap.severity !== filter.severity) return false;
      if (filter.status && cap.status !== filter.status) return false;
      if (filter.searchQuery.trim()) {
        const q = filter.searchQuery.toLowerCase();
        if (
          !cap.title.toLowerCase().includes(q) &&
          !cap.action.toLowerCase().includes(q) &&
          !cap.id.toLowerCase().includes(q) &&
          !cap.owner.toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      return true;
    });
  }, [scopedCapItems, filter.department, filter.severity, filter.status, filter.searchQuery]);

  // Derived Statistics (strictly calculated on scoped data)
  const stats = useMemo(() => {
    const totalEntities = scopedEntities.length;
    const highRiskEntities = scopedEntities.filter((e) => e.inherentRisk === 'high' || e.residualRisk === 'high').length;
    const inProgressEngagements = scopedEngagements.filter((e) => e.status === 'in_progress').length;
    const completedEngagements = scopedEngagements.filter((e) => e.status === 'signed_off').length;
    const openObservations = scopedObservations.filter((o) => o.status === 'open' || o.status === 'draft').length;
    const openIssues = scopedIssues.filter((i) => i.status !== 'closed' && i.status !== 'remediated').length;
    const criticalIssues = scopedIssues.filter((i) => i.severity === 'critical' && i.status !== 'closed').length;
    const sealedWorkpapers = scopedWorkpapers.filter((w) => w.sealed).length;

    // CAP statistics (strictly scoped)
    const totalCapCount = scopedCapItems.length;
    const openCapCount = scopedCapItems.filter((c) => c.status !== 'Closed').length;
    const overdueCapCount = scopedCapItems.filter(
      (c) => c.status === 'Overdue' || (c.status !== 'Closed' && c.dueDate < '2026-09-30')
    ).length;

    // Greeting subtitle based strictly on scoped items
    const greetingSubtitle = `${inProgressEngagements} engagement${inProgressEngagements === 1 ? '' : 's'} in progress • ${openIssues} open finding${openIssues === 1 ? '' : 's'} • ${criticalIssues} critical`;

    // Department breakdown for Sunburst
    const deptMap: Record<string, { total: number; issues: AuditIssue[] }> = {};
    scopedEntities.forEach((ent) => {
      if (!deptMap[ent.department]) {
        deptMap[ent.department] = { total: 0, issues: [] };
      }
      deptMap[ent.department].total += 1;
    });
    scopedIssues.forEach((iss) => {
      if (!deptMap[iss.department]) {
        deptMap[iss.department] = { total: 0, issues: [] };
      }
      deptMap[iss.department].issues.push(iss);
    });

    // CAP Department Map for D3 Radial Tracker (§ 3.4)
    const capDeptMap: Record<
      string,
      {
        department: string;
        total: number;
        overdueCount: number;
        caps: AuditCapItem[];
        severityCounts: Record<string, number>;
      }
    > = {};

    scopedCapItems.forEach((cap) => {
      if (!capDeptMap[cap.department]) {
        capDeptMap[cap.department] = {
          department: cap.department,
          total: 0,
          overdueCount: 0,
          caps: [],
          severityCounts: { critical: 0, high: 0, medium: 0, low: 0 },
        };
      }
      const d = capDeptMap[cap.department];
      d.total += 1;
      d.caps.push(cap);
      if (cap.status === 'Overdue' || (cap.status !== 'Closed' && cap.dueDate < '2026-09-30')) {
        d.overdueCount += 1;
      }
      d.severityCounts[cap.severity] = (d.severityCounts[cap.severity] || 0) + 1;
    });

    return {
      totalEntities,
      highRiskEntities,
      inProgressEngagements,
      completedEngagements,
      openObservations,
      openIssues,
      criticalIssues,
      sealedWorkpapers,
      totalCapCount,
      openCapCount,
      overdueCapCount,
      greetingSubtitle,
      deptMap,
      capDeptMap,
    };
  }, [scopedEntities, scopedEngagements, scopedObservations, scopedIssues, scopedWorkpapers, scopedCapItems]);

  // Scoped Ledger: only entries belonging to accessible entities
  const scopedLedger = useMemo(() => {
    const accessible = ledger.filter((entry) => {
      if (currentUser.role === 'admin' || currentUser.role === 'cia') return true;
      return allowedEntityIds.has(entry.entityId);
    });

    if (ledgerAsOf !== null) {
      return accessible.filter((entry) => entry.seq <= ledgerAsOf);
    }
    return accessible;
  }, [ledger, allowedEntityIds, currentUser.role, ledgerAsOf]);

  // Deep-link safe resolver: resolves an ID or returns null if not accessible
  const resolveEntity = (id: string): AuditEntity | null => {
    return scopedEntities.find((e) => e.id === id) || null;
  };

  const resolveEngagement = (id: string): AuditEngagement | null => {
    return scopedEngagements.find((e) => e.id === id) || null;
  };

  const resolveWorkpaper = (id: string): WorkingPaper | null => {
    return scopedWorkpapers.find((w) => w.id === id) || null;
  };

  const resolveObservation = (id: string): AuditObservation | null => {
    return scopedObservations.find((o) => o.id === id) || null;
  };

  const resolveIssue = (id: string): AuditIssue | null => {
    return scopedIssues.find((i) => i.id === id) || null;
  };

  const resolveCap = (id: string): AuditCapItem | null => {
    return scopedCapItems.find((c) => c.id === id) || null;
  };

  // Action gate helper bound to current user
  const can = (
    action: ActionType,
    context?: {
      preparerId?: string;
      leadAuditorId?: string;
      isLocked?: boolean;
      reopenJustification?: string;
    }
  ) => {
    return canPerformAction(currentUser, action, context);
  };

  return {
    currentUser,
    scopedUniverses,
    hasMultipleUniverses,
    selectedUniverseId: effectiveUniverseId,
    setSelectedUniverseId,
    scopedEntities,
    scopedEngagements,
    scopedControls,
    scopedWorkpapers,
    scopedObservations,
    scopedIssues,
    scopedComments,
    scopedCapItems,
    scopedLedger,
    // Filtered
    filteredEngagements,
    filteredIssues,
    filteredWorkpapers,
    filteredCapItems,
    // Stats & counts
    stats,
    // Deep-link resolvers
    resolveEntity,
    resolveEngagement,
    resolveWorkpaper,
    resolveObservation,
    resolveIssue,
    resolveCap,
    // Role action gate
    can,
  };
}
"""
write_both('src/hooks/useScopedData.ts', use_scoped_data_ts)

app_context_ts = """import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  initialCapItems,
  initialComments,
  initialControls,
  initialEngagements,
  initialEntities,
  initialGlassBoxTokens,
  initialIssues,
  initialLedger,
  initialObservations,
  initialUniverses,
  initialUsers,
  initialWorkpapers,
} from '../data/initialData';
import { canPerformAction } from '../lib/access';
import { appendLedgerEntry, computePayloadHash, verifyChain } from '../lib/ledger';
import {
  AuditCapItem,
  AuditControl,
  AuditEngagement,
  AuditEntity,
  AuditIssue,
  AuditObservation,
  AuditUniverse,
  CapStatus,
  GlassBoxToken,
  LedgerEntry,
  RetestStatus,
  ReviewComment,
  User,
  WorkingPaper,
} from '../types';

export type InspectorType =
  | 'observation'
  | 'comment'
  | 'sira'
  | 'people'
  | 'audit_file'
  | 'workbench'
  | 'red_thread'
  | 'glassbox_share'
  | 'account_settings'
  | 'comment_history'
  | 'cap_inspector';

export interface InspectorState {
  type: InspectorType | null;
  data?: any;
}

interface AppContextType {
  // Current authenticated user (and scope)
  currentUser: User;
  setCurrentUser: (user: User) => void;
  availableUsers: User[];

  // Raw State (internal to context and useScopedData)
  rawUniverses: AuditUniverse[];
  rawEntities: AuditEntity[];
  rawEngagements: AuditEngagement[];
  rawControls: AuditControl[];
  rawWorkpapers: WorkingPaper[];
  rawObservations: AuditObservation[];
  rawIssues: AuditIssue[];
  rawComments: ReviewComment[];
  rawCapItems: AuditCapItem[];
  ledger: LedgerEntry[];
  glassBoxTokens: GlassBoxToken[];

  // Selections & Navigation
  selectedUniverseId: string | null;
  setSelectedUniverseId: (id: string | null) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedEngagementId: string | null;
  setSelectedEngagementId: (id: string | null) => void;
  selectedWorkpaperId: string | null;
  setSelectedWorkpaperId: (id: string | null) => void;
  selectedObservationId: string | null;
  setSelectedObservationId: (id: string | null) => void;

  // Inspector Panel (Sliding right sheet)
  inspector: InspectorState;
  openInspector: (type: InspectorType, data?: any) => void;
  closeInspector: () => void;

  // 4D Ledger Scrub Bar (Task 6 differentiator)
  ledgerAsOf: number | null; // null means live; number is max seq
  setLedgerAsOf: (seq: number | null) => void;

  // 1-stage vs 2-stage Org Toggle (Task 6 differentiator)
  isTwoStageOrg: boolean;
  setIsTwoStageOrg: (twoStage: boolean) => void;

  // Actions
  appendLedger: (params: Parameters<typeof appendLedgerEntry>[1]) => Promise<LedgerEntry>;
  signOffEngagement: (engagementId: string) => Promise<void>;
  reopenEngagement: (engagementId: string, justification: string) => Promise<void>;
  finalizeTest: (workpaperId: string) => Promise<void>;
  signOffWorkpaper: (workpaperId: string) => Promise<void>;
  reopenWorkpaper: (workpaperId: string, justification: string) => Promise<void>;
  addObservation: (
    obs: Omit<AuditObservation, 'id' | 'createdAt' | 'raisedBy'>
  ) => Promise<AuditObservation>;
  addReviewComment: (workpaperId: string, text: string) => Promise<ReviewComment>;
  attachEvidenceToWorkpaper: (
    workpaperId: string,
    file: { name: string; sizeBytes: number; sha256: string },
    actorName: string
  ) => Promise<void>;
  updateCapStatus: (capId: string, status: CapStatus, retestStatus?: RetestStatus) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User>(initialUsers[0]); // default to CIA
  const [availableUsers] = useState<User[]>(initialUsers);

  const [rawUniverses, setRawUniverses] = useState<AuditUniverse[]>(initialUniverses);
  const [rawEntities, setRawEntities] = useState<AuditEntity[]>(initialEntities);
  const [rawEngagements, setRawEngagements] = useState<AuditEngagement[]>(initialEngagements);
  const [rawControls, setRawControls] = useState<AuditControl[]>(initialControls);
  const [rawWorkpapers, setRawWorkpapers] = useState<WorkingPaper[]>(initialWorkpapers);
  const [rawObservations, setRawObservations] = useState<AuditObservation[]>(initialObservations);
  const [rawIssues, setRawIssues] = useState<AuditIssue[]>(initialIssues);
  const [rawComments, setRawComments] = useState<ReviewComment[]>(initialComments);
  const [rawCapItems, setRawCapItems] = useState<AuditCapItem[]>(initialCapItems);
  const [ledger, setLedger] = useState<LedgerEntry[]>(initialLedger);
  const [glassBoxTokens, setGlassBoxTokens] = useState<GlassBoxToken[]>(initialGlassBoxTokens);

  const [selectedUniverseId, setSelectedUniverseId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedEngagementId, setSelectedEngagementId] = useState<string | null>(null);
  const [selectedWorkpaperId, setSelectedWorkpaperId] = useState<string | null>(null);
  const [selectedObservationId, setSelectedObservationId] = useState<string | null>(null);

  const [inspector, setInspector] = useState<InspectorState>({ type: null });
  const [ledgerAsOf, setLedgerAsOf] = useState<number | null>(null);
  const [isTwoStageOrg, setIsTwoStageOrg] = useState<boolean>(true);

  // Auto-select universe if user is tagged to exactly one
  useEffect(() => {
    if (currentUser.universeIds && currentUser.universeIds.length === 1 && currentUser.universeIds[0] !== '*') {
      setSelectedUniverseId(currentUser.universeIds[0]);
    }
  }, [currentUser]);

  const openInspector = (type: InspectorType, data?: any) => {
    setInspector({ type, data });
  };

  const closeInspector = () => {
    setInspector({ type: null });
  };

  const appendLedger = async (params: Parameters<typeof appendLedgerEntry>[1]) => {
    const newEntry = await appendLedgerEntry(ledger, params);
    setLedger((prev) => [...prev, newEntry]);
    return newEntry;
  };

  const signOffEngagement = async (engagementId: string) => {
    const eng = rawEngagements.find((e) => e.id === engagementId);
    if (!eng) return;

    const gate = canPerformAction(currentUser, 'sign_off', {
      leadAuditorId: eng.leadAuditorId,
      preparerId: eng.leadAuditorId,
      isLocked: eng.isLocked,
    });
    if (!gate.allowed) {
      alert(gate.reason || 'Action not permitted');
      return;
    }

    const payloadHash = await computePayloadHash({ engagementId, stage: 'signed_off', timestamp: new Date().toISOString() });
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'audit_sign_off',
      entityId: eng.entityId,
      recordId: eng.id,
      recordType: 'engagement',
      payloadSummary: `Audit engagement "${eng.title}" signed-off and sealed by ${currentUser.name}`,
      payloadHash,
    });

    setRawEngagements((prev) =>
      prev.map((item) =>
        item.id === engagementId
          ? {
              ...item,
              status: 'signed_off',
              stage: 'closed',
              completionPercent: 100,
              signedOffAt: new Date().toISOString(),
              signedOffBy: currentUser.name,
              signedHash: payloadHash,
              isLocked: true,
            }
          : item
      )
    );
  };

  const reopenEngagement = async (engagementId: string, justification: string) => {
    const eng = rawEngagements.find((e) => e.id === engagementId);
    if (!eng) return;

    const gate = canPerformAction(currentUser, 'reopen', {
      reopenJustification: justification,
    });
    if (!gate.allowed) {
      alert(gate.reason || 'Action not permitted');
      return;
    }

    const payloadHash = await computePayloadHash({ engagementId, justification, timestamp: new Date().toISOString() });
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'reopen',
      entityId: eng.entityId,
      recordId: eng.id,
      recordType: 'engagement',
      payloadSummary: `Engagement "${eng.title}" reopened: ${justification}`,
      payloadHash,
      justification,
    });

    setRawEngagements((prev) =>
      prev.map((item) =>
        item.id === engagementId
          ? {
              ...item,
              status: 'reopened',
              stage: 'review',
              isLocked: false,
              reopenJustification: justification,
            }
          : item
      )
    );
  };

  const finalizeTest = async (workpaperId: string) => {
    const wp = rawWorkpapers.find((w) => w.id === workpaperId);
    if (!wp) return;

    const gate = canPerformAction(currentUser, 'finalize_test', { isLocked: wp.sealed });
    if (!gate.allowed) {
      alert(gate.reason || 'Action not permitted');
      return;
    }

    const payloadHash = await computePayloadHash(wp);
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'test_finalize',
      entityId: wp.entityId,
      recordId: wp.id,
      recordType: 'workpaper',
      payloadSummary: `Testing finalized for workpaper "${wp.refCode}" (${wp.sampleCount} samples tested)`,
      payloadHash,
    });

    setRawWorkpapers((prev) =>
      prev.map((w) =>
        w.id === workpaperId
          ? {
              ...w,
              status: 'completed',
              preparedDate: new Date().toISOString().split('T')[0],
            }
          : w
      )
    );
  };

  const signOffWorkpaper = async (workpaperId: string) => {
    const wp = rawWorkpapers.find((w) => w.id === workpaperId);
    if (!wp) return;

    const gate = canPerformAction(currentUser, 'sign_off', {
      preparerId: wp.preparerId,
      isLocked: wp.sealed,
    });
    if (!gate.allowed) {
      alert(gate.reason || 'Action not permitted');
      return;
    }

    const payloadHash = await computePayloadHash(wp);
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'reviewer_sign_off',
      entityId: wp.entityId,
      recordId: wp.id,
      recordType: 'workpaper',
      payloadSummary: `Working paper "${wp.refCode}" sealed and signed-off by Reviewer ${currentUser.name}`,
      payloadHash,
    });

    setRawWorkpapers((prev) =>
      prev.map((w) =>
        w.id === workpaperId
          ? {
              ...w,
              status: 'signed_off',
              reviewedDate: new Date().toISOString().split('T')[0],
              sealed: true,
              sealedHash: payloadHash,
            }
          : w
      )
    );
  };

  const reopenWorkpaper = async (workpaperId: string, justification: string) => {
    const wp = rawWorkpapers.find((w) => w.id === workpaperId);
    if (!wp) return;

    const gate = canPerformAction(currentUser, 'reopen', {
      reopenJustification: justification,
    });
    if (!gate.allowed) {
      alert(gate.reason || 'Action not permitted');
      return;
    }

    const payloadHash = await computePayloadHash({ workpaperId, justification, timestamp: new Date().toISOString() });
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'reopen',
      entityId: wp.entityId,
      recordId: wp.id,
      recordType: 'workpaper',
      payloadSummary: `Workpaper "${wp.refCode}" unsealed and reopened: ${justification}`,
      payloadHash,
      justification,
    });

    setRawWorkpapers((prev) =>
      prev.map((w) =>
        w.id === workpaperId
          ? {
              ...w,
              status: 'reopened',
              sealed: false,
              sealedHash: undefined,
            }
          : w
      )
    );
  };

  const addObservation = async (
    obs: Omit<AuditObservation, 'id' | 'createdAt' | 'raisedBy'>
  ) => {
    const gate = canPerformAction(currentUser, 'raise_observation');
    if (!gate.allowed) {
      throw new Error(gate.reason || 'Not allowed to raise observation');
    }

    const newObs: AuditObservation = {
      ...obs,
      id: `obs-${Date.now()}`,
      createdAt: new Date().toISOString(),
      raisedBy: currentUser.id,
    };

    setRawObservations((prev) => [newObs, ...prev]);

    // Also auto-create tracking Issue
    const newIssue: AuditIssue = {
      id: `iss-${Date.now()}`,
      observationId: newObs.id,
      entityId: newObs.entityId,
      universeId: newObs.universeId,
      department: rawEntities.find((e) => e.id === newObs.entityId)?.department || 'Audit',
      title: newObs.title,
      description: newObs.condition,
      severity: newObs.severity,
      status: 'identified',
      ownerId: currentUser.id,
      identifiedDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    };
    setRawIssues((prev) => [newIssue, ...prev]);

    // Ledger entry
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'test_finalize',
      entityId: newObs.entityId,
      recordId: newObs.id,
      recordType: 'observation',
      payloadSummary: `Audit Observation raised: "${newObs.title}" (${newObs.severity.toUpperCase()})`,
      payloadData: newObs,
    });

    return newObs;
  };

  const addReviewComment = async (workpaperId: string, text: string) => {
    const newComment: ReviewComment = {
      id: `cmt-${Date.now()}`,
      workpaperId,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      text,
      createdAt: new Date().toISOString(),
      status: 'open',
    };
    setRawComments((prev) => [newComment, ...prev]);
    return newComment;
  };

  const attachEvidenceToWorkpaper = async (
    workpaperId: string,
    file: { name: string; sizeBytes: number; sha256: string },
    actorName: string
  ) => {
    const item = {
      id: `ev-${Date.now()}`,
      name: file.name,
      uploadedAt: new Date().toISOString(),
      uploadedBy: actorName,
      sha256: file.sha256,
      sizeBytes: file.sizeBytes,
    };

    setRawWorkpapers((prev) =>
      prev.map((w) => (w.id === workpaperId ? { ...w, evidenceItems: [...w.evidenceItems, item] } : w))
    );

    const wp = rawWorkpapers.find((w) => w.id === workpaperId);
    if (wp) {
      await appendLedger({
        actorId: currentUser.id,
        actorName,
        actorRole: 'auditee',
        eventType: 'evidence_drop',
        entityId: wp.entityId,
        recordId: wp.id,
        recordType: 'evidence',
        payloadSummary: `Auditee evidence uploaded: ${file.name} (SHA-256: ${file.sha256.substring(0, 16)}...)`,
        payloadHash: file.sha256,
      });
    }
  };

  const updateCapStatus = (capId: string, status: CapStatus, retestStatus?: RetestStatus) => {
    setRawCapItems((prev) =>
      prev.map((c) =>
        c.id === capId
          ? {
              ...c,
              status,
              retestStatus: retestStatus !== undefined ? retestStatus : c.retestStatus,
            }
          : c
      )
    );
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        availableUsers,
        rawUniverses,
        rawEntities,
        rawEngagements,
        rawControls,
        rawWorkpapers,
        rawObservations,
        rawIssues,
        rawComments,
        rawCapItems,
        ledger,
        glassBoxTokens,
        selectedUniverseId,
        setSelectedUniverseId,
        activeTab,
        setActiveTab,
        selectedEngagementId,
        setSelectedEngagementId,
        selectedWorkpaperId,
        setSelectedWorkpaperId,
        selectedObservationId,
        setSelectedObservationId,
        inspector,
        openInspector,
        closeInspector,
        ledgerAsOf,
        setLedgerAsOf,
        isTwoStageOrg,
        setIsTwoStageOrg,
        appendLedger,
        signOffEngagement,
        reopenEngagement,
        finalizeTest,
        signOffWorkpaper,
        reopenWorkpaper,
        addObservation,
        addReviewComment,
        attachEvidenceToWorkpaper,
        updateCapStatus,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
"""
write_both('src/context/AppContext.tsx', app_context_ts)
