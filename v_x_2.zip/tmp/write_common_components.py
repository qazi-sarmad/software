import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

icons_tsx = """import React from 'react';

export interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string;
  strokeWidth?: number | string;
  className?: string;
}

const createIcon = (paths: React.ReactNode) => {
  return React.forwardRef<SVGSVGElement, IconProps>(
    ({ size = 17, strokeWidth = 1.3, className = '', ...props }, ref) => (
      <svg
        ref={ref}
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        aria-hidden="true"
        {...props}
      >
        {paths}
      </svg>
    )
  );
};

export const X = createIcon(
  <>
    <path d="M18 6 6 18" />
    <path d="m6 6 12 12" />
  </>
);

export const Search = createIcon(
  <>
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </>
);

export const Calendar = createIcon(
  <>
    <path d="M8 2v4" />
    <path d="M16 2v4" />
    <rect width="18" height="18" x="3" y="4" rx="2" />
    <path d="M3 10h18" />
  </>
);

export const Check = createIcon(
  <>
    <path d="M20 6 9 17l-5-5" />
  </>
);

export const CheckCheck = createIcon(
  <>
    <path d="M18 6 7 17l-5-5" />
    <path d="m22 10-7.5 7.5L13 16" />
  </>
);

export const CheckCircle = createIcon(
  <>
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <path d="m9 11 3 3L22 4" />
  </>
);

export const CheckCircle2 = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <path d="m9 12 2 2 4-4" />
  </>
);

export const AlertCircle = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <line x1="12" x2="12" y1="8" y2="12" />
    <line x1="12" x2="12.01" y1="16" y2="16" />
  </>
);

export const AlertTriangle = createIcon(
  <>
    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
    <line x1="12" x2="12" y1="9" y2="13" />
    <line x1="12" x2="12.01" y1="17" y2="17" />
  </>
);

export const Shield = createIcon(
  <>
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
  </>
);

export const ShieldCheck = createIcon(
  <>
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
    <path d="m9 12 2 2 4-4" />
  </>
);

export const ShieldAlert = createIcon(
  <>
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
    <line x1="12" x2="12" y1="8" y2="12" />
    <line x1="12" x2="12.01" y1="16" y2="16" />
  </>
);

export const ArrowRight = createIcon(
  <>
    <path d="M5 12h14" />
    <path d="m12 5 7 7-7 7" />
  </>
);

export const ArrowLeft = createIcon(
  <>
    <path d="m12 19-7-7 7-7" />
    <path d="M19 12H5" />
  </>
);

export const ArrowUp = createIcon(
  <>
    <path d="m5 12 7-7 7 7" />
    <path d="M12 19V5" />
  </>
);

export const ArrowDown = createIcon(
  <>
    <path d="M12 5v14" />
    <path d="m19 12-7 7-7-7" />
  </>
);

export const ChevronDown = createIcon(
  <>
    <path d="m6 9 6 6 6-6" />
  </>
);

export const ChevronUp = createIcon(
  <>
    <path d="m18 15-6-6-6 6" />
  </>
);

export const ChevronLeft = createIcon(
  <>
    <path d="m15 18-6-6 6-6" />
  </>
);

export const ChevronRight = createIcon(
  <>
    <path d="m9 18 6-6-6-6" />
  </>
);

export const Clock = createIcon(
  <>
    <circle cx="12" cy="12" r="10" />
    <polyline points="12 6 12 12 16 14" />
  </>
);

export const User = createIcon(
  <>
    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
    <circle cx="12" cy="7" r="4" />
  </>
);

export const Users = createIcon(
  <>
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <circle cx="9" cy="7" r="4" />
    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </>
);

export const Settings = createIcon(
  <>
    <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
    <circle cx="12" cy="12" r="3" />
  </>
);

export const Building = createIcon(
  <>
    <rect width="16" height="20" x="4" y="2" rx="2" ry="2" />
    <path d="M9 22v-4h6v4" />
    <path d="M8 6h.01" />
    <path d="M16 6h.01" />
    <path d="M12 6h.01" />
    <path d="M12 10h.01" />
    <path d="M12 14h.01" />
    <path d="M16 10h.01" />
    <path d="M16 14h.01" />
    <path d="M8 10h.01" />
    <path d="M8 14h.01" />
  </>
);

export const Sun = createIcon(
  <>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2" />
    <path d="M12 20v2" />
    <path d="m4.93 4.93 1.41 1.41" />
    <path d="m17.66 17.66 1.41 1.41" />
    <path d="M2 12h2" />
    <path d="M20 12h2" />
    <path d="m6.34 17.66-1.41 1.41" />
    <path d="m19.07 4.93-1.41 1.41" />
  </>
);

export const Moon = createIcon(
  <>
    <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
  </>
);

export const Laptop = createIcon(
  <>
    <path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16" />
  </>
);

export const Palette = createIcon(
  <>
    <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
    <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
    <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
    <circle cx="6.5" cy="12.5" r=".5" fill="currentColor" />
    <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z" />
  </>
);

export const LogOut = createIcon(
  <>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
    <polyline points="16 17 21 12 16 7" />
    <line x1="21" x2="9" y1="12" y2="12" />
  </>
);

export const LayoutDashboard = createIcon(
  <>
    <rect width="7" height="9" x="3" y="3" rx="1" />
    <rect width="7" height="5" x="14" y="3" rx="1" />
    <rect width="7" height="9" x="14" y="12" rx="1" />
    <rect width="7" height="5" x="3" y="16" rx="1" />
  </>
);

export const ClipboardList = createIcon(
  <>
    <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
    <path d="M12 11h4" />
    <path d="M12 16h4" />
    <path d="M8 11h.01" />
    <path d="M8 16h.01" />
  </>
);

export const Network = createIcon(
  <>
    <rect x="16" y="16" width="6" height="6" rx="1" />
    <rect x="2" y="16" width="6" height="6" rx="1" />
    <rect x="9" y="2" width="6" height="6" rx="1" />
    <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
    <path d="M12 12V8" />
  </>
);

export const FileBarChart = createIcon(
  <>
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
    <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    <path d="M8 18v-2" />
    <path d="M12 18v-4" />
    <path d="M16 18v-6" />
  </>
);

export const History = createIcon(
  <>
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
    <path d="M12 7v5l4 2" />
  </>
);

export const RotateCcw = createIcon(
  <>
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
  </>
);

export const RefreshCw = createIcon(
  <>
    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
    <path d="M21 3v5h-5" />
    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
    <path d="M8 16H3v5" />
  </>
);

export const Filter = createIcon(
  <>
    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
  </>
);

export const Folder = createIcon(
  <>
    <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
  </>
);

export const FileText = createIcon(
  <>
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
    <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    <path d="M10 9H8" />
    <path d="M16 13H8" />
    <path d="M16 17H8" />
  </>
);

export const FileCheck = createIcon(
  <>
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
    <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    <path d="m9 15 2 2 4-4" />
  </>
);

export const TrendingUp = createIcon(
  <>
    <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
    <polyline points="16 7 22 7 22 13" />
  </>
);

export const TrendingDown = createIcon(
  <>
    <polyline points="22 17 13.5 8.5 8.5 13.5 2 7" />
    <polyline points="16 17 22 17 22 11" />
  </>
);

export const Activity = createIcon(
  <>
    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
  </>
);

export const Sliders = createIcon(
  <>
    <line x1="4" x2="4" y1="21" y2="14" />
    <line x1="4" x2="4" y1="10" y2="3" />
    <line x1="12" x2="12" y1="21" y2="12" />
    <line x1="12" x2="12" y1="8" y2="3" />
    <line x1="20" x2="20" y1="21" y2="16" />
    <line x1="20" x2="20" y1="12" y2="3" />
    <line x1="1" x2="7" y1="14" y2="14" />
    <line x1="9" x2="15" y1="8" y2="8" />
    <line x1="17" x2="23" y1="16" y2="16" />
  </>
);

export const Zap = createIcon(
  <>
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
  </>
);

export const ZoomIn = createIcon(
  <>
    <circle cx="11" cy="11" r="8" />
    <line x1="21" x2="16.65" y1="21" y2="16.65" />
    <line x1="11" x2="11" y1="8" y2="14" />
    <line x1="8" x2="14" y1="11" y2="11" />
  </>
);

export const ZoomOut = createIcon(
  <>
    <circle cx="11" cy="11" r="8" />
    <line x1="21" x2="16.65" y1="21" y2="16.65" />
    <line x1="8" x2="14" y1="11" y2="11" />
  </>
);

export const MessageSquare = createIcon(
  <>
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
  </>
);

export const MessageCircle = createIcon(
  <>
    <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
  </>
);

export const Send = createIcon(
  <>
    <path d="m22 2-7 20-4-9-9-4Z" />
    <path d="M22 2 11 13" />
  </>
);

export const Plus = createIcon(
  <>
    <path d="M5 12h14" />
    <path d="M12 5v14" />
  </>
);

export const Minus = createIcon(
  <>
    <path d="M5 12h14" />
  </>
);

export const Layers = createIcon(
  <>
    <path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z" />
    <path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65" />
    <path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65" />
  </>
);

export const GitCommit = createIcon(
  <>
    <circle cx="12" cy="12" r="3" />
    <line x1="3" x2="9" y1="12" y2="12" />
    <line x1="15" x2="21" y1="12" y2="12" />
  </>
);

export const Download = createIcon(
  <>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="7 10 12 15 17 10" />
    <line x1="12" x2="12" y1="15" y2="3" />
  </>
);

export const Upload = createIcon(
  <>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="17 8 12 3 7 8" />
    <line x1="12" x2="12" y1="3" y2="15" />
  </>
);

export const Lock = createIcon(
  <>
    <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </>
);

export const Unlock = createIcon(
  <>
    <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 9.9-1" />
  </>
);

export const Eye = createIcon(
  <>
    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
  </>
);

export const EyeOff = createIcon(
  <>
    <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" />
    <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
    <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61" />
    <line x1="2" x2="22" y1="2" y2="22" />
  </>
);

export const Hash = createIcon(
  <>
    <line x1="4" x2="20" y1="9" y2="9" />
    <line x1="4" x2="20" y1="15" y2="15" />
    <line x1="10" x2="8" y1="3" y2="21" />
    <line x1="16" x2="14" y1="3" y2="21" />
  </>
);

export const Share2 = createIcon(
  <>
    <circle cx="18" cy="5" r="3" />
    <circle cx="6" cy="12" r="3" />
    <circle cx="18" cy="19" r="3" />
    <line x1="8.59" x2="15.42" y1="13.51" y2="17.49" />
    <line x1="15.41" x2="8.59" y1="6.51" y2="10.49" />
  </>
);

export const FileSpreadsheet = createIcon(
  <>
    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
    <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    <path d="M8 13h2" />
    <path d="M14 13h2" />
    <path d="M8 17h2" />
    <path d="M14 17h2" />
  </>
);

export const ExternalLink = createIcon(
  <>
    <path d="M15 3h6v6" />
    <path d="M10 14 21 3" />
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
  </>
);

export const Paperclip = createIcon(
  <>
    <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" />
  </>
);
"""
write_both('src/components/common/Icons.tsx', icons_tsx)

inspector_panel_tsx = """import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from './Icons';

interface InspectorPanelProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  width?: string; // e.g. "max-w-2xl" or "max-w-4xl"
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  badge,
  width = 'max-w-2xl',
  children,
  footer,
}) => {
  const panelRef = useRef<HTMLDivElement>(null);

  // Close on Escape key press & handle focus trapping
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    // Focus panel on open
    panelRef.current?.focus();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end overflow-hidden">
          {/* Backdrop Scrim */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-xs"
            aria-hidden="true"
          />

          {/* Sliding Inspector Panel */}
          <motion.div
            ref={panelRef}
            tabIndex={-1}
            role="dialog"
            aria-modal="true"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 30,
            }}
            className={`relative w-full ${width} h-full bg-surface border-l border-hairline shadow-apple flex flex-col z-10 outline-none`}
          >
            {/* Header with frosted glass style */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-hairline bg-surface/90 backdrop-blur-md shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h2 className="text-apple-15 font-semibold text-primary truncate">{title}</h2>
                    {badge}
                  </div>
                  {subtitle && (
                    <p className="text-apple-12 text-secondary truncate mt-0.5">{subtitle}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg text-secondary hover:text-primary bg-surface-hover transition-colors flex items-center gap-1.5"
                  title="Close (Esc)"
                  aria-label="Close inspector panel"
                >
                  <span className="text-apple-11 text-tertiary hidden sm:inline">Esc</span>
                  <X className="w-4 h-4 stroke-[1.5]" />
                </button>
              </div>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">{children}</div>

            {/* Optional Footer */}
            {footer && (
              <div className="px-6 py-4 border-t border-hairline bg-surface-elevated shrink-0">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
"""
write_both('src/components/common/InspectorPanel.tsx', inspector_panel_tsx)

hover_preview_tsx = """import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';

export interface HoverPreviewContent {
  title: string;
  subtitle?: string;
  category?: string;
  status?: string;
  statusType?: 'verdigris' | 'cinnabar' | 'amber' | 'neutral';
  exceptionsCount?: number;
  owner?: string;
  dueDate?: string;
  metrics?: { label: string; value: string | number }[];
  hint?: string;
}

interface HoverPreviewProps {
  children: React.ReactNode;
  content: HoverPreviewContent | null | undefined;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
}

export const HoverPreview: React.FC<HoverPreviewProps> = ({
  children,
  content,
  onClick,
  className = '',
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [coords, setCoords] = useState<{ x: number; y: number; placeAbove: boolean }>({
    x: 0,
    y: 0,
    placeAbove: false,
  });
  const triggerRef = useRef<HTMLDivElement>(null);
  const openTimer = useRef<number | null>(null);
  const closeTimer = useRef<number | null>(null);

  const calculatePosition = () => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const popoverWidth = 280;
    const popoverHeight = 160;

    // Center horizontally on trigger, clamp to viewport padding
    let x = rect.left + rect.width / 2 - popoverWidth / 2;
    x = Math.max(12, Math.min(x, window.innerWidth - popoverWidth - 12));

    // Place below by default, or above if close to bottom
    const spaceBelow = window.innerHeight - rect.bottom;
    const placeAbove = spaceBelow < popoverHeight + 20 && rect.top > popoverHeight + 20;
    const y = placeAbove ? rect.top - 8 : rect.bottom + 8;

    setCoords({ x, y, placeAbove });
  };

  const handleMouseEnter = () => {
    if (disabled || !content) return;
    if (closeTimer.current) clearTimeout(closeTimer.current);
    openTimer.current = window.setTimeout(() => {
      calculatePosition();
      setIsOpen(true);
    }, 120);
  };

  const handleMouseLeave = () => {
    if (openTimer.current) clearTimeout(openTimer.current);
    closeTimer.current = window.setTimeout(() => {
      setIsOpen(false);
    }, 80);
  };

  const handleFocus = () => {
    if (disabled || !content) return;
    calculatePosition();
    setIsOpen(true);
  };

  const handleBlur = () => {
    setIsOpen(false);
  };

  // Touch support: long press (350ms)
  const touchTimer = useRef<number | null>(null);
  const handleTouchStart = () => {
    if (disabled || !content) return;
    touchTimer.current = window.setTimeout(() => {
      calculatePosition();
      setIsOpen(true);
    }, 350);
  };

  const handleTouchEnd = () => {
    if (touchTimer.current) clearTimeout(touchTimer.current);
  };

  useEffect(() => {
    return () => {
      if (openTimer.current) clearTimeout(openTimer.current);
      if (closeTimer.current) clearTimeout(closeTimer.current);
      if (touchTimer.current) clearTimeout(touchTimer.current);
    };
  }, []);

  const getStatusChipClass = (type?: string) => {
    switch (type) {
      case 'verdigris':
        return 'text-verdigris bg-verdigris-subtle border-verdigris';
      case 'cinnabar':
        return 'text-cinnabar bg-cinnabar-subtle border-cinnabar';
      case 'amber':
        return 'text-amber bg-amber-subtle';
      default:
        return 'text-secondary bg-surface-hover';
    }
  };

  return (
    <div
      ref={triggerRef}
      className={`inline-block ${className}`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onFocus={handleFocus}
      onBlur={handleBlur}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onClick={onClick}
      tabIndex={0}
      role="button"
      data-testid="hover-preview-trigger"
    >
      {children}
      {typeof document !== 'undefined' &&
        createPortal(
          <AnimatePresence>
            {isOpen && content && (
              <motion.div
                data-testid="hover-preview-popover"
                initial={{
                  opacity: 0,
                  scale: 0.96,
                  y: coords.placeAbove ? 6 : -6,
                }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  y: 0,
                }}
                exit={{
                  opacity: 0,
                  scale: 0.96,
                  y: coords.placeAbove ? 6 : -6,
                }}
                transition={{
                  type: 'spring',
                  stiffness: 300,
                  damping: 30,
                }}
                style={{
                  position: 'fixed',
                  top: coords.placeAbove ? undefined : coords.y,
                  bottom: coords.placeAbove ? window.innerHeight - coords.y : undefined,
                  left: coords.x,
                  zIndex: 9999,
                  pointerEvents: 'none',
                  width: 280,
                }}
                className="bg-glass border border-hairline shadow-apple rounded-xl p-3.5 select-none"
              >
                {/* Header row: category and status */}
                <div className="flex items-center justify-between gap-2 mb-1.5 text-apple-11">
                  {content.category && (
                    <span className="text-secondary font-medium tracking-wide uppercase">
                      {content.category}
                    </span>
                  )}
                  {content.status && (
                    <span
                      className={`px-1.5 py-0.5 rounded text-apple-11 font-medium ${getStatusChipClass(
                        content.statusType
                      )}`}
                    >
                      {content.status}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h4 className="text-primary text-apple-13 font-semibold line-clamp-2 leading-snug mb-1">
                  {content.title}
                </h4>
                {content.subtitle && (
                  <p className="text-secondary text-apple-11 line-clamp-1 mb-2">
                    {content.subtitle}
                  </p>
                )}

                {/* Exception Count / Owner / Due Date metadata */}
                <div className="grid grid-cols-2 gap-y-1 gap-x-2 pt-2 border-t border-hairline text-apple-11">
                  {content.owner && (
                    <div>
                      <span className="text-tertiary">Owner: </span>
                      <span className="text-primary font-medium">{content.owner}</span>
                    </div>
                  )}
                  {content.dueDate && (
                    <div>
                      <span className="text-tertiary">Due: </span>
                      <span className="text-primary tabular-nums font-medium">
                        {content.dueDate}
                      </span>
                    </div>
                  )}
                  {content.exceptionsCount !== undefined && (
                    <div className="col-span-2">
                      <span className="text-tertiary">Exceptions: </span>
                      <span
                        className={`tabular-nums font-semibold ${
                          content.exceptionsCount > 0 ? 'text-cinnabar' : 'text-verdigris'
                        }`}
                      >
                        {content.exceptionsCount === 0
                          ? '0 (Clean)'
                          : `${content.exceptionsCount} Identified`}
                      </span>
                    </div>
                  )}
                  {content.metrics?.map((m, i) => (
                    <div key={i}>
                      <span className="text-tertiary">{m.label}: </span>
                      <span className="text-primary tabular-nums font-medium">{m.value}</span>
                    </div>
                  ))}
                </div>

                {/* Hint */}
                <div className="mt-2.5 pt-1.5 border-t border-hairline flex items-center justify-between text-apple-11 text-secondary">
                  <span>{content.hint || 'Click to open details'}</span>
                  <span className="text-accent text-apple-11 font-medium">→</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>,
          document.body
        )}
    </div>
  );
};
"""
write_both('src/components/common/HoverPreview.tsx', hover_preview_tsx)

hover_preview_test_tsx = """import React from 'react';
import { describe, expect, it, vi, beforeAll, afterAll } from 'vitest';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import { MotionGlobalConfig } from 'motion/react';
import { HoverPreview } from './HoverPreview';

beforeAll(() => {
  MotionGlobalConfig.skipAnimations = true;
});

afterAll(() => {
  MotionGlobalConfig.skipAnimations = false;
});

describe('Task C: Universal Hover Previews Component Tests', () => {
  it('Gantt Bar: Renders preview on hover and hides on mouse leave', async () => {
    const ganttContent = {
      title: 'Q3 Liquidity Coverage Audit',
      category: 'Stage: Fieldwork',
      subtitle: '68% complete',
      status: 'In Fieldwork',
      statusType: 'amber' as const,
      dueDate: '2026-10-24',
      exceptionsCount: 2,
    };

    render(
      <HoverPreview content={ganttContent}>
        <div data-testid="gantt-bar">Gantt Bar</div>
      </HoverPreview>
    );

    const trigger = screen.getByTestId('hover-preview-trigger');

    // Initially popover is not in DOM
    expect(screen.queryByTestId('hover-preview-popover')).toBeNull();

    // Hover trigger
    fireEvent.mouseEnter(trigger);

    // Wait for popover to appear past delay
    await waitFor(() => {
      expect(screen.getByTestId('hover-preview-popover')).toBeDefined();
    }, { timeout: 1000 });

    expect(screen.getByText('Q3 Liquidity Coverage Audit')).toBeDefined();
    expect(screen.getByText('2 Identified')).toBeDefined();

    // Leave trigger
    fireEvent.mouseLeave(trigger);

    // Wait for popover exit animation to complete and remove from DOM
    await waitFor(() => {
      expect(screen.queryByTestId('hover-preview-popover')).toBeNull();
    }, { timeout: 1000 });
  });

  it('Calendar Day: Renders preview with milestone details on hover', async () => {
    const calendarContent = {
      title: 'September 30, 2026',
      category: 'Audit Calendar Milestone',
      subtitle: '3 Scheduled Milestones',
      status: 'Critical Due Date',
      statusType: 'cinnabar' as const,
      metrics: [{ label: 'Engagements Due', value: 2 }],
    };

    render(
      <HoverPreview content={calendarContent}>
        <div data-testid="calendar-day">Day 30</div>
      </HoverPreview>
    );

    const trigger = screen.getByTestId('hover-preview-trigger');
    fireEvent.mouseEnter(trigger);

    await waitFor(() => {
      expect(screen.getByTestId('hover-preview-popover')).toBeDefined();
    }, { timeout: 1000 });

    expect(screen.getByText('September 30, 2026')).toBeDefined();
    expect(screen.getByText('Critical Due Date')).toBeDefined();

    fireEvent.mouseLeave(trigger);

    await waitFor(() => {
      expect(screen.queryByTestId('hover-preview-popover')).toBeNull();
    }, { timeout: 1000 });
  });

  it('Issue Row: Displays owner, due date, and exception status on keyboard focus', async () => {
    const issueContent = {
      title: 'Delayed Cash Ledger Posting',
      category: 'Treasury Finding',
      status: 'CRITICAL',
      statusType: 'cinnabar' as const,
      owner: 'David Miller',
      dueDate: '2026-11-30',
    };

    render(
      <HoverPreview content={issueContent}>
        <div data-testid="issue-row">Issue Row</div>
      </HoverPreview>
    );

    const trigger = screen.getByTestId('hover-preview-trigger');

    // Test Keyboard focus support
    fireEvent.focus(trigger);

    await waitFor(() => {
      expect(screen.getByTestId('hover-preview-popover')).toBeDefined();
    }, { timeout: 1000 });

    expect(screen.getByText('Delayed Cash Ledger Posting')).toBeDefined();
    expect(screen.getByText('David Miller')).toBeDefined();

    // Blur hides preview
    fireEvent.blur(trigger);

    await waitFor(() => {
      expect(screen.queryByTestId('hover-preview-popover')).toBeNull();
    }, { timeout: 1000 });
  });

  it('Entity Card: Renders SIRA score and controls count instantly', async () => {
    const entityContent = {
      title: 'Fixed Income & Derivatives Trading',
      category: 'GBM-TRADE',
      status: 'SIRA Score: 76/100',
      statusType: 'cinnabar' as const,
      metrics: [
        { label: 'Inherent Risk', value: 'HIGH' },
        { label: 'Controls Active', value: 16 },
      ],
    };

    render(
      <HoverPreview content={entityContent}>
        <div data-testid="entity-card">Entity Card</div>
      </HoverPreview>
    );

    const trigger = screen.getByTestId('hover-preview-trigger');
    fireEvent.mouseEnter(trigger);

    await waitFor(() => {
      expect(screen.getByTestId('hover-preview-popover')).toBeDefined();
    }, { timeout: 1000 });

    expect(screen.getByText('Fixed Income & Derivatives Trading')).toBeDefined();
    expect(screen.getByText('SIRA Score: 76/100')).toBeDefined();

    fireEvent.mouseLeave(trigger);

    await waitFor(() => {
      expect(screen.queryByTestId('hover-preview-popover')).toBeNull();
    }, { timeout: 1000 });
  });

  it('Review Comment: Renders author and review query on touch long-press', async () => {
    const commentContent = {
      title: 'Comment from Marcus Vance (REVIEWER)',
      category: 'Workpaper WP-TREAS-LQ-01',
      subtitle: 'Please check July 14th tickmark statement',
      status: 'Pending Preparer Action',
      statusType: 'amber' as const,
    };

    render(
      <HoverPreview content={commentContent}>
        <div data-testid="comment-dock-item">Comment Item</div>
      </HoverPreview>
    );

    const trigger = screen.getByTestId('hover-preview-trigger');

    // Test Touch Long-press support (350ms)
    fireEvent.touchStart(trigger);

    await waitFor(() => {
      expect(screen.getByTestId('hover-preview-popover')).toBeDefined();
    }, { timeout: 1000 });

    expect(screen.getByText('Comment from Marcus Vance (REVIEWER)')).toBeDefined();

    fireEvent.touchEnd(trigger);
  });
});
"""
write_both('src/components/common/HoverPreview.test.tsx', hover_preview_test_tsx)
