import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

cal_panel_tsx = """import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useScopedData } from '../../hooks/useScopedData';
import { AuditEngagement } from '../../types';
import {
  ChevronLeft,
  ChevronRight,
  X,
  Check,
  RotateCcw,
  Calendar,
} from '../common/Icons';

interface CalendarPanelProps {
  isOpen: boolean;
  onClose: () => void;
  triggerRef: React.RefObject<HTMLButtonElement | null>;
  onSelectAudit?: (auditId: string) => void;
}

export const HeaderCalendarPanel: React.FC<CalendarPanelProps> = ({
  isOpen,
  onClose,
  triggerRef,
  onSelectAudit,
}) => {
  const { scopedEngagements } = useScopedData();
  const panelRef = useRef<HTMLDivElement>(null);

  // Month navigation: default to September 2026
  const [currentDate, setCurrentDate] = useState<Date>(new Date(2026, 8, 1));
  const [slideDirection, setSlideDirection] = useState<'left' | 'right'>('right');
  const [highlightedAuditId, setHighlightedAuditId] = useState<string | null>(null);

  // Hover popover for day
  const [hoveredDay, setHoveredDay] = useState<{
    dateStr: string;
    dayNumber: number;
    audits: AuditEngagement[];
    rect: DOMRect;
  } | null>(null);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Monday-start calendar calculation
  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sun
  const mondayOffset = (firstDayOfMonth + 6) % 7; // 0 = Mon, 6 = Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const changeMonth = (delta: number) => {
    setSlideDirection(delta > 0 ? 'right' : 'left');
    setCurrentDate((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  };

  const jumpToToday = () => {
    setSlideDirection('right');
    setCurrentDate(new Date(2026, 8, 30)); // 2026-09-30 simulated today
  };

  // Native non-passive wheel listener with preventDefault and 260ms cooldown
  useEffect(() => {
    if (!isOpen || !panelRef.current) return;
    let lastWheelTime = 0;
    const cooldownMs = 260;

    const handleWheel = (e: WheelEvent) => {
      // Must prevent default page scroll
      e.preventDefault();
      e.stopPropagation();
      const now = Date.now();
      if (now - lastWheelTime < cooldownMs) return;

      if (Math.abs(e.deltaY) > 10 || Math.abs(e.deltaX) > 10) {
        lastWheelTime = now;
        if (e.deltaY > 0 || e.deltaX > 0) {
          changeMonth(1);
        } else {
          changeMonth(-1);
        }
      }
    };

    const el = panelRef.current;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      el.removeEventListener('wheel', handleWheel);
    };
  }, [isOpen]);

  // Close on outside click and Esc
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    const handlePointerDown = (e: MouseEvent) => {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node) &&
        triggerRef.current &&
        !triggerRef.current.contains(e.target as Node)
      ) {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('pointerdown', handlePointerDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('pointerdown', handlePointerDown);
    };
  }, [isOpen, onClose, triggerRef]);

  // Determine audits active on a given day
  const getAuditsForDay = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return scopedEngagements.filter((eng) => {
      const start = eng.periodStart;
      const due = eng.dueDate;
      return dateStr >= start && dateStr <= due;
    });
  };

  const highlightedAudit = scopedEngagements.find((e) => e.id === highlightedAuditId);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={panelRef}
          role="dialog"
          aria-label="Audit Calendar Panel"
          initial={{ opacity: 0, scale: 0.94, y: -8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: -8 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          style={{ transformOrigin: 'top right' }}
          className="absolute right-0 top-14 mt-2 w-[340px] bg-glass border border-hairline shadow-apple rounded-2xl p-4 z-50 select-none text-primary"
        >
          {/* Header row: Month in serif font, prev/next, and Jump to today */}
          <div className="flex items-center justify-between pb-3 border-b border-hairline">
            <div className="flex items-center gap-1.5">
              <span className="font-serif-title text-apple-15 font-bold text-primary">
                {monthNames[month]} {year}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={jumpToToday}
                className="px-2 py-0.5 rounded text-apple-11 font-medium text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                title="Jump to today (Sep 30)"
              >
                Today
              </button>
              <button
                onClick={() => changeMonth(-1)}
                className="p-1 rounded-md text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                title="Previous month"
              >
                <ChevronLeft className="w-4 h-4 stroke-[1.5]" />
              </button>
              <button
                onClick={() => changeMonth(1)}
                className="p-1 rounded-md text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                title="Next month"
              >
                <ChevronRight className="w-4 h-4 stroke-[1.5]" />
              </button>
            </div>
          </div>

          {/* Dismissible selected audit filter chip */}
          {highlightedAudit && (
            <div className="mt-2.5 flex items-center justify-between px-2.5 py-1 rounded-lg bg-accent-subtle text-accent text-apple-11 font-medium">
              <span className="truncate pr-2">Highlighting: {highlightedAudit.title}</span>
              <button
                onClick={() => setHighlightedAuditId(null)}
                className="p-0.5 hover:opacity-75"
              >
                <X className="w-3 h-3 stroke-[1.5]" />
              </button>
            </div>
          )}

          {/* Monday-start 7-column header */}
          <div className="grid grid-cols-7 text-center text-apple-11 font-semibold text-secondary uppercase tracking-wider pt-3 pb-1.5">
            <div>M</div>
            <div>T</div>
            <div>W</div>
            <div>T</div>
            <div>F</div>
            <div>S</div>
            <div>S</div>
          </div>

          {/* Sliding Grid Animation */}
          <div className="overflow-hidden relative min-h-[210px]">
            <motion.div
              key={`${year}-${month}`}
              initial={{ x: slideDirection === 'right' ? 30 : -30, opacity: 0.7 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="grid grid-cols-7 gap-1"
            >
              {/* Empty leading padding */}
              {Array.from({ length: mondayOffset }).map((_, i) => (
                <div key={`offset-${i}`} className="h-8 rounded-lg opacity-20" />
              ))}

              {/* Days in Month */}
              {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(
                  day
                ).padStart(2, '0')}`;
                const dayAudits = getAuditsForDay(day);
                const hasAudits = dayAudits.length > 0;
                const isMultiAudit = dayAudits.length > 1;
                const isToday = year === 2026 && month === 8 && day === 30;

                // Check audit states for tinting
                const hasOverdue = dayAudits.some((a) => a.dueDate < '2026-09-30' && a.status !== 'signed_off');
                const hasInProgress = dayAudits.some((a) => a.status === 'in_progress');
                const hasCompleted = dayAudits.some((a) => a.status === 'signed_off');
                const isSelectedAuditDay =
                  highlightedAuditId &&
                  dayAudits.some((a) => a.id === highlightedAuditId);

                let cellClass = 'hover:bg-surface-hover text-secondary';
                if (isToday) {
                  cellClass = 'bg-accent text-white font-bold shadow-xs';
                } else if (isSelectedAuditDay) {
                  cellClass = 'bg-accent-subtle text-accent font-bold ring-1 ring-accent';
                } else if (hasOverdue) {
                  cellClass = 'bg-cinnabar-subtle text-cinnabar font-semibold';
                } else if (hasCompleted) {
                  cellClass = 'bg-verdigris-subtle text-verdigris font-semibold';
                } else if (hasInProgress) {
                  cellClass = 'bg-surface-elevated text-primary font-medium';
                }

                return (
                  <div
                    key={day}
                    onMouseEnter={(e) => {
                      if (hasAudits) {
                        setHoveredDay({
                          dateStr,
                          dayNumber: day,
                          audits: dayAudits,
                          rect: e.currentTarget.getBoundingClientRect(),
                        });
                      }
                    }}
                    onMouseLeave={() => setHoveredDay(null)}
                    className={`h-8 rounded-lg flex flex-col items-center justify-center text-apple-12 tabular-nums cursor-pointer relative transition-all ${cellClass}`}
                  >
                    <span>{day}</span>
                    {/* Multi-audit indicator dot */}
                    {isMultiAudit && !isToday && (
                      <span className="w-1 h-1 rounded-full bg-accent absolute bottom-1" />
                    )}
                  </div>
                );
              })}
            </motion.div>
          </div>

          {/* Hover Popover showing 3 step circles per audit (Fieldwork / Review / Sign-off) */}
          {hoveredDay && (
            <div
              className="absolute left-4 right-4 bg-surface border border-hairline shadow-apple rounded-xl p-3 z-50 text-apple-11 space-y-2 pointer-events-auto"
              style={{ bottom: 44 }}
            >
              <div className="font-semibold text-primary border-b border-hairline pb-1.5 flex items-center justify-between">
                <span>{hoveredDay.dateStr}</span>
                <span className="text-secondary font-normal">{hoveredDay.audits.length} audit(s)</span>
              </div>
              <div className="space-y-2 max-h-36 overflow-y-auto">
                {hoveredDay.audits.map((audit) => {
                  const isSigned = audit.status === 'signed_off';
                  const isReopened = audit.status === 'reopened';
                  const step1 = isSigned || audit.completionPercent > 50 ? 'check' : 'filled';
                  const step2 = isSigned ? 'check' : isReopened ? 'red_dot' : audit.stage === 'review' ? 'filled' : 'empty';
                  const step3 = isSigned ? 'check' : 'empty';

                  const renderStepCircle = (type: string, label: string) => {
                    if (type === 'check') {
                      return (
                        <span className="w-3.5 h-3.5 rounded-full bg-verdigris-subtle text-verdigris flex items-center justify-center" title={`${label}: Checked`}>
                          <Check className="w-2.5 h-2.5 stroke-[2]" />
                        </span>
                      );
                    }
                    if (type === 'red_dot') {
                      return (
                        <span className="w-3.5 h-3.5 rounded-full bg-cinnabar-subtle flex items-center justify-center" title={`${label}: Reverts`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-cinnabar" />
                        </span>
                      );
                    }
                    if (type === 'filled') {
                      return (
                        <span className="w-3.5 h-3.5 rounded-full border border-accent flex items-center justify-center" title={`${label}: In Progress`}>
                          <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                        </span>
                      );
                    }
                    return (
                      <span className="w-3.5 h-3.5 rounded-full border border-hairline" title={`${label}: Pending`} />
                    );
                  };

                  return (
                    <div
                      key={audit.id}
                      onClick={() => {
                        setHighlightedAuditId(audit.id);
                        if (onSelectAudit) onSelectAudit(audit.id);
                      }}
                      className="p-1.5 rounded-lg hover:bg-surface-hover cursor-pointer transition-colors"
                    >
                      <div className="font-medium text-primary truncate">{audit.title}</div>
                      <div className="flex items-center justify-between pt-1 text-tertiary">
                        <span>Due: {audit.dueDate}</span>
                        <div className="flex items-center gap-1.5">
                          {renderStepCircle(step1, 'Fieldwork')}
                          {renderStepCircle(step2, 'Review')}
                          {renderStepCircle(step3, 'Sign-off')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Legend at bottom */}
          <div className="mt-3 pt-2.5 border-t border-hairline flex items-center justify-between text-apple-11 text-secondary">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-accent" /> Active
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-verdigris" /> Sealed
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-cinnabar" /> Overdue
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-accent" /> Multi
            </span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
"""
write_both('src/components/calendar/HeaderCalendarPanel.tsx', cal_panel_tsx)

cal_tab_tsx = """import React, { useState } from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useFilterStore } from '../../context/FilterStore';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
} from '../common/Icons';

export const AuditCalendarTab: React.FC = () => {
  const { filteredEngagements, scopedWorkpapers, scopedIssues } = useScopedData();
  const filter = useFilterStore();
  const { setSelectedEngagementId, setActiveTab } = useApp();

  const [currentMonth, setCurrentMonth] = useState<number>(8); // 8 = September 2026
  const [currentYear, setCurrentYear] = useState<number>(2026);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfWeek = new Date(currentYear, currentMonth, 1).getDay(); // 0 = Sun

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  // Find events on a specific day
  const getDayEvents = (day: number) => {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(
      day
    ).padStart(2, '0')}`;

    const dueEngagements = filteredEngagements.filter((e) => e.dueDate === dateStr);
    const startEngagements = filteredEngagements.filter((e) => e.periodStart === dateStr);
    const dueIssues = scopedIssues.filter((i) => i.dueDate === dateStr);

    return {
      dueEngagements,
      startEngagements,
      dueIssues,
      totalCount: dueEngagements.length + startEngagements.length + dueIssues.length,
      hasCritical: dueIssues.some((i) => i.severity === 'critical'),
    };
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-hairline pb-4">
        <div>
          <h1 className="text-apple-28 font-bold text-primary tracking-tight">Audit Schedule &amp; Milestones</h1>
          <p className="text-apple-15 text-secondary mt-1">
            Deadlines, phase completions, and testing deadlines across your scoped entities
          </p>
        </div>

        {/* Month Navigation */}
        <div className="flex items-center gap-3 bg-surface border border-hairline rounded-xl p-1.5 shadow-apple">
          <button
            onClick={handlePrevMonth}
            className="p-1.5 rounded-lg text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
          >
            <ChevronLeft className="w-4 h-4 stroke-[1.5]" />
          </button>
          <span className="text-apple-13 font-semibold text-primary px-3">
            {monthNames[currentMonth]} {currentYear}
          </span>
          <button
            onClick={handleNextMonth}
            className="p-1.5 rounded-lg text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
          >
            <ChevronRight className="w-4 h-4 stroke-[1.5]" />
          </button>
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="bg-surface border border-hairline rounded-2xl p-6 shadow-apple space-y-4">
        {/* Days of week header */}
        <div className="grid grid-cols-7 text-center text-apple-11 font-semibold text-secondary uppercase tracking-wider pb-2 border-b border-hairline">
          <div>Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>

        {/* Calendar Day Cells */}
        <div className="grid grid-cols-7 gap-2">
          {/* Empty cells for leading offset */}
          {Array.from({ length: firstDayOfWeek }).map((_, i) => (
            <div key={`offset-${i}`} className="min-h-[100px] p-2 rounded-xl bg-surface-elevated/20 opacity-40" />
          ))}

          {/* Days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const events = getDayEvents(day);
            const isToday = currentYear === 2026 && currentMonth === 8 && day === 30;

            const previewData = events.totalCount > 0 ? {
              title: `${monthNames[currentMonth]} ${day}, ${currentYear}`,
              category: 'Audit Calendar Milestone',
              subtitle: `${events.totalCount} Scheduled Milestone(s)`,
              status: events.hasCritical ? 'Critical Due Date' : 'Normal Cadence',
              statusType: events.hasCritical ? ('cinnabar' as const) : ('verdigris' as const),
              metrics: [
                { label: 'Engagements Due', value: events.dueEngagements.length },
                { label: 'Issues Due', value: events.dueIssues.length },
              ],
              hint: 'Click to inspect scheduled items',
            } : null;

            return (
              <HoverPreview key={day} content={previewData} className="w-full">
                <div
                  className={`min-h-[100px] p-2.5 rounded-xl border border-hairline transition-all flex flex-col justify-between cursor-pointer ${
                    isToday
                      ? 'bg-accent-subtle border-accent'
                      : events.totalCount > 0
                      ? 'bg-surface hover:bg-surface-hover shadow-xs'
                      : 'bg-surface-elevated/30 hover:bg-surface-elevated/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-apple-13 font-semibold tabular-nums ${
                        isToday ? 'text-accent' : 'text-primary'
                      }`}
                    >
                      {day}
                    </span>
                    {/* Task 6 differentiator: Micro-state circle indicators (empty, half, check, red dot) */}
                    <div className="flex items-center gap-1">
                      {events.hasCritical && (
                        <span className="w-2 h-2 rounded-full bg-cinnabar" title="Critical Issue Due" />
                      )}
                      {events.dueEngagements.some((e) => e.status === 'signed_off') && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-verdigris stroke-[1.5]" />
                      )}
                      {events.dueEngagements.some((e) => e.status === 'in_progress') && (
                        <span className="w-2 h-2 rounded-full bg-amber" />
                      )}
                    </div>
                  </div>

                  {/* Event Badges */}
                  <div className="space-y-1 mt-1">
                    {events.dueEngagements.map((eng) => (
                      <div
                        key={eng.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedEngagementId(eng.id);
                          setActiveTab('plan');
                        }}
                        className="text-apple-11 truncate px-1.5 py-0.5 rounded bg-accent-subtle text-accent font-medium hover:opacity-80"
                      >
                        Due: {eng.title}
                      </div>
                    ))}
                    {events.dueIssues.map((iss) => (
                      <div
                        key={iss.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveTab('issues');
                        }}
                        className={`text-apple-11 truncate px-1.5 py-0.5 rounded font-medium ${
                          iss.severity === 'critical'
                            ? 'bg-cinnabar-subtle text-cinnabar'
                            : 'bg-surface-elevated text-secondary'
                        }`}
                      >
                        Issue: {iss.title}
                      </div>
                    ))}
                  </div>
                </div>
              </HoverPreview>
            );
          })}
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/calendar/AuditCalendarTab.tsx', cal_tab_tsx)

cap_inspector_tsx = """import React, { useState } from 'react';
import { AuditCapItem, CapStatus, RetestStatus, Severity } from '../../types';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  ExternalLink,
  FileText,
  ShieldCheck,
  User,
  Calendar,
} from '../common/Icons';

interface CapInspectorProps {
  data?: {
    department?: string;
    severity?: Severity;
    cap?: AuditCapItem;
    caps?: AuditCapItem[];
  };
  onClose?: () => void;
}

export const CapInspector: React.FC<CapInspectorProps> = ({ data, onClose }) => {
  const { updateCapStatus, openInspector, setActiveTab, setSelectedEngagementId } = useApp();
  const { scopedCapItems, scopedEngagements } = useScopedData();

  // If a single CAP was clicked, show detail or list
  const activeDepartment = data?.department || (data?.cap ? data.cap.department : null);
  const items = data?.caps
    ? data.caps
    : data?.cap
    ? [data.cap]
    : activeDepartment
    ? scopedCapItems.filter((c) => c.department === activeDepartment)
    : scopedCapItems;

  const [selectedCapId, setSelectedCapId] = useState<string | null>(
    data?.cap ? data.cap.id : items[0]?.id || null
  );

  const activeCap = items.find((c) => c.id === selectedCapId) || items[0];

  const getSeverityBadge = (sev: Severity) => {
    switch (sev) {
      case 'critical':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-cinnabar-subtle text-cinnabar border border-cinnabar">
            Critical
          </span>
        );
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-amber-subtle text-amber border border-amber">
            High
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-verdigris-subtle text-verdigris border border-verdigris">
            Medium
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-medium uppercase bg-surface-elevated text-secondary border border-hairline">
            Low
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header section */}
      <div className="border-b border-hairline pb-4">
        <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
          Remediation Assurance Inspector
        </span>
        <h3 className="text-apple-20 font-bold text-primary mt-1">
          {activeDepartment ? `${activeDepartment} Corrective Actions` : 'Corrective Action Plan Detail'}
        </h3>
        <p className="text-apple-12 text-secondary mt-1">
          {items.length} remediation commitment{items.length === 1 ? '' : 's'} assigned to this scope.
        </p>
      </div>

      {/* Item selector pills if multiple items in department */}
      {items.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
          {items.map((c) => {
            const isSelected = c.id === activeCap?.id;
            const isOvd = c.status === 'Overdue' || c.dueDate < '2026-09-30';
            return (
              <button
                key={c.id}
                onClick={() => setSelectedCapId(c.id)}
                className={`px-3 py-1.5 rounded-xl text-apple-12 font-medium shrink-0 transition-colors border flex items-center gap-2 ${
                  isSelected
                    ? 'bg-accent text-canvas border-accent shadow-xs'
                    : 'bg-surface-elevated border-hairline text-secondary hover:text-primary hover:bg-surface-hover'
                }`}
              >
                <span>{c.id}</span>
                {isOvd && (
                  <span className="w-2 h-2 rounded-full bg-cinnabar shrink-0 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Active CAP Details Card */}
      {activeCap ? (
        <div className="space-y-6">
          {/* Overdue Pulsing Banner if overdue (§ 3.4 requirement) */}
          {(activeCap.status === 'Overdue' || activeCap.dueDate < '2026-09-30') && (
            <div className="p-3.5 rounded-xl bg-cinnabar-subtle border border-cinnabar flex items-center justify-between animate-pulse">
              <div className="flex items-center gap-2.5 text-cinnabar">
                <AlertCircle className="w-4 h-4 stroke-[2]" />
                <span className="text-apple-12 font-semibold">
                  Remediation Target Overdue ({activeCap.agingDays} days aging)
                </span>
              </div>
              <span className="text-apple-11 font-medium text-cinnabar uppercase">
                Escalated to CIA
              </span>
            </div>
          )}

          {/* Title and Badges */}
          <div className="p-5 rounded-2xl bg-surface-elevated border border-hairline space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-apple-11 font-mono text-accent font-semibold">
                  {activeCap.id} • {activeCap.department}
                </div>
                <h4 className="text-apple-17 font-bold text-primary mt-1">
                  {activeCap.title}
                </h4>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {getSeverityBadge(activeCap.severity)}
                <span className="px-2 py-0.5 rounded text-apple-11 font-medium bg-surface text-secondary border border-hairline">
                  {activeCap.approvalStatus}
                </span>
              </div>
            </div>

            <div className="text-apple-13 text-secondary leading-relaxed bg-surface p-3.5 rounded-xl border border-hairline">
              <div className="text-apple-11 font-semibold text-primary uppercase mb-1">
                Remediation Commitment &amp; Action Plan
              </div>
              {activeCap.action}
            </div>

            {/* Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-apple-12">
              <div className="p-2.5 rounded-xl bg-surface border border-hairline">
                <div className="text-apple-11 text-tertiary">Action Owner</div>
                <div className="font-semibold text-primary mt-0.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-secondary stroke-[1.5]" />
                  <span className="truncate">{activeCap.owner}</span>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-surface border border-hairline">
                <div className="text-apple-11 text-tertiary">Target Due Date</div>
                <div className="font-semibold text-primary mt-0.5 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-secondary stroke-[1.5]" />
                  <span>{activeCap.dueDate}</span>
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-surface border border-hairline">
                <div className="text-apple-11 text-tertiary">Current Status</div>
                <div className="font-semibold text-primary mt-0.5">
                  {activeCap.status}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-surface border border-hairline">
                <div className="text-apple-11 text-tertiary">Independent Re-Test</div>
                <div className="font-semibold text-primary mt-0.5">
                  {activeCap.retestStatus}
                </div>
              </div>
            </div>

            {/* Link to originating report (§ 3.4 requirement) */}
            <div className="pt-2 border-t border-hairline flex items-center justify-between">
              <div className="flex items-center gap-2 text-apple-12 text-secondary min-w-0">
                <FileText className="w-4 h-4 stroke-[1.5] text-accent shrink-0" />
                <span className="truncate">Originating: {activeCap.originatingReport}</span>
              </div>
              <button
                onClick={() => {
                  const eng = scopedEngagements.find((e) => e.id === activeCap.engagementId);
                  if (eng) {
                    setSelectedEngagementId(eng.id);
                    openInspector('audit_file', { engagement: eng });
                  } else {
                    setActiveTab('reports');
                  }
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-accent-subtle hover:bg-accent-hover text-accent text-apple-12 font-medium transition-colors shrink-0"
              >
                <span>View Audit Report</span>
                <ExternalLink className="w-3.5 h-3.5 stroke-[1.5]" />
              </button>
            </div>
          </div>

          {/* Remediation Lifecycle Management Actions */}
          <div className="p-5 rounded-2xl bg-surface border border-hairline space-y-3">
            <h5 className="text-apple-13 font-semibold text-primary">
              Update Remediation Status &amp; Re-Test Protocol
            </h5>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => updateCapStatus(activeCap.id, 'In progress', 'In retest')}
                className="p-2 rounded-xl bg-surface-elevated hover:bg-surface-hover border border-hairline text-apple-12 font-medium text-secondary hover:text-primary transition-colors text-center"
              >
                Mark In Progress
              </button>
              <button
                onClick={() => updateCapStatus(activeCap.id, 'Pending validation', 'In retest')}
                className="p-2 rounded-xl bg-surface-elevated hover:bg-surface-hover border border-hairline text-apple-12 font-medium text-secondary hover:text-primary transition-colors text-center"
              >
                Submit for Validation
              </button>
              <button
                onClick={() => updateCapStatus(activeCap.id, 'Closed', 'Passed')}
                className="p-2 rounded-xl bg-verdigris-subtle hover:opacity-85 text-verdigris text-apple-12 font-semibold transition-opacity text-center flex items-center justify-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5 stroke-[2]" />
                <span>Verify &amp; Close</span>
              </button>
              <button
                onClick={() => updateCapStatus(activeCap.id, 'Overdue', 'Failed')}
                className="p-2 rounded-xl bg-cinnabar-subtle hover:opacity-85 text-cinnabar text-apple-12 font-semibold transition-opacity text-center flex items-center justify-center gap-1"
              >
                <AlertCircle className="w-3.5 h-3.5 stroke-[2]" />
                <span>Fail Re-Test</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="py-12 text-center text-apple-13 text-secondary">
          No corrective action item selected.
        </div>
      )}
    </div>
  );
};
"""
write_both('src/components/dashboard/CapInspector.tsx', cap_inspector_tsx)

cap_radial_tsx = """import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { useFilterStore } from '../../context/FilterStore';
import { useApp } from '../../context/AppContext';
import { AuditCapItem, Severity } from '../../types';
import { AlertCircle, Filter, RotateCcw } from '../common/Icons';

interface CapDeptData {
  department: string;
  total: number;
  overdueCount: number;
  caps: AuditCapItem[];
  severityCounts: Record<string, number>;
}

interface CapRadialTrackerProps {
  capDeptMap: Record<string, CapDeptData>;
  totalCapCount: number;
  openCapCount: number;
  overdueCapCount: number;
}

export const CapRadialTracker: React.FC<CapRadialTrackerProps> = ({
  capDeptMap,
  totalCapCount,
  openCapCount,
  overdueCapCount,
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const filter = useFilterStore();
  const { openInspector } = useApp();
  const [hoveredDept, setHoveredDept] = useState<string | null>(null);

  // Department colors mapped to harmonic palette tokens
  const deptColorPalette: Record<string, string> = {
    Treasury: 'var(--accent-primary)',
    Trading: 'var(--accent-verdigris)',
    'Credit Risk': 'var(--accent-amber)',
    Operations: 'var(--text-secondary)',
    Technology: 'var(--accent-primary)',
    Compliance: 'var(--accent-verdigris)',
  };

  const getDeptColor = (dept: string, index: number): string => {
    if (deptColorPalette[dept]) return deptColorPalette[dept];
    const fallback = ['var(--accent-primary)', 'var(--accent-verdigris)', 'var(--accent-amber)'];
    return fallback[index % fallback.length];
  };

  // Outer ring severity colors
  const severityColors: Record<Severity, string> = {
    critical: 'var(--accent-cinnabar)',
    high: 'var(--accent-amber)',
    medium: 'var(--accent-verdigris)',
    low: 'var(--text-tertiary)',
  };

  const departments = Object.values(capDeptMap).filter((d) => d.total > 0);

  useEffect(() => {
    if (!svgRef.current || departments.length === 0) return;

    const width = 340;
    const height = 340;
    const radius = Math.min(width, height) / 2;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const g = svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    // Dimensions
    const innerRadiusHub = 62;
    const innerRadiusDept = 66;
    const outerRadiusDept = 104;
    const innerRadiusCap = 108;
    const outerRadiusCap = 146;
    const overdueArcInner = 149;
    const overdueArcOuter = 153;

    // D3 Pie layout for inner ring (departments)
    const pie = d3
      .pie<CapDeptData>()
      .value((d) => d.total)
      .sort(null)
      .padAngle(0.035);

    const pieData = pie(departments);

    // Inner Arc generator
    const arcDept = d3
      .arc<d3.PieArcDatum<CapDeptData>>()
      .innerRadius(innerRadiusDept)
      .outerRadius(outerRadiusDept)
      .cornerRadius(4);

    // Outer Arc generator for CAP severities
    const arcCap = d3
      .arc<{ startAngle: number; endAngle: number; padAngle: number }>()
      .innerRadius(innerRadiusCap)
      .outerRadius(outerRadiusCap)
      .cornerRadius(2);

    // Overdue outer rim arc generator
    const arcOverdue = d3
      .arc<{ startAngle: number; endAngle: number }>()
      .innerRadius(overdueArcInner)
      .outerRadius(overdueArcOuter)
      .cornerRadius(1.5);

    // Draw Inner Ring (Departments) with draw-on animation and stagger
    const deptGroups = g
      .selectAll('.dept-slice')
      .data(pieData)
      .enter()
      .append('g')
      .attr('class', 'dept-slice cursor-pointer')
      .style('transition', 'transform 260ms cubic-bezier(0.16, 1, 0.3, 1), opacity 200ms ease')
      .on('mouseenter', (event, d) => {
        setHoveredDept(d.data.department);
      })
      .on('mouseleave', () => {
        setHoveredDept(null);
      })
      .on('click', (event, d) => {
        // Toggle department filter and open inspector
        const nextDept = filter.department === d.data.department ? null : d.data.department;
        filter.setDepartment(nextDept);
        openInspector('cap_inspector', { department: d.data.department, caps: d.data.caps });
      });

    // Inner slice paths
    deptGroups
      .append('path')
      .attr('fill', (d, i) => getDeptColor(d.data.department, i))
      .attr('fill-opacity', (d) => {
        if (filter.department && filter.department !== d.data.department) return 0.25;
        if (hoveredDept && hoveredDept !== d.data.department) return 0.35;
        return 0.85;
      })
      .attr('stroke', 'var(--canvas)')
      .attr('stroke-width', 2)
      .transition()
      .duration(750)
      .delay((d, i) => i * 90)
      .attrTween('d', function (d) {
        const interpolate = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
        return function (t) {
          return arcDept(interpolate(t) as any) || '';
        };
      });

    // Draw Outer Ring (CAPs grouped by severity within each department slice)
    pieData.forEach((deptArc, i) => {
      const dept = deptArc.data;
      const deptSpan = deptArc.endAngle - deptArc.startAngle;
      let currentAngle = deptArc.startAngle;

      const severities: Severity[] = ['critical', 'high', 'medium', 'low'];
      severities.forEach((sev) => {
        const count = dept.severityCounts[sev] || 0;
        if (count === 0) return;

        const fraction = count / dept.total;
        const sevSpan = fraction * deptSpan;
        const start = currentAngle;
        const end = currentAngle + sevSpan;
        currentAngle = end;

        const capPath = g
          .append('path')
          .attr('class', 'cap-slice cursor-pointer')
          .attr('fill', severityColors[sev])
          .attr('fill-opacity', () => {
            if (filter.department && filter.department !== dept.department) return 0.25;
            if (hoveredDept && hoveredDept !== dept.department) return 0.35;
            return 0.95;
          })
          .attr('stroke', 'var(--canvas)')
          .attr('stroke-width', 1.5)
          .on('mouseenter', () => setHoveredDept(dept.department))
          .on('mouseleave', () => setHoveredDept(null))
          .on('click', () => {
            filter.setDepartment(dept.department);
            filter.setSeverity(sev);
            openInspector('cap_inspector', { department: dept.department, severity: sev, caps: dept.caps });
          });

        capPath
          .transition()
          .duration(750)
          .delay(i * 90 + 150)
          .attrTween('d', function () {
            const interpolate = d3.interpolate(
              { startAngle: deptArc.startAngle, endAngle: deptArc.startAngle, padAngle: 0.02 },
              { startAngle: start, endAngle: end, padAngle: 0.02 }
            );
            return function (t) {
              return arcCap(interpolate(t)) || '';
            };
          });
      });

      // Overdue outer arc: thin cinnabar outer arc for departments with overdue items (§ 3.4)
      if (dept.overdueCount > 0) {
        g.append('path')
          .attr('class', 'overdue-arc')
          .attr('fill', 'var(--accent-cinnabar)')
          .attr('fill-opacity', 0.9)
          .transition()
          .duration(800)
          .delay(i * 90 + 300)
          .attrTween('d', function () {
            const interpolate = d3.interpolate(
              { startAngle: deptArc.startAngle, endAngle: deptArc.startAngle },
              { startAngle: deptArc.startAngle, endAngle: deptArc.endAngle }
            );
            return function (t) {
              return arcOverdue(interpolate(t)) || '';
            };
          });
      }
    });

    // Center hub circle
    g.append('circle')
      .attr('r', innerRadiusHub)
      .attr('fill', 'var(--surface-elevated)')
      .attr('stroke', 'var(--border-hairline)')
      .attr('stroke-width', 1)
      .attr('class', 'shadow-xs');
  }, [departments, filter.department, hoveredDept]);

  // Center display data
  const currentDeptData = hoveredDept
    ? capDeptMap[hoveredDept]
    : filter.department
    ? capDeptMap[filter.department]
    : null;

  const displayCount = currentDeptData ? currentDeptData.total : totalCapCount;
  const displayOpen = currentDeptData
    ? currentDeptData.caps.filter((c) => c.status !== 'Closed').length
    : openCapCount;
  const displayOverdue = currentDeptData
    ? currentDeptData.overdueCount
    : overdueCapCount;

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-6 shadow-apple space-y-6">
      {/* Header and Filter Reset */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
              Assurance Remediation Radar
            </span>
            {filter.hasActiveFilters() && (
              <span className="px-2 py-0.5 rounded-full text-apple-11 font-medium bg-accent-subtle text-accent border border-accent">
                Cross-Filtered
              </span>
            )}
          </div>
          <h3 className="text-apple-17 font-bold text-primary mt-1">
            Corrective Action Plan (CAP) Radial Tracker
          </h3>
          <p className="text-apple-12 text-secondary mt-0.5">
            Inner ring: Departments • Outer ring: Actions by severity • Red arc: Overdue remediation
          </p>
        </div>

        {filter.hasActiveFilters() && (
          <button
            onClick={() => filter.clearFilters()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-surface-elevated hover:bg-surface-hover border border-hairline text-apple-12 font-medium text-secondary hover:text-primary transition-colors shadow-xs"
          >
            <RotateCcw className="w-3.5 h-3.5 stroke-[1.5]" />
            <span>Clear filters</span>
          </button>
        )}
      </div>

      {/* Main Grid: D3 Radial Chart + Side Legend Rail */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Radial SVG Container with Center Hub */}
        <div className="md:col-span-7 flex justify-center relative select-none">
          <svg
            ref={svgRef}
            className="w-[320px] h-[320px] max-w-full drop-shadow-xs"
            role="img"
            aria-label="CAP Radial Remediation Distribution"
          />

          {/* HTML Overlay for Center Hub Typography (crisp text, never blurred SVG text) */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
            <span className="text-apple-11 font-medium text-secondary truncate max-w-[100px]">
              {currentDeptData ? currentDeptData.department : 'Total Portfolio'}
            </span>
            <span className="font-serif-numeral text-apple-32 font-bold text-primary tabular-nums leading-none my-0.5">
              {displayCount}
            </span>
            <span className="text-apple-11 text-secondary">
              {displayOpen} open CAPs
            </span>
            {displayOverdue > 0 && (
              <span className="text-apple-11 font-bold text-cinnabar flex items-center gap-1 mt-0.5">
                <AlertCircle className="w-3 h-3 stroke-[2]" />
                <span>{displayOverdue} overdue</span>
              </span>
            )}
          </div>
        </div>

        {/* Legend Rail beside chart (§ 3.4 requirement) */}
        <div className="md:col-span-5 space-y-2 border-l border-hairline pl-4">
          <div className="text-apple-11 text-tertiary uppercase font-semibold tracking-wider pb-1">
            Remediation by Business Unit
          </div>
          <div className="space-y-1.5 max-h-[260px] overflow-y-auto pr-1">
            {departments.map((dept, idx) => {
              const isSelected = filter.department === dept.department;
              const isHovered = hoveredDept === dept.department;
              const color = getDeptColor(dept.department, idx);

              return (
                <button
                  key={dept.department}
                  onClick={() => {
                    const next = isSelected ? null : dept.department;
                    filter.setDepartment(next);
                    openInspector('cap_inspector', { department: dept.department, caps: dept.caps });
                  }}
                  onMouseEnter={() => setHoveredDept(dept.department)}
                  onMouseLeave={() => setHoveredDept(null)}
                  className={`w-full text-left p-2.5 rounded-xl transition-colors flex items-center justify-between border ${
                    isSelected
                      ? 'bg-accent-subtle border-accent text-accent'
                      : isHovered
                      ? 'bg-surface-hover border-hairline text-primary'
                      : 'bg-surface-elevated border-hairline text-secondary hover:text-primary'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className="w-3 h-3 rounded-full shrink-0 shadow-xs"
                      style={{ backgroundColor: color }}
                    />
                    <span className="text-apple-12 font-medium truncate">
                      {dept.department}
                    </span>
                    {dept.overdueCount > 0 && (
                      <span
                        className="w-2 h-2 rounded-full bg-cinnabar shrink-0 animate-pulse"
                        title={`${dept.overdueCount} overdue actions`}
                      />
                    )}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {dept.overdueCount > 0 && (
                      <span className="text-apple-11 font-semibold text-cinnabar tabular-nums">
                        {dept.overdueCount} ovd
                      </span>
                    )}
                    <span className="text-apple-12 font-semibold text-primary tabular-nums">
                      {dept.total}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Severity Swatches Guide */}
          <div className="pt-3 border-t border-hairline flex items-center justify-between text-apple-11 text-secondary">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-cinnabar" /> Critical
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber" /> High
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-verdigris" /> Medium
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-surface-sunken border border-hairline" /> Low
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/dashboard/CapRadialTracker.tsx', cap_radial_tsx)

cap_radial_test_tsx = """import React from 'react';
import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import { CapRadialTracker } from './CapRadialTracker';
import { AppProvider } from '../../context/AppContext';
import { ThemeProvider } from '../../context/ThemeContext';
import { AuditCapItem } from '../../types';

describe('§ 3.4 CAP Radial Tracker & Legend Rail', () => {
  const mockCapDeptMap = {
    Treasury: {
      department: 'Treasury',
      total: 5,
      overdueCount: 1,
      caps: [
        {
          id: 'CAP-001',
          title: 'Cash Pipeline STP',
          action: 'Deploy automated SWIFT parser',
          owner: 'David Miller',
          department: 'Treasury',
          severity: 'critical' as const,
          dueDate: '2026-09-15',
          agingDays: 45,
          status: 'Overdue' as const,
          retestStatus: 'Not tested' as const,
          approvalStatus: 'Approved by CIA' as const,
          originatingReport: 'Q3 Report',
          engagementId: 'eng-1',
          entityId: 'ent-1',
          universeId: 'u-1',
        },
      ],
      severityCounts: { critical: 1, high: 2, medium: 2, low: 0 },
    },
    Trading: {
      department: 'Trading',
      total: 3,
      overdueCount: 0,
      caps: [],
      severityCounts: { critical: 0, high: 2, medium: 1, low: 0 },
    },
  };

  it('renders radial tracker SVG and center hub statistics', () => {
    render(
      <ThemeProvider>
        <AppProvider>
          <CapRadialTracker
            capDeptMap={mockCapDeptMap}
            totalCapCount={8}
            openCapCount={7}
            overdueCapCount={1}
          />
        </AppProvider>
      </ThemeProvider>
    );

    // Assert Center Hub values
    expect(screen.getByText('8')).toBeDefined();
    expect(screen.getByText('7 open CAPs')).toBeDefined();
    expect(screen.getByText('1 overdue')).toBeDefined();

    // Assert Legend Rail items
    expect(screen.getByText('Treasury')).toBeDefined();
    expect(screen.getByText('Trading')).toBeDefined();
  });
});
"""
write_both('src/components/dashboard/CapRadialTracker.test.tsx', cap_radial_test_tsx)
