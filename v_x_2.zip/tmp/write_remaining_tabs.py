import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Wrote {path}")

audit_plan_tsx = """import React, { useState } from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import {
  Folder,
  FileText,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  CheckCircle2,
  Clock,
  ChevronRight,
} from '../common/Icons';

export const AuditPlanTab: React.FC = () => {
  const {
    filteredEngagements,
    scopedControls,
    scopedWorkpapers,
    can,
    currentUser,
  } = useScopedData();
  const {
    selectedEngagementId,
    setSelectedEngagementId,
    setSelectedWorkpaperId,
    setActiveTab,
    signOffEngagement,
    reopenEngagement,
    openInspector,
  } = useApp();

  const [reopenNote, setReopenNote] = useState('');
  const [reopeningId, setReopeningId] = useState<string | null>(null);

  const selectedEngagement =
    filteredEngagements.find((e) => e.id === selectedEngagementId) ||
    filteredEngagements[0];

  const engagementControls = selectedEngagement
    ? scopedControls.filter((c) => c.engagementId === selectedEngagement.id)
    : [];

  const engagementWorkpapers = selectedEngagement
    ? scopedWorkpapers.filter((w) => w.engagementId === selectedEngagement.id)
    : [];

  const handleSignOff = async (engId: string) => {
    await signOffEngagement(engId);
  };

  const handleReopenSubmit = async (engId: string) => {
    if (reopenNote.trim().length < 10) {
      alert('Reopening justification must be at least 10 characters.');
      return;
    }
    await reopenEngagement(engId, reopenNote);
    setReopeningId(null);
    setReopenNote('');
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-hairline pb-4">
        <div>
          <h1 className="text-apple-28 font-bold text-primary tracking-tight">Audit Engagements &amp; Plan</h1>
          <p className="text-apple-15 text-secondary mt-1">
            Scoped audit portfolio, testing roadmaps, and reviewer attestation sign-offs
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Engagement List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-apple-12 font-semibold text-secondary uppercase tracking-wider px-2">
            Active Engagements ({filteredEngagements.length})
          </div>

          {filteredEngagements.length === 0 ? (
            <div className="p-8 text-center bg-surface border border-hairline rounded-2xl text-secondary text-apple-13">
              No engagements within your scope match the current filter.
            </div>
          ) : (
            filteredEngagements.map((eng) => {
              const isSelected = selectedEngagement?.id === eng.id;
              const isLocked = eng.isLocked;

              const previewData = {
                title: eng.title,
                category: `Stage: ${eng.stage.toUpperCase()}`,
                subtitle: `Progress: ${eng.completionPercent}% • Due: ${eng.dueDate}`,
                status: isLocked ? 'Sealed ✓' : eng.status.replace('_', ' ').toUpperCase(),
                statusType: isLocked ? ('verdigris' as const) : ('amber' as const),
                owner: eng.leadAuditorId,
                dueDate: eng.dueDate,
                metrics: [
                  { label: 'Start Date', value: eng.periodStart },
                  { label: 'Reviewer', value: eng.reviewerId },
                ],
                hint: 'Click to select and view testing controls',
              };

              return (
                <HoverPreview key={eng.id} content={previewData} className="w-full">
                  <div
                    onClick={() => setSelectedEngagementId(eng.id)}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-surface border-accent shadow-apple'
                        : 'bg-surface hover:bg-surface-hover border-hairline'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
                        {eng.stage}
                      </span>
                      <div className="flex items-center gap-2">
                        {isLocked ? (
                          <span className="flex items-center gap-1 text-apple-11 font-semibold text-verdigris bg-verdigris-subtle px-2 py-0.5 rounded border border-verdigris">
                            <Lock className="w-3 h-3 stroke-[1.5]" />
                            <span>Sealed ✓</span>
                          </span>
                        ) : (
                          <span className="text-apple-11 font-medium text-amber bg-amber-subtle px-2 py-0.5 rounded">
                            {eng.status.replace('_', ' ')}
                          </span>
                        )}
                      </div>
                    </div>

                    <h3 className="text-apple-15 font-semibold text-primary">{eng.title}</h3>

                    <div className="mt-4 pt-3 border-t border-hairline flex items-center justify-between text-apple-11 text-secondary">
                      <span>Due {eng.dueDate}</span>
                      <span className="tabular-nums font-semibold text-primary">
                        {eng.completionPercent}% Complete
                      </span>
                    </div>
                  </div>
                </HoverPreview>
              );
            })
          )}
        </div>

        {/* Right: Selected Engagement Details, Controls & Workpapers */}
        {selectedEngagement && (
          <div className="lg:col-span-7 bg-surface border border-hairline rounded-2xl p-6 shadow-apple space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 border-b border-hairline pb-5">
              <div>
                <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
                  Audit Execution Target
                </span>
                <h2 className="text-apple-20 font-bold text-primary mt-1">
                  {selectedEngagement.title}
                </h2>
                <div className="flex flex-wrap items-center gap-4 text-apple-12 text-secondary mt-2">
                  <span>Period: {selectedEngagement.periodStart} → {selectedEngagement.periodEnd}</span>
                  <span>•</span>
                  <span>Due: {selectedEngagement.dueDate}</span>
                </div>
              </div>

              {/* Action Buttons: Sign-off & Reopen */}
              <div className="flex items-center gap-2 shrink-0">
                {!selectedEngagement.isLocked ? (
                  can('sign_off', {
                    leadAuditorId: selectedEngagement.leadAuditorId,
                    preparerId: selectedEngagement.leadAuditorId,
                  }).allowed && (
                    <button
                      onClick={() => handleSignOff(selectedEngagement.id)}
                      className="px-4 py-2 bg-accent text-white font-medium text-apple-12 rounded-xl hover:opacity-90 transition-opacity shadow-xs"
                    >
                      Sign-off &amp; Seal
                    </button>
                  )
                ) : (
                  <div>
                    {reopeningId === selectedEngagement.id ? (
                      <div className="flex flex-col gap-2 p-3 bg-surface-elevated border border-hairline rounded-xl w-72">
                        <textarea
                          value={reopenNote}
                          onChange={(e) => setReopenNote(e.target.value)}
                          placeholder="Reopening justification (min 10 chars)..."
                          className="w-full text-apple-12 p-2 bg-surface border border-hairline rounded-lg text-primary outline-none"
                          rows={2}
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setReopeningId(null)}
                            className="px-2.5 py-1 text-apple-11 text-secondary hover:text-primary"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleReopenSubmit(selectedEngagement.id)}
                            className="px-3 py-1 bg-cinnabar text-white font-medium text-apple-11 rounded-lg hover:opacity-90"
                          >
                            Confirm Reopen
                          </button>
                        </div>
                      </div>
                    ) : (
                      can('reopen').allowed && (
                        <button
                          onClick={() => setReopeningId(selectedEngagement.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-surface-elevated hover:bg-surface-hover text-secondary border border-hairline text-apple-12 font-medium rounded-xl transition-colors"
                        >
                          <Unlock className="w-3.5 h-3.5 stroke-[1.5]" />
                          <span>Reopen Engagement</span>
                        </button>
                      )
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Controls in this engagement */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
                  Controls Matrix ({engagementControls.length})
                </h4>
              </div>

              <div className="space-y-3">
                {engagementControls.map((ctrl) => (
                  <div
                    key={ctrl.id}
                    className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-apple-12 font-semibold text-primary">
                        {ctrl.code}
                      </span>
                      <span
                        className={`text-apple-11 font-medium px-2 py-0.5 rounded capitalize ${
                          ctrl.effectiveness === 'effective'
                            ? 'text-verdigris bg-verdigris-subtle'
                            : 'text-amber bg-amber-subtle'
                        }`}
                      >
                        {ctrl.effectiveness.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="text-apple-13 font-semibold text-primary">{ctrl.title}</div>
                    <p className="text-apple-12 text-secondary">{ctrl.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Workpapers in this engagement */}
            <div className="space-y-4 pt-4 border-t border-hairline">
              <div className="flex items-center justify-between">
                <h4 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
                  Associated Working Papers ({engagementWorkpapers.length})
                </h4>
              </div>

              <div className="space-y-2.5">
                {engagementWorkpapers.map((wp) => (
                  <div
                    key={wp.id}
                    onClick={() => {
                      setSelectedWorkpaperId(wp.id);
                      setActiveTab('workbench');
                    }}
                    className="p-3.5 rounded-xl bg-surface-elevated hover:bg-surface-hover border border-hairline cursor-pointer transition-colors flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="w-4 h-4 text-accent stroke-[1.5]" />
                      <div>
                        <div className="text-apple-13 font-medium text-primary">
                          {wp.refCode} • {wp.title}
                        </div>
                        <div className="text-apple-11 text-secondary">
                          {wp.sampleCount} Samples Tested • {wp.exceptionsIdentified} Exceptions
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {wp.sealed && (
                        <span className="text-apple-11 font-medium text-verdigris bg-verdigris-subtle px-2 py-0.5 rounded border border-verdigris">
                          Sealed ✓
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-secondary stroke-[1.5]" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
"""
write_file('/app/applet/src/components/plan/AuditPlanTab.tsx', audit_plan_tsx)
write_file('/app/applet/docs/reference/v1/src/components/plan/AuditPlanTab.tsx', audit_plan_tsx)

issues_reg_tsx = """import React, { useState } from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useFilterStore } from '../../context/FilterStore';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import { AuditIssue, Severity } from '../../types';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Filter,
  Search,
  Plus,
  ArrowRight,
} from '../common/Icons';

export const IssuesRegisterTab: React.FC = () => {
  const { filteredIssues, can, currentUser } = useScopedData();
  const filter = useFilterStore();
  const { openInspector } = useApp();

  const getSeverityBadge = (severity: Severity) => {
    switch (severity) {
      case 'critical':
        return 'text-cinnabar bg-cinnabar-subtle border-cinnabar';
      case 'high':
        return 'text-amber bg-amber-subtle border-amber';
      case 'medium':
        return 'text-primary bg-surface-elevated';
      default:
        return 'text-secondary bg-surface-hover';
    }
  };

  const getStatusBadge = (status: AuditIssue['status']) => {
    switch (status) {
      case 'closed':
      case 'remediated':
        return 'text-verdigris bg-verdigris-subtle';
      case 'overdue':
        return 'text-cinnabar bg-cinnabar-subtle';
      default:
        return 'text-secondary bg-surface-hover';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-hairline pb-4">
        <div>
          <h1 className="text-apple-28 font-bold text-primary tracking-tight">Audit Findings &amp; Issues Register</h1>
          <p className="text-apple-15 text-secondary mt-1">
            Tracking remedial commitments, management action plans, and regulatory observations
          </p>
        </div>

        {/* Action Gate: only non-auditees can raise observations */}
        {can('raise_observation').allowed && (
          <button
            onClick={() => openInspector('observation', null)}
            className="flex items-center gap-2 px-4 py-2 bg-accent text-white font-medium text-apple-13 rounded-xl hover:opacity-90 transition-opacity shadow-xs"
          >
            <Plus className="w-4 h-4 stroke-[1.5]" />
            <span>Raise Finding</span>
          </button>
        )}
      </div>

      {/* Filter / Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-surface p-4 rounded-2xl border border-hairline shadow-apple">
        <div className="flex items-center gap-3 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-secondary stroke-[1.5]" />
          <input
            type="text"
            value={filter.searchQuery}
            onChange={(e) => filter.setSearchQuery(e.target.value)}
            placeholder="Search findings by title, department, description..."
            className="w-full bg-transparent text-apple-13 text-primary placeholder:text-tertiary outline-none border-none"
          />
        </div>

        {/* Quick Severity Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-surface-elevated rounded-xl border border-hairline">
          {['all', 'critical', 'high', 'medium'].map((sev) => {
            const isSelected = sev === 'all' ? !filter.severity : filter.severity === sev;
            return (
              <button
                key={sev}
                onClick={() => filter.setSeverity(sev === 'all' ? null : sev)}
                className={`px-3 py-1 text-apple-12 font-medium rounded-lg capitalize transition-colors ${
                  isSelected
                    ? 'bg-surface text-primary shadow-xs'
                    : 'text-secondary hover:text-primary'
                }`}
              >
                {sev}
              </button>
            );
          })}
        </div>
      </div>

      {/* Issues Table */}
      <div className="bg-surface border border-hairline rounded-2xl shadow-apple overflow-hidden">
        <div className="grid grid-cols-12 px-6 py-3 border-b border-hairline bg-surface-elevated text-apple-11 font-semibold text-secondary uppercase tracking-wider">
          <div className="col-span-5">Issue / Finding</div>
          <div className="col-span-2">Department</div>
          <div className="col-span-2">Severity</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-1 text-right">Due Date</div>
        </div>

        <div className="divide-y divide-hairline">
          {filteredIssues.length === 0 ? (
            <div className="py-12 text-center text-apple-13 text-secondary">
              No audit issues match your current scoped filters.
            </div>
          ) : (
            filteredIssues.map((issue) => {
              const previewData = {
                title: issue.title,
                category: `${issue.department} • Finding #${issue.id}`,
                subtitle: issue.description,
                status: issue.severity.toUpperCase(),
                statusType:
                  issue.severity === 'critical'
                    ? ('cinnabar' as const)
                    : issue.severity === 'high'
                    ? ('amber' as const)
                    : ('neutral' as const),
                dueDate: issue.dueDate,
                owner: issue.ownerId,
                hint: 'Click to inspect finding details',
              };

              return (
                <HoverPreview key={issue.id} content={previewData} className="w-full">
                  <div
                    onClick={() => openInspector('observation', { issue })}
                    className="grid grid-cols-12 px-6 py-4 items-center hover:bg-surface-hover transition-colors cursor-pointer"
                  >
                    <div className="col-span-5 pr-4">
                      <div className="text-apple-13 font-semibold text-primary truncate">
                        {issue.title}
                      </div>
                      <div className="text-apple-12 text-secondary line-clamp-1 mt-0.5">
                        {issue.description}
                      </div>
                    </div>
                    <div className="col-span-2 text-apple-12 font-medium text-secondary">
                      {issue.department}
                    </div>
                    <div className="col-span-2">
                      <span
                        className={`px-2 py-0.5 rounded text-apple-11 font-semibold uppercase ${getSeverityBadge(
                          issue.severity
                        )}`}
                      >
                        {issue.severity}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <span
                        className={`px-2 py-0.5 rounded text-apple-11 font-medium capitalize ${getStatusBadge(
                          issue.status
                        )}`}
                      >
                        {issue.status.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="col-span-1 text-right text-apple-12 text-primary font-medium tabular-nums">
                      {issue.dueDate}
                    </div>
                  </div>
                </HoverPreview>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
"""
write_file('/app/applet/src/components/issues/IssuesRegisterTab.tsx', issues_reg_tsx)
write_file('/app/applet/docs/reference/v1/src/components/issues/IssuesRegisterTab.tsx', issues_reg_tsx)

obs_drilldown_tsx = """import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { AuditObservation, Severity } from '../../types';
import { AlertCircle, CheckCircle2, Zap } from '../common/Icons';

interface ObservationDrilldownProps {
  data?: {
    observation?: AuditObservation;
    issue?: any;
    workpaper?: any;
  } | null;
  onClose?: () => void;
}

export const ObservationDrilldown: React.FC<ObservationDrilldownProps> = ({ data, onClose }) => {
  const { addObservation, closeInspector, openInspector } = useApp();
  const { scopedWorkpapers, scopedEntities } = useScopedData();

  const existingObs = data?.observation;
  const isEditingOrCreating = !existingObs;

  const [title, setTitle] = useState(existingObs?.title || '');
  const [condition, setCondition] = useState(existingObs?.condition || '');
  const [criteria, setCriteria] = useState(existingObs?.criteria || '');
  const [cause, setCause] = useState(existingObs?.cause || '');
  const [consequence, setConsequence] = useState(existingObs?.consequence || '');
  const [recommendation, setRecommendation] = useState(existingObs?.recommendation || '');
  const [severity, setSeverity] = useState<Severity>(existingObs?.severity || 'high');
  const [selectedWpId, setSelectedWpId] = useState(
    data?.workpaper?.id || scopedWorkpapers[0]?.id || ''
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !condition.trim()) {
      alert('Please provide title and condition.');
      return;
    }

    const targetWp = scopedWorkpapers.find((w) => w.id === selectedWpId) || scopedWorkpapers[0];
    if (!targetWp) {
      alert('No working paper available in current scope.');
      return;
    }

    await addObservation({
      workpaperId: targetWp.id,
      controlId: targetWp.controlId,
      entityId: targetWp.entityId,
      universeId: targetWp.universeId,
      title,
      condition,
      criteria,
      cause,
      consequence,
      recommendation,
      severity,
      status: 'open',
    });

    closeInspector();
  };

  if (existingObs) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <span className="text-apple-11 font-semibold text-cinnabar bg-cinnabar-subtle px-2.5 py-1 rounded uppercase">
            {existingObs.severity} Severity Finding
          </span>
          {existingObs.ruleId && (
            <button
              onClick={() => openInspector('red_thread')}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-apple-11 font-medium bg-accent-subtle text-accent hover:opacity-80 transition-opacity"
            >
              <Zap className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Trace Red Thread</span>
            </button>
          )}
        </div>

        <div>
          <h3 className="text-apple-20 font-bold text-primary">{existingObs.title}</h3>
          <div className="text-apple-11 text-secondary mt-1">
            Recorded {new Date(existingObs.createdAt).toLocaleString()} by {existingObs.raisedBy}
          </div>
        </div>

        <div className="space-y-4 text-apple-13">
          <div className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-1">
            <span className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
              1. Condition (What was found)
            </span>
            <p className="text-primary leading-relaxed">{existingObs.condition}</p>
          </div>

          <div className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-1">
            <span className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
              2. Criteria (What should be)
            </span>
            <p className="text-primary leading-relaxed">{existingObs.criteria}</p>
          </div>

          <div className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-1">
            <span className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
              3. Root Cause
            </span>
            <p className="text-primary leading-relaxed">{existingObs.cause}</p>
          </div>

          <div className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-1">
            <span className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
              4. Consequence / Risk Impact
            </span>
            <p className="text-primary leading-relaxed">{existingObs.consequence}</p>
          </div>

          <div className="p-4 rounded-xl bg-surface-elevated border border-hairline space-y-1">
            <span className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
              5. Auditor Recommendation
            </span>
            <p className="text-primary leading-relaxed">{existingObs.recommendation}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="border-b border-hairline pb-3">
        <h3 className="text-apple-15 font-semibold text-primary">Raise Formal Audit Finding</h3>
        <p className="text-apple-12 text-secondary mt-0.5">
          Standardized 5C observation structure committed to hash ledger
        </p>
      </div>

      <div className="space-y-1.5">
        <label className="text-apple-12 font-medium text-secondary">Target Working Paper</label>
        <select
          value={selectedWpId}
          onChange={(e) => setSelectedWpId(e.target.value)}
          className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
        >
          {scopedWorkpapers.map((w) => (
            <option key={w.id} value={w.id}>
              {w.refCode} • {w.title}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-1.5">
        <label className="text-apple-12 font-medium text-secondary">Finding Title</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Brief executive summary of deficiency..."
          className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <label className="text-apple-12 font-medium text-secondary">Severity</label>
          <select
            value={severity}
            onChange={(e) => setSeverity(e.target.value as Severity)}
            className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
          >
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-apple-12 font-medium text-secondary">Condition (Observation)</label>
        <textarea
          rows={2}
          value={condition}
          onChange={(e) => setCondition(e.target.value)}
          placeholder="What specific deficiency was observed?"
          className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-apple-12 font-medium text-secondary">Criteria</label>
        <textarea
          rows={2}
          value={criteria}
          onChange={(e) => setCriteria(e.target.value)}
          placeholder="Policy clause, regulation, or standard breached..."
          className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-apple-12 font-medium text-secondary">Recommendation</label>
        <textarea
          rows={2}
          value={recommendation}
          onChange={(e) => setRecommendation(e.target.value)}
          placeholder="Actionable remedial steps for management..."
          className="w-full p-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-13 text-primary outline-none"
        />
      </div>

      <div className="pt-4 flex justify-end gap-3">
        <button
          type="button"
          onClick={closeInspector}
          className="px-4 py-2 text-apple-12 text-secondary hover:text-primary"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-5 py-2 bg-accent text-white font-medium text-apple-12 rounded-xl hover:opacity-90 transition-opacity shadow-xs"
        >
          Commit Finding
        </button>
      </div>
    </form>
  );
};
"""
write_file('/app/applet/src/components/issues/ObservationDrilldown.tsx', obs_drilldown_tsx)
write_file('/app/applet/docs/reference/v1/src/components/issues/ObservationDrilldown.tsx', obs_drilldown_tsx)

# 5 files with Lucide-react: write unchanged to docs/reference/v1, and write fixed to src/

universe_tab_ref = """import React from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import { AuditEntity } from '../../types';
import { Shield, AlertTriangle, Layers, ArrowRight, Activity } from 'lucide-react';

export const AuditUniverseTab: React.FC = () => {
  const { scopedUniverses, scopedEntities, selectedUniverseId } = useScopedData();
  const { openInspector } = useApp();

  const currentUniverse =
    scopedUniverses.find((u) => u.id === selectedUniverseId) || scopedUniverses[0];

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'high':
      case 'critical':
        return 'text-cinnabar bg-cinnabar-subtle border-cinnabar';
      case 'medium':
        return 'text-amber bg-amber-subtle border-amber';
      default:
        return 'text-verdigris bg-verdigris-subtle border-verdigris';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
      {/* Editorial Header */}
      <div className="border-b border-hairline pb-6">
        <span className="text-apple-12 font-medium tracking-wide uppercase text-accent">
          Strategic Internal Risk Assessment (SIRA)
        </span>
        <h1 className="text-apple-28 font-bold text-primary tracking-tight mt-1">
          Audit Universe &amp; Entity Heatmap
        </h1>
        <p className="text-apple-15 text-secondary mt-1">
          {currentUniverse ? (
            <span>
              Universe:{' '}
              <strong className="text-primary font-semibold">{currentUniverse.name}</strong> (
              {currentUniverse.code}) • {scopedEntities.length} Auditable Entities Scoped
            </span>
          ) : (
            'Scoped auditable entities and quantitative risk profiles'
          )}
        </p>
      </div>

      {/* Entity Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scopedEntities.map((entity) => {
          const previewData = {
            title: entity.name,
            category: `Department: ${entity.department} • Code: ${entity.code}`,
            subtitle: `Head of Department: ${entity.headOfDepartment}`,
            status: `SIRA Score: ${entity.siraScore}/100`,
            statusType:
              entity.siraScore >= 75
                ? ('cinnabar' as const)
                : entity.siraScore >= 50
                ? ('amber' as const)
                : ('verdigris' as const),
            metrics: [
              { label: 'Inherent Risk', value: entity.inherentRisk.toUpperCase() },
              { label: 'Residual Risk', value: entity.residualRisk.toUpperCase() },
              { label: 'Controls Active', value: entity.controlsCount },
              { label: 'Last Audit', value: entity.lastAuditDate },
            ],
            hint: 'Click to open SIRA factor matrix & RCM',
          };

          return (
            <HoverPreview key={entity.id} content={previewData} className="w-full">
              <div
                onClick={() => openInspector('sira', { entity })}
                className="p-6 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
                      {entity.department}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-apple-11 font-semibold uppercase ${getRiskBadge(
                        entity.inherentRisk
                      )}`}
                    >
                      {entity.inherentRisk} Risk
                    </span>
                  </div>
                  <h3 className="text-apple-15 font-semibold text-primary">{entity.name}</h3>
                  <p className="text-apple-12 text-secondary mt-1">
                    Head: {entity.headOfDepartment}
                  </p>
                </div>

                <div className="pt-4 border-t border-hairline flex items-center justify-between text-apple-12">
                  <div className="flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-accent stroke-[1.5]" />
                    <span className="text-secondary">SIRA Index:</span>
                    <span className="font-semibold text-primary tabular-nums">
                      {entity.siraScore}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-accent font-medium text-apple-11">
                    <span>Inspect RCM</span>
                    <ArrowRight className="w-3.5 h-3.5 stroke-[1.5]" />
                  </div>
                </div>
              </div>
            </HoverPreview>
          );
        })}
      </div>
    </div>
  );
};
"""
write_file('/app/applet/docs/reference/v1/src/components/universe/AuditUniverseTab.tsx', universe_tab_ref)
write_file('/app/applet/src/components/universe/AuditUniverseTab.tsx', universe_tab_ref.replace("from 'lucide-react'", "from '../common/Icons'"))

sira_rcm_ref = """import React from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { AuditEntity } from '../../types';
import { ShieldAlert, Activity, CheckCircle2, Sliders } from 'lucide-react';

interface SiraRcmProps {
  entity: AuditEntity;
  onClose?: () => void;
}

export const EntitySiraRcmModal: React.FC<SiraRcmProps> = ({ entity, onClose }) => {
  const { scopedControls } = useScopedData();
  const entityControls = scopedControls.filter((c) => c.entityId === entity.id);

  return (
    <div className="space-y-6">
      {/* SIRA Quantitative Breakdown */}
      <div className="p-5 rounded-2xl bg-surface-elevated border border-hairline space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
              Composite Risk Score
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-serif-numeral text-apple-40 font-bold text-primary tabular-nums">
                {entity.siraScore}
              </span>
              <span className="text-apple-13 text-secondary font-medium">/ 100 SIRA Index</span>
            </div>
          </div>
          <span className="px-3 py-1 rounded-xl text-apple-12 font-bold uppercase text-cinnabar bg-cinnabar-subtle border border-cinnabar">
            {entity.inherentRisk} Inherent
          </span>
        </div>

        {/* Factors */}
        <div className="grid grid-cols-2 gap-3 pt-3 border-t border-hairline text-apple-12">
          <div>
            <span className="text-tertiary">Department: </span>
            <span className="text-primary font-medium">{entity.department}</span>
          </div>
          <div>
            <span className="text-tertiary">Head: </span>
            <span className="text-primary font-medium">{entity.headOfDepartment}</span>
          </div>
          <div>
            <span className="text-tertiary">Residual Rating: </span>
            <span className="text-primary font-medium uppercase">{entity.residualRisk}</span>
          </div>
          <div>
            <span className="text-tertiary">Last Audit: </span>
            <span className="text-primary font-medium tabular-nums">{entity.lastAuditDate}</span>
          </div>
        </div>
      </div>

      {/* Risk and Control Matrix (RCM) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
            Risk &amp; Control Matrix ({entityControls.length} Controls)
          </h4>
        </div>

        <div className="space-y-3">
          {entityControls.length === 0 ? (
            <div className="p-6 text-center text-apple-12 text-secondary bg-surface-elevated rounded-xl">
              No controls currently indexed for this entity.
            </div>
          ) : (
            entityControls.map((ctrl) => (
              <div
                key={ctrl.id}
                className="p-4 rounded-xl bg-surface border border-hairline space-y-2 hover:bg-surface-hover transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-apple-12 font-bold text-accent">
                    {ctrl.code}
                  </span>
                  <span
                    className={`text-apple-11 font-semibold px-2 py-0.5 rounded capitalize ${
                      ctrl.effectiveness === 'effective'
                        ? 'text-verdigris bg-verdigris-subtle'
                        : 'text-amber bg-amber-subtle'
                    }`}
                  >
                    {ctrl.effectiveness.replace('_', ' ')}
                  </span>
                </div>
                <div className="text-apple-13 font-semibold text-primary">{ctrl.title}</div>
                <p className="text-apple-12 text-secondary">{ctrl.description}</p>
                <div className="flex items-center gap-4 text-apple-11 text-tertiary pt-2 border-t border-hairline">
                  <span>Type: {ctrl.controlType}</span>
                  <span>•</span>
                  <span>Frequency: {ctrl.frequency}</span>
                  <span>•</span>
                  <span>Sample Size: {ctrl.sampleSize}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
"""
write_file('/app/applet/docs/reference/v1/src/components/universe/EntitySiraRcmModal.tsx', sira_rcm_ref)
write_file('/app/applet/src/components/universe/EntitySiraRcmModal.tsx', sira_rcm_ref.replace("from 'lucide-react'", "from '../common/Icons'"))

cmt_history_ref = """import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { ReviewComment, WorkingPaper } from '../../types';
import {
  MessageSquare,
  Send,
  CheckCircle2,
  FileText,
  ExternalLink,
  Search,
  Filter,
  Clock,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface CommentPanelProps {
  data?: {
    comment?: ReviewComment;
    workpaper?: WorkingPaper;
  } | null;
  onClose?: () => void;
}

export const CommentHistoryPanel: React.FC<CommentPanelProps> = ({ data, onClose }) => {
  const { currentUser, openInspector } = useApp();
  const { scopedComments, scopedWorkpapers, scopedEngagements } = useScopedData();

  // If a single comment was passed in data, single mode; otherwise full history across all cycles (§ 3.5)
  const isSingleCommentMode = Boolean(data?.comment);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'cleared'>('all');
  const [cycleFilter, setCycleFilter] = useState<string>('all');
  const [expandedCommentId, setExpandedCommentId] = useState<string | null>(
    data?.comment ? data.comment.id : null
  );

  // Single comment reply state
  const [replyText, setReplyText] = useState('');

  // Cycle assignment mock based on comment date for multi-cycle history
  const getCycleTag = (dateStr: string) => {
    const d = new Date(dateStr);
    const m = d.getMonth();
    const y = d.getFullYear();
    if (y < 2026) return '2025 Annual Cycle';
    if (m >= 6 && m <= 8) return 'Q3 2026 Cycle';
    if (m >= 3 && m <= 5) return 'Q2 2026 Cycle';
    return 'Q1 2026 Cycle';
  };

  const handleSendReply = (cmt: ReviewComment) => {
    if (!replyText.trim()) return;

    const newReply = {
      id: `rep-${Date.now()}`,
      authorName: currentUser.name,
      text: replyText.trim(),
      createdAt: new Date().toISOString(),
    };

    if (!cmt.replies) {
      cmt.replies = [];
    }
    cmt.replies.push(newReply);
    setReplyText('');
  };

  // Filtered comments for full history mode
  const filteredComments = scopedComments.filter((c) => {
    if (statusFilter !== 'all') {
      if (statusFilter === 'cleared' && c.status !== 'cleared') return false;
      if (statusFilter === 'open' && c.status === 'cleared') return false;
    }
    const cycle = getCycleTag(c.createdAt);
    if (cycleFilter !== 'all' && cycle !== cycleFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesText = c.text.toLowerCase().includes(q);
      const matchesAuthor = c.authorName.toLowerCase().includes(q);
      const wp = scopedWorkpapers.find((w) => w.id === c.workpaperId);
      const matchesWp = wp ? wp.refCode.toLowerCase().includes(q) || wp.title.toLowerCase().includes(q) : false;
      if (!matchesText && !matchesAuthor && !matchesWp) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-hairline pb-4">
        <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
          {isSingleCommentMode ? 'Reviewer Query & Dialogue' : 'Four-Eyes Assurance Audit Trail'}
        </span>
        <h3 className="text-apple-20 font-bold text-primary mt-1">
          {isSingleCommentMode
            ? `Workpaper ${data?.workpaper?.refCode || data?.comment?.workpaperId}`
            : 'Comprehensive Review Comment History'}
        </h3>
        <p className="text-apple-12 text-secondary mt-1">
          {isSingleCommentMode
            ? data?.workpaper?.title
            : 'Permanent archive of supervisor notes, peer clearances, and auditor dialogues across all cycles.'}
        </p>
      </div>

      {/* Full History Mode Filters (§ 3.5: "cycle tag, resolved/open chips, replies") */}
      {!isSingleCommentMode && (
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row gap-2.5">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-secondary absolute left-3 top-2.5 stroke-[1.5]" />
              <input
                type="text"
                placeholder="Search comments, author, or workpaper..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-8 pl-8 pr-3 text-apple-12 rounded-xl bg-surface-elevated border border-hairline text-primary placeholder:text-tertiary outline-none focus:border-accent"
              />
            </div>

            {/* Cycle Selector */}
            <select
              value={cycleFilter}
              onChange={(e) => setCycleFilter(e.target.value)}
              className="h-8 px-2.5 rounded-xl bg-surface-elevated border border-hairline text-apple-12 text-secondary outline-none cursor-pointer"
            >
              <option value="all">All Audit Cycles</option>
              <option value="Q3 2026 Cycle">Q3 2026 Cycle</option>
              <option value="Q2 2026 Cycle">Q2 2026 Cycle</option>
              <option value="2025 Annual Cycle">2025 Annual Cycle</option>
            </select>

            {/* Status Pills */}
            <div className="flex items-center gap-1 bg-surface-elevated p-0.5 rounded-xl border border-hairline">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1 rounded-lg text-apple-11 font-medium transition-colors ${
                  statusFilter === 'all'
                    ? 'bg-surface text-primary shadow-xs font-semibold'
                    : 'text-secondary hover:text-primary'
                }`}
              >
                All ({scopedComments.length})
              </button>
              <button
                onClick={() => setStatusFilter('open')}
                className={`px-2.5 py-1 rounded-lg text-apple-11 font-medium transition-colors ${
                  statusFilter === 'open'
                    ? 'bg-surface text-cinnabar shadow-xs font-semibold'
                    : 'text-secondary hover:text-primary'
                }`}
              >
                Open
              </button>
              <button
                onClick={() => setStatusFilter('cleared')}
                className={`px-2.5 py-1 rounded-lg text-apple-11 font-medium transition-colors ${
                  statusFilter === 'cleared'
                    ? 'bg-surface text-verdigris shadow-xs font-semibold'
                    : 'text-secondary hover:text-primary'
                }`}
              >
                Cleared
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comments List */}
      <div className="space-y-4">
        {(isSingleCommentMode ? (data?.comment ? [data.comment] : []) : filteredComments).map(
          (cmt) => {
            const wp = scopedWorkpapers.find((w) => w.id === cmt.workpaperId);
            const eng = scopedEngagements.find((e) => e.id === wp?.engagementId);
            const cycleTag = getCycleTag(cmt.createdAt);
            const isExpanded = expandedCommentId === cmt.id || isSingleCommentMode;

            return (
              <div
                key={cmt.id}
                className="p-4 rounded-2xl bg-surface-elevated border border-hairline shadow-xs space-y-3"
              >
                {/* Meta Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="w-7 h-7 rounded-full bg-accent-subtle text-accent font-semibold flex items-center justify-center text-apple-11">
                      {cmt.authorName
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)}
                    </span>
                    <div>
                      <div className="text-apple-12 font-semibold text-primary">
                        {cmt.authorName}{' '}
                        <span className="text-apple-11 uppercase font-normal text-secondary">
                          ({cmt.authorRole})
                        </span>
                      </div>
                      <div className="text-apple-11 text-tertiary tabular-nums">
                        {new Date(cmt.createdAt).toLocaleString()}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {/* Cycle Tag (§ 3.5 requirement) */}
                    <span className="px-2 py-0.5 rounded-full text-apple-11 font-medium bg-surface text-secondary border border-hairline">
                      {cycleTag}
                    </span>
                    {/* Status Chip */}
                    {cmt.status === 'cleared' ? (
                      <span className="px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-verdigris-subtle text-verdigris flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 stroke-[2]" />
                        Cleared
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-cinnabar-subtle text-cinnabar">
                        Open
                      </span>
                    )}
                  </div>
                </div>

                {/* Comment Text */}
                <p className="text-apple-13 text-primary leading-relaxed bg-surface p-3 rounded-xl border border-hairline">
                  {cmt.text}
                </p>

                {/* Linked Document Reference (§ 3.5: clicking document opens audit file) */}
                {wp && (
                  <div className="flex items-center justify-between text-apple-12 pt-1 border-t border-hairline">
                    <div className="flex items-center gap-1.5 text-secondary truncate">
                      <FileText className="w-3.5 h-3.5 stroke-[1.5] text-accent shrink-0" />
                      <span className="truncate">
                        On <strong>{wp.refCode}</strong> • {wp.title}
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        if (eng) {
                          openInspector('audit_file', { engagement: eng, workpaper: wp });
                        }
                      }}
                      className="flex items-center gap-1 text-apple-11 text-accent font-semibold hover:underline shrink-0 ml-2"
                    >
                      <span>Open Audit File</span>
                      <ExternalLink className="w-3 h-3 stroke-[1.5]" />
                    </button>
                  </div>
                )}

                {/* Replies Thread */}
                {cmt.replies && cmt.replies.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-hairline">
                    <div className="text-apple-11 font-semibold text-secondary uppercase tracking-wider">
                      Thread Clearance Responses ({cmt.replies.length})
                    </div>
                    {cmt.replies.map((rep) => (
                      <div
                        key={rep.id}
                        className="p-3 rounded-xl bg-surface border border-hairline ml-3 space-y-1"
                      >
                        <div className="flex items-center justify-between text-apple-11 text-secondary">
                          <span className="font-semibold text-primary">{rep.authorName}</span>
                          <span className="tabular-nums">
                            {new Date(rep.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-apple-12 text-primary">{rep.text}</p>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply Composer */}
                <div className="pt-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={expandedCommentId === cmt.id ? replyText : ''}
                      onChange={(e) => {
                        setExpandedCommentId(cmt.id);
                        setReplyText(e.target.value);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleSendReply(cmt);
                        }
                      }}
                      placeholder="Add formal reviewer clearance note or reply…"
                      className="flex-1 h-8 px-3 rounded-xl bg-surface border border-hairline text-apple-12 text-primary placeholder:text-tertiary outline-none focus:border-accent"
                    />
                    <button
                      onClick={() => handleSendReply(cmt)}
                      disabled={expandedCommentId !== cmt.id || !replyText.trim()}
                      className="px-3 py-1 bg-accent text-canvas font-semibold rounded-xl text-apple-11 hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed shadow-xs flex items-center gap-1"
                    >
                      <Send className="w-3 h-3 stroke-[2]" />
                      <span>Reply</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          }
        )}

        {!isSingleCommentMode && filteredComments.length === 0 && (
          <div className="py-12 text-center text-apple-13 text-secondary">
            No review comments found matching the current criteria.
          </div>
        )}
      </div>
    </div>
  );
};
"""
write_file('/app/applet/docs/reference/v1/src/components/reviews/CommentHistoryPanel.tsx', cmt_history_ref)
write_file('/app/applet/src/components/reviews/CommentHistoryPanel.tsx', cmt_history_ref.replace("from 'lucide-react'", "from '../common/Icons'"))

cmt_dock_ref = """import React from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import { MessageSquare, Check, ArrowRight } from 'lucide-react';

export const ReviewCommentsDock: React.FC = () => {
  const { scopedComments, scopedWorkpapers } = useScopedData();
  const { openInspector, setSelectedWorkpaperId, setActiveTab } = useApp();

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-5 shadow-apple space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-apple-15 font-semibold text-primary">Review Comments Dock</h3>
          <p className="text-apple-12 text-secondary">
            Four-eyes peer review queries and supervisor clearance notes
          </p>
        </div>
        <span className="px-2 py-0.5 rounded text-apple-11 font-medium bg-surface-elevated text-secondary border border-hairline tabular-nums">
          {scopedComments.length} Active Notes
        </span>
      </div>

      <div className="space-y-2.5">
        {scopedComments.length === 0 ? (
          <div className="py-8 text-center text-apple-12 text-secondary">
            No open review comments for your current scope.
          </div>
        ) : (
          scopedComments.map((cmt) => {
            const wp = scopedWorkpapers.find((w) => w.id === cmt.workpaperId);
            const previewData = {
              title: `Comment from ${cmt.authorName} (${cmt.authorRole.toUpperCase()})`,
              category: `Workpaper ${wp?.refCode || cmt.workpaperId}`,
              subtitle: cmt.text,
              status: cmt.status === 'cleared' ? 'Cleared' : 'Pending Preparer Action',
              statusType: cmt.status === 'cleared' ? ('verdigris' as const) : ('amber' as const),
              dueDate: new Date(cmt.createdAt).toLocaleDateString(),
              hint: 'Click to open comment thread in inspector',
            };

            return (
              <HoverPreview key={cmt.id} content={previewData} className="w-full">
                <div
                  onClick={() => openInspector('comment', { comment: cmt, workpaper: wp })}
                  className="w-full text-left p-3.5 rounded-xl bg-surface-elevated hover:bg-surface-hover transition-colors border border-hairline cursor-pointer flex items-start gap-3"
                >
                  <div className="p-2 rounded-lg bg-accent-subtle text-accent shrink-0 mt-0.5">
                    <MessageSquare className="w-4 h-4 stroke-[1.5]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-apple-12 font-semibold text-primary truncate">
                        {cmt.authorName}
                      </div>
                      <span className="text-apple-11 text-tertiary tabular-nums">
                        {new Date(cmt.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-apple-12 text-secondary line-clamp-2 mt-0.5">{cmt.text}</p>
                    {wp && (
                      <div className="mt-2 flex items-center gap-2 text-apple-11 text-accent font-medium">
                        <span>{wp.refCode}</span>
                        <span>•</span>
                        <span className="truncate">{wp.title}</span>
                      </div>
                    )}
                  </div>
                </div>
              </HoverPreview>
            );
          })
        )}
      </div>
    </div>
  );
};
"""
write_file('/app/applet/docs/reference/v1/src/components/reviews/ReviewCommentsDock.tsx', cmt_dock_ref)
write_file('/app/applet/src/components/reviews/ReviewCommentsDock.tsx', cmt_dock_ref.replace("from 'lucide-react'", "from '../common/Icons'"))

global_dock_ref = """import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { ReviewComment, WorkingPaper } from '../../types';
import {
  MessageSquare,
  Minus,
  Paperclip,
  Send,
  X,
  FileText,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Clock,
  CheckCircle2,
} from 'lucide-react';

interface AttachedFile {
  name: string;
  size: string;
}

export const ReviewCommentsGlobalDock: React.FC = () => {
  const { openInspector, currentUser } = useApp();
  const { scopedComments, scopedWorkpapers, scopedEngagements } = useScopedData();

  // Floating dock open / minimize state
  const [isOpen, setIsOpen] = useState(false);
  const [expandedThreadId, setExpandedThreadId] = useState<string | null>(null);

  // Composer reply state per thread
  const [replyText, setReplyText] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<AttachedFile[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // In-progress audits filter for dock (§ 3.5: "Dock lists current in-progress audits; history lists all")
  const inProgressWorkpapers = scopedWorkpapers.filter((w) => {
    const eng = scopedEngagements.find((e) => e.id === w.engagementId);
    return eng?.status === 'in_progress' || w.status === 'in_progress';
  });
  const inProgressWpIds = new Set(inProgressWorkpapers.map((w) => w.id));

  // Dock comments: comments on currently active audits
  const activeDockComments = scopedComments.filter((c) =>
    inProgressWpIds.has(c.workpaperId)
  );

  const awaitingResponseCount = activeDockComments.filter(
    (c) => c.status === 'open'
  ).length;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const newFiles: AttachedFile[] = Array.from(e.target.files).map((f) => ({
      name: f.name,
      size: `${Math.round(f.size / 1024)} KB`,
    }));
    setAttachedFiles((prev) => [...prev, ...newFiles]);
  };

  const removeFile = (fileName: string) => {
    setAttachedFiles((prev) => prev.filter((f) => f.name !== fileName));
  };

  const handleSendReply = (cmt: ReviewComment) => {
    if (!replyText.trim() && attachedFiles.length === 0) return;

    const reply = {
      id: `rep-${Date.now()}`,
      authorName: currentUser.name,
      text: replyText.trim() + (attachedFiles.length > 0 ? ` [Attached: ${attachedFiles.map(f => f.name).join(', ')}]` : ''),
      createdAt: new Date().toISOString(),
    };

    if (!cmt.replies) {
      cmt.replies = [];
    }
    cmt.replies.push(reply);
    setReplyText('');
    setAttachedFiles([]);
  };

  return (
    <>
      {/* Global Floating Launcher Bubble (56px, comment icon, cinnabar unread badge per § 3.5) */}
      <div className="fixed bottom-6 right-6 z-40 select-none">
        <AnimatePresence>
          {!isOpen && (
            <motion.button
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              onClick={() => setIsOpen(true)}
              className="w-14 h-14 rounded-full bg-primary text-canvas shadow-apple flex items-center justify-center hover:scale-105 active:scale-95 transition-transform relative focus:outline-none focus:ring-2 focus:ring-accent"
              title="Four-eyes Review Comments Dock"
              aria-label="Open review comments dock"
            >
              <MessageSquare className="w-6 h-6 stroke-[1.5]" />
              {/* Cinnabar Unread Badge */}
              {awaitingResponseCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1.5 rounded-full bg-cinnabar text-canvas font-bold text-apple-11 flex items-center justify-center shadow-xs border-2 border-canvas tabular-nums">
                  {awaitingResponseCount}
                </span>
              )}
            </motion.button>
          )}
        </AnimatePresence>

        {/* 420px Dock Panel (max 620px, origin bottom-right per § 3.5) */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.88, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.88, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              style={{ transformOrigin: 'bottom right' }}
              className="w-[420px] max-w-[calc(100vw-32px)] max-h-[620px] bg-glass border border-hairline shadow-apple rounded-3xl flex flex-col overflow-hidden text-primary"
            >
              {/* Header */}
              <div className="px-5 py-4 border-b border-hairline flex items-center justify-between bg-surface-elevated shrink-0">
                <div>
                  <h4 className="text-apple-15 font-bold text-primary flex items-center gap-2">
                    <span>Review Comments</span>
                    <span className="px-2 py-0.5 rounded-full text-apple-11 font-medium bg-accent-subtle text-accent border border-accent">
                      Active Audits
                    </span>
                  </h4>
                  <p className="text-apple-11 text-secondary mt-0.5">
                    {awaitingResponseCount} awaiting preparer response
                  </p>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-1.5 rounded-lg text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                    title="Minimize dock"
                    aria-label="Minimize review comments dock"
                  >
                    <Minus className="w-4 h-4 stroke-[1.5]" />
                  </button>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-1.5 rounded-lg text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                    title="Close dock"
                    aria-label="Close review comments dock"
                  >
                    <X className="w-4 h-4 stroke-[1.5]" />
                  </button>
                </div>
              </div>

              {/* Thread Rows Scroll Area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {activeDockComments.length === 0 ? (
                  <div className="py-12 text-center text-apple-12 text-secondary">
                    No open queries awaiting clearance in current active audits.
                  </div>
                ) : (
                  activeDockComments.map((cmt) => {
                    const wp = scopedWorkpapers.find((w) => w.id === cmt.workpaperId);
                    const eng = scopedEngagements.find((e) => e.id === wp?.engagementId);
                    const isExpanded = expandedThreadId === cmt.id;
                    const repliesCount = cmt.replies ? cmt.replies.length : 0;

                    return (
                      <div
                        key={cmt.id}
                        className={`rounded-2xl border transition-all overflow-hidden ${
                          isExpanded
                            ? 'bg-surface border-accent shadow-soft'
                            : 'bg-surface-elevated border-hairline hover:bg-surface-hover'
                        }`}
                      >
                        {/* Summary Row */}
                        <div
                          onClick={() => setExpandedThreadId(isExpanded ? null : cmt.id)}
                          className="p-3.5 cursor-pointer flex items-start gap-3 select-none"
                        >
                          {/* Avatar */}
                          <div className="w-8 h-8 rounded-full bg-accent-subtle text-accent font-semibold flex items-center justify-center text-apple-11 shrink-0 mt-0.5">
                            {cmt.authorName
                              .split(' ')
                              .map((n) => n[0])
                              .join('')
                              .slice(0, 2)}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5 truncate">
                                <span className="text-apple-12 font-semibold text-primary truncate">
                                  {cmt.authorName}
                                </span>
                                <span className="text-apple-11 uppercase font-semibold text-accent px-1 rounded bg-accent-subtle">
                                  {cmt.authorRole}
                                </span>
                              </div>
                              <span className="text-apple-11 text-tertiary tabular-nums shrink-0">
                                {new Date(cmt.createdAt).toLocaleTimeString([], {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                            </div>

                            <p className="text-apple-12 text-primary mt-1 line-clamp-2">
                              {cmt.text}
                            </p>

                            {/* Document Reference Pill: Clicking document opens audit file (§ 3.5 requirement) */}
                            {wp && (
                              <div className="mt-2 flex items-center justify-between text-apple-11">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (eng) {
                                      openInspector('audit_file', { engagement: eng, workpaper: wp });
                                    }
                                  }}
                                  className="flex items-center gap-1.5 text-accent hover:underline font-medium truncate max-w-[240px]"
                                  title="Open in Permanent Audit File"
                                >
                                  <FileText className="w-3 h-3 stroke-[1.5] shrink-0" />
                                  <span className="truncate">on {wp.refCode} ({wp.title})</span>
                                  <ExternalLink className="w-2.5 h-2.5 stroke-[1.5] shrink-0" />
                                </button>

                                <div className="flex items-center gap-2 text-secondary">
                                  {repliesCount > 0 && (
                                    <span className="text-apple-11 font-medium">
                                      {repliesCount} {repliesCount === 1 ? 'reply' : 'replies'}
                                    </span>
                                  )}
                                  {cmt.status === 'cleared' ? (
                                    <span className="text-verdigris font-semibold flex items-center gap-0.5">
                                      <CheckCircle2 className="w-3 h-3 stroke-[2]" />
                                      Cleared
                                    </span>
                                  ) : (
                                    <span className="text-cinnabar font-semibold">
                                      Open
                                    </span>
                                  )}
                                  {isExpanded ? (
                                    <ChevronUp className="w-3.5 h-3.5 stroke-[1.5]" />
                                  ) : (
                                    <ChevronDown className="w-3.5 h-3.5 stroke-[1.5]" />
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Expanded Dialogue View (§ 3.5: reply bubbles + composer) */}
                        {isExpanded && (
                          <div className="px-3.5 pb-3.5 pt-1 border-t border-hairline space-y-3 bg-surface-sunken">
                            {/* Previous Replies Bubbles */}
                            {cmt.replies && cmt.replies.length > 0 && (
                              <div className="space-y-2 pt-2 max-h-48 overflow-y-auto pr-1">
                                <div
                                  className="flex flex-col items-start"
                                >
                                  <span className="text-apple-11 text-tertiary mb-0.5 px-1">
                                    {cmt.authorName} • {new Date(cmt.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </span>
                                  <div className="max-w-[85%] p-2.5 rounded-2xl text-apple-12 bg-surface text-primary border border-hairline rounded-bl-xs">
                                    {cmt.text}
                                  </div>
                                </div>
                                {cmt.replies.map((rep) => {
                                  const isOwn = rep.authorName === currentUser.name;
                                  return (
                                    <div
                                      key={rep.id}
                                      className={`flex flex-col ${
                                        isOwn ? 'items-end' : 'items-start'
                                      }`}
                                    >
                                      <span className="text-apple-11 text-tertiary mb-0.5 px-1">
                                        {rep.authorName} • {new Date(rep.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                      </span>
                                      <div
                                        className={`max-w-[85%] p-2.5 rounded-2xl text-apple-12 ${
                                          isOwn
                                            ? 'bg-accent text-canvas rounded-br-xs shadow-xs'
                                            : 'bg-surface text-primary border border-hairline rounded-bl-xs'
                                        }`}
                                      >
                                        {rep.text}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            {/* Attached files preview chips */}
                            {attachedFiles.length > 0 && (
                              <div className="flex flex-wrap gap-1.5 pt-1">
                                {attachedFiles.map((f) => (
                                  <span
                                    key={f.name}
                                    className="px-2 py-0.5 rounded-lg bg-surface border border-hairline text-apple-11 text-primary flex items-center gap-1 shadow-xs"
                                  >
                                    <Paperclip className="w-3 h-3 stroke-[1.5] text-accent" />
                                    <span className="truncate max-w-[120px]">{f.name}</span>
                                    <button
                                      onClick={() => removeFile(f.name)}
                                      className="text-secondary hover:text-cinnabar"
                                    >
                                      ×
                                    </button>
                                  </span>
                                ))}
                              </div>
                            )}

                            {/* Composer */}
                            <div className="space-y-2">
                              <textarea
                                rows={2}
                                value={replyText}
                                onChange={(e) => setReplyText(e.target.value)}
                                placeholder="Write response or clearance clarification…"
                                className="w-full p-2.5 text-apple-12 rounded-xl bg-surface border border-hairline text-primary placeholder:text-tertiary outline-none focus:border-accent resize-none"
                              />

                              <div className="flex items-center justify-between">
                                {/* Paperclip for Multi-file Upload */}
                                <div>
                                  <input
                                    type="file"
                                    ref={fileInputRef}
                                    onChange={handleFileUpload}
                                    multiple
                                    className="hidden"
                                    accept=".pdf,.xlsx,.csv,.png,.docx"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    className="p-1.5 rounded-lg text-secondary hover:text-primary hover:bg-surface transition-colors flex items-center gap-1.5 text-apple-11"
                                    title="Attach supporting audit file"
                                  >
                                    <Paperclip className="w-3.5 h-3.5 stroke-[1.5]" />
                                    <span>Attach file</span>
                                  </button>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => handleSendReply(cmt)}
                                  disabled={!replyText.trim() && attachedFiles.length === 0}
                                  className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-accent text-canvas font-semibold text-apple-12 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed shadow-xs"
                                >
                                  <span>Reply</span>
                                  <Send className="w-3 h-3 stroke-[2]" />
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Footer: "View full comment history" opens Inspector Panel (§ 3.5 requirement) */}
              <div className="p-3 border-t border-hairline bg-surface-elevated text-center shrink-0">
                <button
                  onClick={() => {
                    openInspector('comment_history');
                    setIsOpen(false);
                  }}
                  className="w-full py-2 px-4 rounded-xl bg-surface hover:bg-surface-hover border border-hairline text-apple-12 font-semibold text-accent transition-colors flex items-center justify-center gap-2 shadow-xs"
                >
                  <Clock className="w-3.5 h-3.5 stroke-[1.5]" />
                  <span>View full comment history across all cycles</span>
                  <ExternalLink className="w-3.5 h-3.5 stroke-[1.5]" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};
"""
write_file('/app/applet/docs/reference/v1/src/components/reviews/ReviewCommentsGlobalDock.tsx', global_dock_ref)
write_file('/app/applet/src/components/reviews/ReviewCommentsGlobalDock.tsx', global_dock_ref.replace("from 'lucide-react'", "from '../common/Icons'"))

global_dock_test_tsx = """import React from 'react';
import { describe, expect, it } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { ReviewCommentsGlobalDock } from './ReviewCommentsGlobalDock';
import { AppProvider } from '../../context/AppContext';
import { ThemeProvider } from '../../context/ThemeContext';

describe('§ 3.5 Global Review Comments Dock', () => {
  it('renders floating launcher button and opens dock on click', () => {
    render(
      <ThemeProvider>
        <AppProvider>
          <ReviewCommentsGlobalDock />
        </AppProvider>
      </ThemeProvider>
    );

    // Assert floating launcher button is rendered
    const launcherBtn = screen.getByLabelText('Open review comments dock');
    expect(launcherBtn).toBeDefined();

    // Click to open dock
    fireEvent.click(launcherBtn);

    // Verify dock panel header is visible
    expect(screen.getByText('Review Comments')).toBeDefined();
    expect(screen.getByText('View full comment history across all cycles')).toBeDefined();
  });
});
"""
write_file('/app/applet/src/components/reviews/ReviewCommentsGlobalDock.test.tsx', global_dock_test_tsx)
write_file('/app/applet/docs/reference/v1/src/components/reviews/ReviewCommentsGlobalDock.test.tsx', global_dock_test_tsx)
