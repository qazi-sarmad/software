import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

ledger_ts = """import { LedgerEntry, LedgerEventType, Role } from '../types';

export const GENESIS_PREV_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

/**
 * Deterministically computes SHA-256 hex string for a given text or JSON object.
 */
export async function computeSha256(data: string): Promise<string> {
  // Use crypto.subtle in browser / modern Node
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // Fallback for test runner if needed
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(64, '0');
}

/**
 * Computes payload hash for any structured data.
 */
export async function computePayloadHash(payload: unknown): Promise<string> {
  const jsonString = typeof payload === 'string' ? payload : JSON.stringify(payload);
  return computeSha256(jsonString);
}

/**
 * Computes block hash for an entry in the hash chain.
 */
export async function computeEntryHash(
  prevHash: string,
  timestamp: string,
  actorId: string,
  actorRole: string,
  eventType: string,
  entityId: string,
  recordId: string,
  payloadHash: string,
  justification?: string
): Promise<string> {
  const rawData = [
    prevHash,
    timestamp,
    actorId,
    actorRole,
    eventType,
    entityId,
    recordId,
    payloadHash,
    justification || '',
  ].join('|');
  return computeSha256(rawData);
}

/**
 * Creates and appends a new ledger entry in the hash chain.
 */
export async function appendLedgerEntry(
  existingChain: LedgerEntry[],
  params: {
    actorId: string;
    actorName: string;
    actorRole: Role;
    eventType: LedgerEventType;
    entityId: string;
    recordId: string;
    recordType: LedgerEntry['recordType'];
    payloadSummary: string;
    payloadData?: unknown;
    payloadHash?: string;
    justification?: string;
    timestamp?: string;
  }
): Promise<LedgerEntry> {
  if (params.eventType === 'reopen') {
    if (!params.justification || params.justification.trim().length < 10) {
      throw new Error('Reopen event requires a justification note of at least 10 characters');
    }
  }

  const prevHash =
    existingChain.length > 0 ? existingChain[existingChain.length - 1].hash : GENESIS_PREV_HASH;
  const seq = existingChain.length + 1;
  const timestamp = params.timestamp || new Date().toISOString();

  const payloadHash =
    params.payloadHash ||
    (params.payloadData ? await computePayloadHash(params.payloadData) : await computeSha256(params.payloadSummary));

  const hash = await computeEntryHash(
    prevHash,
    timestamp,
    params.actorId,
    params.actorRole,
    params.eventType,
    params.entityId,
    params.recordId,
    payloadHash,
    params.justification
  );

  return {
    seq,
    prevHash,
    hash,
    timestamp,
    actorId: params.actorId,
    actorName: params.actorName,
    actorRole: params.actorRole,
    eventType: params.eventType,
    entityId: params.entityId,
    recordId: params.recordId,
    recordType: params.recordType,
    payloadSummary: params.payloadSummary,
    payloadHash,
    justification: params.justification,
  };
}

export interface VerificationResult {
  valid: boolean;
  brokenSeq?: number;
  error?: string;
}

/**
 * Client-side verification of chain integrity.
 */
export async function verifyChain(entries: LedgerEntry[]): Promise<VerificationResult> {
  if (!entries || entries.length === 0) {
    return { valid: true };
  }

  let expectedPrevHash = GENESIS_PREV_HASH;

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];

    if (entry.seq !== i + 1) {
      return {
        valid: false,
        brokenSeq: entry.seq,
        error: `Sequence numbering broken at index ${i}, expected seq ${i + 1}, found ${entry.seq}`,
      };
    }

    if (entry.prevHash !== expectedPrevHash) {
      return {
        valid: false,
        brokenSeq: entry.seq,
        error: `Previous hash mismatch at sequence ${entry.seq}`,
      };
    }

    const calculatedHash = await computeEntryHash(
      entry.prevHash,
      entry.timestamp,
      entry.actorId,
      entry.actorRole,
      entry.eventType,
      entry.entityId,
      entry.recordId,
      entry.payloadHash,
      entry.justification
    );

    if (calculatedHash !== entry.hash) {
      return {
        valid: false,
        brokenSeq: entry.seq,
        error: `Cryptographic hash recalculation mismatch at sequence ${entry.seq}`,
      };
    }

    expectedPrevHash = entry.hash;
  }

  return { valid: true };
}

/**
 * Checks if current state matches the signed hash.
 */
export function matchesSignedState(currentHash: string, signedHash?: string): boolean {
  if (!signedHash) return false;
  return currentHash === signedHash;
}

/**
 * Generates the seeded initial ledger with authentic cryptographic hashes.
 */
export async function generateInitialLedger(): Promise<LedgerEntry[]> {
  const chain: LedgerEntry[] = [];

  const e1 = await appendLedgerEntry(chain, {
    actorId: 'usr-prep-2',
    actorName: 'Julian Sterling',
    actorRole: 'preparer',
    eventType: 'test_finalize',
    entityId: 'ent-compliance',
    recordId: 'wp-aml-01',
    recordType: 'workpaper',
    payloadSummary: 'Test steps completed and population verified (420,000 wires)',
    payloadHash: 'c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2',
    timestamp: '2026-09-10T14:30:00Z',
  });
  chain.push(e1);

  const e2 = await appendLedgerEntry(chain, {
    actorId: 'usr-rev-1',
    actorName: 'Marcus Vance',
    actorRole: 'reviewer',
    eventType: 'reviewer_sign_off',
    entityId: 'ent-compliance',
    recordId: 'wp-aml-01',
    recordType: 'workpaper',
    payloadSummary: 'Workpaper sealed and approved by Reviewer Marcus Vance',
    payloadHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    timestamp: '2026-09-14T16:00:00Z',
  });
  chain.push(e2);

  const e3 = await appendLedgerEntry(chain, {
    actorId: 'usr-rev-1',
    actorName: 'Marcus Vance',
    actorRole: 'reviewer',
    eventType: 'audit_sign_off',
    entityId: 'ent-compliance',
    recordId: 'eng-aml-annual',
    recordType: 'engagement',
    payloadSummary: 'Engagement Q3 AML Monitoring formally signed-off and sealed',
    payloadHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    timestamp: '2026-09-14T16:15:00Z',
  });
  chain.push(e3);

  return chain;
}
"""
write_both('src/lib/ledger.ts', ledger_ts)

ledger_test_ts = """import { describe, expect, it } from 'vitest';
import { appendLedgerEntry, generateInitialLedger, matchesSignedState, verifyChain } from './ledger';

describe('Task 1: Audit Signatures Ledger Hash-Chain', () => {
  it('Appends entries and maintains cryptographic chain integrity', async () => {
    let chain: any[] = [];

    // Entry 1: test_finalize
    const entry1 = await appendLedgerEntry(chain, {
      actorId: 'usr-prep-1',
      actorName: 'Alice Auditor',
      actorRole: 'preparer',
      eventType: 'test_finalize',
      entityId: 'ent-a',
      recordId: 'wp-1',
      recordType: 'workpaper',
      payloadSummary: 'Finalized 25 sample items for LCR test',
      payloadData: { samplesTested: 25, exceptions: 0 },
    });
    chain = [...chain, entry1];

    expect(entry1.seq).toBe(1);
    expect(entry1.prevHash).toBe('0000000000000000000000000000000000000000000000000000000000000000');
    expect(entry1.hash).toBeDefined();

    // Entry 2: reviewer_sign_off
    const entry2 = await appendLedgerEntry(chain, {
      actorId: 'usr-rev-1',
      actorName: 'Bob Reviewer',
      actorRole: 'reviewer',
      eventType: 'reviewer_sign_off',
      entityId: 'ent-a',
      recordId: 'wp-1',
      recordType: 'workpaper',
      payloadSummary: 'Reviewed and concurred with test conclusion',
    });
    chain = [...chain, entry2];

    expect(entry2.seq).toBe(2);
    expect(entry2.prevHash).toBe(entry1.hash);

    // Verify chain is valid
    const verification = await verifyChain(chain);
    expect(verification.valid).toBe(true);
    expect(verification.brokenSeq).toBeUndefined();
  });

  it('Enforces reopen justification of at least 10 characters', async () => {
    const chain: any[] = [];

    // Short justification (< 10 chars) should throw
    await expect(
      appendLedgerEntry(chain, {
        actorId: 'usr-cia',
        actorName: 'Carol CIA',
        actorRole: 'cia',
        eventType: 'reopen',
        entityId: 'ent-a',
        recordId: 'wp-1',
        recordType: 'workpaper',
        payloadSummary: 'Reopening workpaper',
        justification: 'Too short',
      })
    ).rejects.toThrow('justification note of at least 10 characters');

    // Valid justification (>= 10 chars) should succeed
    const validEntry = await appendLedgerEntry(chain, {
      actorId: 'usr-cia',
      actorName: 'Carol CIA',
      actorRole: 'cia',
      eventType: 'reopen',
      entityId: 'ent-a',
      recordId: 'wp-1',
      recordType: 'workpaper',
      payloadSummary: 'Reopening workpaper',
      justification: 'Requested by external regulator for supplemental sampling',
    });

    expect(validEntry.seq).toBe(1);
    expect(validEntry.justification).toBe('Requested by external regulator for supplemental sampling');
  });

  it('Detects tampering in the hash chain and pinpoints the broken sequence number', async () => {
    let chain: any[] = [];

    const entry1 = await appendLedgerEntry(chain, {
      actorId: 'usr-1',
      actorName: 'User 1',
      actorRole: 'preparer',
      eventType: 'test_finalize',
      entityId: 'ent-a',
      recordId: 'wp-1',
      recordType: 'workpaper',
      payloadSummary: 'Block 1',
    });
    chain = [entry1];

    const entry2 = await appendLedgerEntry(chain, {
      actorId: 'usr-2',
      actorName: 'User 2',
      actorRole: 'reviewer',
      eventType: 'reviewer_sign_off',
      entityId: 'ent-a',
      recordId: 'wp-1',
      recordType: 'workpaper',
      payloadSummary: 'Block 2',
    });
    chain = [...chain, entry2];

    const entry3 = await appendLedgerEntry(chain, {
      actorId: 'usr-3',
      actorName: 'User 3',
      actorRole: 'cia',
      eventType: 'audit_sign_off',
      entityId: 'ent-a',
      recordId: 'eng-1',
      recordType: 'engagement',
      payloadSummary: 'Block 3',
    });
    chain = [...chain, entry3];

    // Tamper with entry 2 payloadHash
    const tamperedChain = [
      entry1,
      { ...entry2, payloadHash: 'tampered_hash_value_123' },
      entry3,
    ];

    const check = await verifyChain(tamperedChain);
    expect(check.valid).toBe(false);
    expect(check.brokenSeq).toBe(2);
  });

  it('matchesSignedState returns true only when hashes match', () => {
    const hash = 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3';
    expect(matchesSignedState(hash, hash)).toBe(true);
    expect(matchesSignedState(hash, 'drifted_state')).toBe(false);
    expect(matchesSignedState(hash, undefined)).toBe(false);
  });

  it('Verifies that an untouched seeded ledger verifies successfully', async () => {
    const seed = await generateInitialLedger();
    const result = await verifyChain(seed);
    expect(result.valid).toBe(true);
    expect(result.brokenSeq).toBeUndefined();
  });
});
"""
write_both('src/lib/ledger.test.ts', ledger_test_ts)

analytics_ts = """import { AnalysisResultRow, AnalyticsRule } from '../types';

export interface TrialBalanceItem {
  account: string;
  category?: string;
  debit: number;
  credit: number;
  rowRef: number;
}

export interface VarianceInputItem {
  account: string;
  category: string;
  currentPeriod: number;
  priorPeriod: number;
  rowRef: number;
}

/**
 * Deterministic Variance Analysis.
 * Flags variances exceeding both absolute dollar threshold and percentage threshold.
 */
export function runVarianceAnalysis(
  items: VarianceInputItem[],
  thresholdPct = 10,
  thresholdVal = 100000
): AnalysisResultRow[] {
  return items.map((item, index) => {
    const varianceVal = item.currentPeriod - item.priorPeriod;
    const priorAbs = Math.abs(item.priorPeriod);
    const variancePct = priorAbs > 0 ? (varianceVal / priorAbs) * 100 : (item.currentPeriod !== 0 ? 100 : 0);

    const exceedsVal = Math.abs(varianceVal) >= thresholdVal;
    const exceedsPct = Math.abs(variancePct) >= thresholdPct;
    const flagged = exceedsVal && exceedsPct;

    let flagReason: string | undefined;
    if (flagged) {
      flagReason = `Exceeds thresholds: ${varianceVal >= 0 ? '+' : ''}$${Math.round(
        varianceVal
      ).toLocaleString()} (${variancePct.toFixed(1)}%)`;
    }

    return {
      rowIndex: index + 1,
      account: item.account,
      category: item.category,
      currentPeriod: item.currentPeriod,
      priorPeriod: item.priorPeriod,
      varianceVal,
      variancePct,
      flagged,
      flagReason,
      ruleId: 'variance' as AnalyticsRule,
      originalRowRef: item.rowRef,
    };
  });
}

/**
 * Deterministic Trial Balance Check.
 * Asserts Debits == Credits. Identifies accounts with unusual sign convention.
 */
export function runTrialBalanceCheck(items: TrialBalanceItem[]): {
  totalDebits: number;
  totalCredits: number;
  imbalance: number;
  balanced: boolean;
  rows: AnalysisResultRow[];
} {
  let totalDebits = 0;
  let totalCredits = 0;

  items.forEach((item) => {
    totalDebits += Number(item.debit) || 0;
    totalCredits += Number(item.credit) || 0;
  });

  const imbalance = Math.abs(totalDebits - totalCredits);
  const balanced = imbalance < 0.01; // Allow 1 cent rounding tolerance

  const rows: AnalysisResultRow[] = items.map((item, idx) => {
    const isUnusualNegative = item.debit < 0 || item.credit < 0;
    const isBothNonZero = item.debit > 0 && item.credit > 0;
    const flagged = isUnusualNegative || isBothNonZero || !balanced;

    return {
      rowIndex: idx + 1,
      account: item.account,
      category: item.category || 'Trial Balance',
      currentPeriod: item.debit,
      priorPeriod: item.credit,
      varianceVal: item.debit - item.credit,
      variancePct: item.credit !== 0 ? ((item.debit - item.credit) / item.credit) * 100 : 0,
      flagged,
      flagReason: isUnusualNegative
        ? 'Unusual negative balance in posting column'
        : isBothNonZero
        ? 'Both debit and credit non-zero on same line'
        : !balanced
        ? `TB overall out of balance by $${imbalance.toLocaleString()}`
        : undefined,
      ruleId: 'tb_check' as AnalyticsRule,
      originalRowRef: item.rowRef,
    };
  });

  return {
    totalDebits,
    totalCredits,
    imbalance,
    balanced,
    rows,
  };
}

/**
 * Deterministic Anomaly & Outlier Detection (Z-Score + Benford first-digit + round numbers).
 */
export function runAnomalyDetection(
  items: { account: string; category?: string; amount: number; rowRef: number }[]
): AnalysisResultRow[] {
  if (items.length === 0) return [];

  const amounts = items.map((i) => Math.abs(i.amount));
  const n = amounts.length;
  const mean = amounts.reduce((acc, v) => acc + v, 0) / n;
  const variance =
    n > 1
      ? amounts.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (n - 1)
      : 0;
  const stdDev = Math.sqrt(variance);

  return items.map((item, idx) => {
    const val = Math.abs(item.amount);
    const zScore = stdDev > 0 ? (val - mean) / stdDev : 0;
    const isZScoreOutlier = zScore > 2.0;

    // Check round number anomaly (multiples of $50,000 above $100k)
    const isRoundNumberAnomaly = val >= 100000 && val % 50000 === 0;

    const flagged = isZScoreOutlier || isRoundNumberAnomaly;
    let flagReason: string | undefined;

    if (isZScoreOutlier && isRoundNumberAnomaly) {
      flagReason = `Statistical outlier (z-score ${zScore.toFixed(2)} > 2.5) and exact round amount ($${val.toLocaleString()})`;
    } else if (isZScoreOutlier) {
      flagReason = `Statistical outlier (z-score ${zScore.toFixed(2)} > 2.5)`;
    } else if (isRoundNumberAnomaly) {
      flagReason = `Suspicious exact round amount ($${val.toLocaleString()})`;
    }

    return {
      rowIndex: idx + 1,
      account: item.account,
      category: item.category || 'General Ledger',
      currentPeriod: item.amount,
      priorPeriod: mean,
      varianceVal: item.amount - mean,
      variancePct: mean > 0 ? ((item.amount - mean) / mean) * 100 : 0,
      flagged,
      flagReason,
      ruleId: 'anomalies' as AnalyticsRule,
      originalRowRef: item.rowRef,
    };
  });
}

/**
 * Deterministic GL to TB Reconciliation.
 */
export function runGlToTbReconciliation(
  glEntries: { account: string; amount: number; rowRef: number }[],
  tbBalances: { account: string; balance: number; rowRef: number }[]
): AnalysisResultRow[] {
  const glMap = new Map<string, { total: number; rowRefs: number[] }>();

  glEntries.forEach((entry) => {
    const existing = glMap.get(entry.account) || { total: 0, rowRefs: [] };
    existing.total += entry.amount;
    existing.rowRefs.push(entry.rowRef);
    glMap.set(entry.account, existing);
  });

  return tbBalances.map((tb, idx) => {
    const glData = glMap.get(tb.account) || { total: 0, rowRefs: [] };
    const diff = Math.abs(glData.total - tb.balance);
    const flagged = diff > 0.01;

    return {
      rowIndex: idx + 1,
      account: tb.account,
      category: 'GL vs TB Reconciliation',
      currentPeriod: glData.total,
      priorPeriod: tb.balance,
      varianceVal: glData.total - tb.balance,
      variancePct: tb.balance !== 0 ? ((glData.total - tb.balance) / Math.abs(tb.balance)) * 100 : 0,
      flagged,
      flagReason: flagged
        ? `Reconciliation gap: GL subledger ($${glData.total.toLocaleString()}) does not tie to TB ($${tb.balance.toLocaleString()})`
        : undefined,
      ruleId: 'gl_to_tb' as AnalyticsRule,
      originalRowRef: tb.rowRef,
    };
  });
}

export interface DocumentReviewCheckResult {
  rule: string;
  passed: boolean;
  message: string;
  findings: string[];
}

/**
 * Deterministic Document Review for Word / Text extractions.
 * Analyzes structure, placeholder phrases, missing dates/signatures, and numeric assertions.
 */
export function runDocumentReview(rawText: string): DocumentReviewCheckResult[] {
  const text = rawText || '';
  const lines = text.split('\\n').map((l) => l.trim()).filter(Boolean);
  const results: DocumentReviewCheckResult[] = [];

  // Check 1: Placeholder text patterns
  const placeholderPatterns = [
    /\\b(TODO|TBD|PLACEHOLDER|INSERT HERE|DRAFT)\\b/i,
    /\\[.*?\\]/,
    /<.*?>/,
    /\\b(lorem ipsum|consectetur adipiscing)\\b/i,
  ];

  const placeholderMatches: string[] = [];
  lines.forEach((line, idx) => {
    for (const pat of placeholderPatterns) {
      if (pat.test(line)) {
        placeholderMatches.push(`Line ${idx + 1}: "${line.substring(0, 80)}"`);
        break;
      }
    }
  });

  results.push({
    rule: 'Placeholder and Draft Tokens',
    passed: placeholderMatches.length === 0,
    message:
      placeholderMatches.length === 0
        ? 'No draft placeholders or unpopulated tokens detected'
        : `Found ${placeholderMatches.length} placeholder tokens requiring completion`,
    findings: placeholderMatches,
  });

  // Check 2: Signatures and Sign-off Blocks
  const signatureKeywords = ['prepared by', 'reviewed by', 'approved by', 'signed', 'signature'];
  const signatureMatches = lines.filter((l) =>
    signatureKeywords.some((kw) => l.toLowerCase().includes(kw))
  );

  const unsignedMatches: string[] = [];
  signatureMatches.forEach((line) => {
    // If line has empty colon or trailing dashes: e.g. "Approved by: ______" or "Approved by:"
    if (/:\\s*(_+|\\.{3,}|\\s*)$/.test(line) || /:\\s*$/.test(line)) {
      unsignedMatches.push(line);
    }
  });

  results.push({
    rule: 'Formal Signatures and Attestation',
    passed: unsignedMatches.length === 0 && signatureMatches.length > 0,
    message:
      unsignedMatches.length === 0 && signatureMatches.length > 0
        ? 'Signature attestation lines completed'
        : signatureMatches.length === 0
        ? 'No formal attestation or approval block found in document'
        : `Found ${unsignedMatches.length} unsigned approval lines`,
    findings: unsignedMatches.length > 0 ? unsignedMatches : signatureMatches.length === 0 ? ['Missing signature block'] : [],
  });

  // Check 3: Effective Date Presence
  const datePattern = /\\b(\\d{1,2}[\\/\\.-]\\d{1,2}[\\/\\.-]\\d{2,4}|(?:January|February|March|April|May|June|July|August|September|October|November|December)\\s+\\d{1,2},\\s+\\d{4})\\b/i;
  const hasDates = datePattern.test(text);

  results.push({
    rule: 'Document Date and Period Specification',
    passed: hasDates,
    message: hasDates ? 'Effective period or audit date identified' : 'Missing formal date or period reference',
    findings: hasDates ? [] : ['No standard calendar date found in document body'],
  });

  // Check 4: Section Structure / Empty Sections
  const emptySectionFindings: string[] = [];
  for (let i = 0; i < lines.length - 1; i++) {
    const current = lines[i];
    const next = lines[i + 1];
    if (
      /^(Section|\\d+\\.|\\bObjective\\b|\\bScope\\b|\\bMethodology\\b)/i.test(current) &&
      /^(Section|\\d+\\.|\\bObjective\\b|\\bScope\\b|\\bMethodology\\b)/i.test(next)
    ) {
      emptySectionFindings.push(`Empty section header detected before "${next}"`);
    }
  }

  results.push({
    rule: 'Section Completeness',
    passed: emptySectionFindings.length === 0,
    message:
      emptySectionFindings.length === 0
        ? 'All documented sections contain substantive body text'
        : `Detected ${emptySectionFindings.length} consecutive section headers without body text`,
    findings: emptySectionFindings,
  });

  return results;
}
"""
write_both('src/lib/analytics.ts', analytics_ts)

analytics_test_ts = """import { describe, expect, it } from 'vitest';
import {
  runAnomalyDetection,
  runDocumentReview,
  runGlToTbReconciliation,
  runTrialBalanceCheck,
  runVarianceAnalysis,
} from './analytics';

describe('Task 2: Audit Analytics & Document Review Engine', () => {
  it('Variance analysis flags rows exceeding percentage and dollar thresholds', () => {
    const input = [
      {
        account: '1010 - Cash & Equivalents',
        category: 'Assets',
        currentPeriod: 1200000,
        priorPeriod: 1000000,
        rowRef: 1,
      }, // +200k, +20% -> Flagged (exceeds 100k & 10%)
      {
        account: '1020 - Petty Cash',
        category: 'Assets',
        currentPeriod: 12000,
        priorPeriod: 10000,
        rowRef: 2,
      }, // +2k, +20% -> Not flagged (dollar < 100k)
      {
        account: '2010 - Accounts Payable',
        category: 'Liabilities',
        currentPeriod: 5020000,
        priorPeriod: 5000000,
        rowRef: 3,
      }, // +20k, +0.4% -> Not flagged
    ];

    const results = runVarianceAnalysis(input, 10, 100000);
    expect(results).toHaveLength(3);
    expect(results[0].flagged).toBe(true);
    expect(results[0].varianceVal).toBe(200000);
    expect(results[0].variancePct).toBe(20);
    expect(results[1].flagged).toBe(false);
    expect(results[2].flagged).toBe(false);
  });

  it('Trial Balance check accurately verifies debits equal credits', () => {
    const balancedInput = [
      { account: 'Cash', debit: 500000, credit: 0, rowRef: 1 },
      { account: 'Revenue', debit: 0, credit: 500000, rowRef: 2 },
    ];
    const balancedCheck = runTrialBalanceCheck(balancedInput);
    expect(balancedCheck.balanced).toBe(true);
    expect(balancedCheck.imbalance).toBe(0);

    const imbalancedInput = [
      { account: 'Cash', debit: 500000, credit: 0, rowRef: 1 },
      { account: 'Revenue', debit: 0, credit: 485000, rowRef: 2 },
    ];
    const imbalancedCheck = runTrialBalanceCheck(imbalancedInput);
    expect(imbalancedCheck.balanced).toBe(false);
    expect(imbalancedCheck.imbalance).toBe(15000);
    expect(imbalancedCheck.rows[0].flagged).toBe(true);
  });

  it('Anomaly detection catches statistical outliers and round figures', () => {
    const normalItems = [
      { account: 'Exp 1', amount: 12450, rowRef: 1 },
      { account: 'Exp 2', amount: 11800, rowRef: 2 },
      { account: 'Exp 3', amount: 12100, rowRef: 3 },
      { account: 'Exp 4', amount: 12900, rowRef: 4 },
      { account: 'Exp 5', amount: 11950, rowRef: 5 },
      { account: 'Exp 6', amount: 12300, rowRef: 6 },
      { account: 'Exp 7', amount: 12150, rowRef: 7 },
      { account: 'Exp Outlier', amount: 485123, rowRef: 8 }, // extreme statistical outlier
      { account: 'Exp Round', amount: 200000, rowRef: 9 }, // suspicious round number
    ];

    const anomalies = runAnomalyDetection(normalItems);
    const outlierRow = anomalies.find((a) => a.account === 'Exp Outlier');
    expect(outlierRow?.flagged).toBe(true);
    expect(outlierRow?.flagReason).toContain('Statistical outlier');

    const roundRow = anomalies.find((a) => a.account === 'Exp Round');
    expect(roundRow?.flagged).toBe(true);
    expect(roundRow?.flagReason).toContain('exact round amount');
  });

  it('GL to TB reconciliation flags subledger variances', () => {
    const gl = [
      { account: 'AR', amount: 40000, rowRef: 101 },
      { account: 'AR', amount: 60000, rowRef: 102 },
      { account: 'AP', amount: 30000, rowRef: 103 },
    ];
    const tb = [
      { account: 'AR', balance: 100000, rowRef: 201 }, // matches 40k + 60k
      { account: 'AP', balance: 35000, rowRef: 202 }, // discrepancy of 5k
    ];

    const recon = runGlToTbReconciliation(gl, tb);
    expect(recon[0].flagged).toBe(false);
    expect(recon[1].flagged).toBe(true);
    expect(recon[1].varianceVal).toBe(-5000);
  });

  it('Document review detects placeholders and unexecuted signatures', () => {
    const badDoc = `
      Audit Scope & Methodology
      [INSERT SCOPE HERE]
      TODO: Verify sample count with CAE
      
      Approval Block:
      Prepared by: Jane Auditor
      Approved by: ____________________
    `;
    const checks = runDocumentReview(badDoc);
    const placeholderCheck = checks.find((c) => c.rule === 'Placeholder and Draft Tokens');
    expect(placeholderCheck?.passed).toBe(false);
    expect(placeholderCheck?.findings.length).toBeGreaterThan(0);

    const sigCheck = checks.find((c) => c.rule === 'Formal Signatures and Attestation');
    expect(sigCheck?.passed).toBe(false);
  });
});
"""
write_both('src/lib/analytics.test.ts', analytics_test_ts)

audit_engines_ts = """import { computeSha256 } from './ledger';

/**
 * Deterministic PRNG using Mulberry32 algorithm.
 * Guarantees zero Math.random() usage in all audit sampling and statistical calculations.
 */
export function createDeterministicPrng(seedStr: string): () => number {
  let h = 0;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(31, h) + seedStr.charCodeAt(i) | 0;
  }
  let s = h >>> 0;
  return function () {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Deterministically samples N items from population using seed string.
 */
export function drawSeededSample<T>(population: T[], sampleSize: number, seed: string): T[] {
  if (sampleSize <= 0) return [];
  if (sampleSize >= population.length) return [...population];

  const rng = createDeterministicPrng(seed);
  const pool = [...population];
  const sample: T[] = [];

  for (let i = 0; i < sampleSize; i++) {
    const idx = Math.floor(rng() * pool.length);
    sample.push(pool.splice(idx, 1)[0]);
  }

  return sample;
}

/**
 * Verifies population SHA-256 gate.
 */
export async function verifyPopulationGate(
  populationData: unknown[],
  expectedSha256: string
): Promise<{ matches: boolean; calculatedSha256: string }> {
  const jsonStr = JSON.stringify(populationData);
  const calculatedSha256 = await computeSha256(jsonStr);
  return {
    matches: calculatedSha256 === expectedSha256,
    calculatedSha256,
  };
}

/**
 * Strategic Internal Risk Assessment (SIRA) composite score.
 * Formula: Inherent Risk (40%) + Velocity/Volatility (20%) - Control Quality (30%) + Prior Findings (10%)
 */
export interface SiraFactors {
  financialMateriality: number; // 1-5
  regulatoryScrutiny: number;    // 1-5
  processComplexity: number;     // 1-5
  controlMaturity: number;       // 1-5 (higher is better)
  priorExceptions: number;       // count
}

export function computeSiraScore(factors: SiraFactors): {
  score: number; // 0 - 100
  tier: 'Low' | 'Medium' | 'High' | 'Critical';
} {
  const inherent = (factors.financialMateriality * 0.4 + factors.regulatoryScrutiny * 0.35 + factors.processComplexity * 0.25) * 20; // 0-100
  const controlMitigation = (factors.controlMaturity / 5) * 40; // 0-40 reduction
  const findingsPenalty = Math.min(factors.priorExceptions * 5, 25); // 0-25 penalty

  const rawScore = Math.max(5, Math.min(100, Math.round(inherent - controlMitigation + findingsPenalty)));

  let tier: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
  if (rawScore >= 80) tier = 'Critical';
  else if (rawScore >= 65) tier = 'High';
  else if (rawScore >= 45) tier = 'Medium';

  return { score: rawScore, tier };
}
"""
write_both('src/lib/auditEngines.ts', audit_engines_ts)

audit_engines_test_ts = """import { describe, expect, it } from 'vitest';
import { computeSiraScore, drawSeededSample, verifyPopulationGate } from './auditEngines';

describe('Audit Engines: Seeded Sampling, Population Gate, and SIRA', () => {
  it('Deterministic seeded sampling produces identical samples for identical seeds', () => {
    const population = Array.from({ length: 100 }, (_, i) => ({ id: `row-${i + 1}`, value: i * 10 }));
    const seed = 'PROVIO-AUDIT-2026-Q3-TREASURY';

    const sample1 = drawSeededSample(population, 10, seed);
    const sample2 = drawSeededSample(population, 10, seed);

    expect(sample1).toHaveLength(10);
    expect(sample2).toHaveLength(10);
    expect(sample1).toEqual(sample2);

    // Different seed produces different selection
    const sample3 = drawSeededSample(population, 10, 'DIFFERENT-SEED-999');
    expect(sample1).not.toEqual(sample3);
  });

  it('Population SHA-256 gate verifies population data integrity', async () => {
    const population = [{ id: 1, val: 500 }, { id: 2, val: 800 }];
    const gateCheck = await verifyPopulationGate(population, 'dummy_expected');
    expect(gateCheck.matches).toBe(false);
    expect(gateCheck.calculatedSha256).toBeDefined();

    // Matching hash check
    const validCheck = await verifyPopulationGate(population, gateCheck.calculatedSha256);
    expect(validCheck.matches).toBe(true);
  });

  it('Computes reproducible SIRA scores and tiers', () => {
    const highRiskEntity = computeSiraScore({
      financialMateriality: 5,
      regulatoryScrutiny: 5,
      processComplexity: 4,
      controlMaturity: 2,
      priorExceptions: 3,
    });
    expect(highRiskEntity.score).toBeGreaterThanOrEqual(70);
    expect(['High', 'Critical']).toContain(highRiskEntity.tier);

    const lowRiskEntity = computeSiraScore({
      financialMateriality: 1,
      regulatoryScrutiny: 1,
      processComplexity: 1,
      controlMaturity: 5,
      priorExceptions: 0,
    });
    expect(lowRiskEntity.score).toBeLessThanOrEqual(40);
    expect(lowRiskEntity.tier).toBe('Low');
  });
});
"""
write_both('src/lib/auditEngines.test.ts', audit_engines_test_ts)

glassbox_ts = """import { GlassBoxToken } from '../types';
import { computeSha256 } from './ledger';

export const DEFAULT_ALLOWED_EXTENSIONS = ['.pdf', '.xlsx', '.xls', '.csv', '.png', '.docx'];
export const DEFAULT_MAX_SIZE_BYTES = 25 * 1024 * 1024; // 25 MB

/**
 * Generates a cryptographically random 32-byte token and records its SHA-256 hash.
 * Only the SHA-256 hash is stored.
 */
export async function createGlassBoxTokenRecord(params: {
  workpaperId: string;
  entityId: string;
  orgId: string;
  allowedExtensions?: string[];
  maxSizeBytes?: number;
  validityDays?: number;
}): Promise<{ rawToken: string; record: GlassBoxToken }> {
  // Generate 32 cryptographically secure random bytes
  const bytes = new Uint8Array(32);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 32; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
  }

  const rawToken = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  const tokenHash = await computeSha256(rawToken);
  const now = new Date();
  const validityDays = params.validityDays ?? 7;
  const expires = new Date(now.getTime() + validityDays * 24 * 60 * 60 * 1000);

  const record: GlassBoxToken = {
    tokenHash,
    workpaperId: params.workpaperId,
    entityId: params.entityId,
    orgId: params.orgId,
    createdAt: now.toISOString(),
    expiresAt: expires.toISOString(),
    used: false,
    allowedExtensions: params.allowedExtensions || DEFAULT_ALLOWED_EXTENSIONS,
    maxSizeBytes: params.maxSizeBytes || DEFAULT_MAX_SIZE_BYTES,
  };

  return { rawToken, record };
}

export interface GlassBoxValidationResult {
  valid: boolean;
  record?: GlassBoxToken;
  error?: string;
}

/**
 * Validates a raw token against stored token records.
 * Checks:
 * - Token hash matches
 * - Correct organization ID
 * - Not expired (< 7 days)
 * - Not already used (single-use)
 */
export async function validateGlassBoxToken(
  rawToken: string,
  currentOrgId: string,
  tokens: GlassBoxToken[],
  currentTime = new Date()
): Promise<GlassBoxValidationResult> {
  if (!rawToken || rawToken.length < 32) {
    return { valid: false, error: 'Invalid token structure' };
  }

  const tokenHash = await computeSha256(rawToken);
  const record = tokens.find((t) => t.tokenHash === tokenHash);

  if (!record) {
    return { valid: false, error: 'Token not found or does not exist' };
  }

  // Org boundary check
  if (record.orgId !== currentOrgId) {
    return { valid: false, error: 'Token belongs to an unauthorized organization' };
  }

  // Expiration check
  const expiryDate = new Date(record.expiresAt);
  if (currentTime.getTime() > expiryDate.getTime()) {
    return { valid: false, error: 'Evidence upload link has expired (7-day window passed)' };
  }

  // Single-use check
  if (record.used) {
    return { valid: false, error: 'Evidence upload link has already been used' };
  }

  return { valid: true, record };
}

/**
 * Validates an uploaded file against token constraints.
 */
export function validateEvidenceFile(
  filename: string,
  sizeBytes: number,
  tokenRecord: GlassBoxToken
): { allowed: boolean; error?: string } {
  const ext = '.' + filename.split('.').pop()?.toLowerCase();
  const isAllowedExt = tokenRecord.allowedExtensions.some(
    (allowed) => allowed.toLowerCase() === ext
  );

  if (!isAllowedExt) {
    return {
      allowed: false,
      error: `File extension "${ext}" is not permitted. Allowed: ${tokenRecord.allowedExtensions.join(
        ', '
      )}`,
    };
  }

  if (sizeBytes > tokenRecord.maxSizeBytes) {
    const maxMb = (tokenRecord.maxSizeBytes / (1024 * 1024)).toFixed(0);
    return {
      allowed: false,
      error: `File size exceeds the permitted cap of ${maxMb} MB`,
    };
  }

  return { allowed: true };
}
"""
write_both('src/lib/glassbox.ts', glassbox_ts)

glassbox_test_ts = """import { describe, expect, it } from 'vitest';
import {
  createGlassBoxTokenRecord,
  validateEvidenceFile,
  validateGlassBoxToken,
} from './glassbox';

describe('Task 5: Auditee Glass Box Token Verification & Dropzone Security', () => {
  it('Successfully creates and validates a fresh, valid token for the correct org', async () => {
    const { rawToken, record } = await createGlassBoxTokenRecord({
      workpaperId: 'wp-lcr-01',
      entityId: 'ent-treasury',
      orgId: 'org-alpha',
    });

    const store = [record];
    const validation = await validateGlassBoxToken(rawToken, 'org-alpha', store);

    expect(validation.valid).toBe(true);
    expect(validation.record?.workpaperId).toBe('wp-lcr-01');
    expect(validation.error).toBeUndefined();
  });

  it('Rejects tokens from a different organization (wrong-org)', async () => {
    const { rawToken, record } = await createGlassBoxTokenRecord({
      workpaperId: 'wp-lcr-01',
      entityId: 'ent-treasury',
      orgId: 'org-alpha',
    });

    const store = [record];
    // User / session is authenticated in org-beta attempting to use org-alpha token
    const validation = await validateGlassBoxToken(rawToken, 'org-beta', store);

    expect(validation.valid).toBe(false);
    expect(validation.error).toContain('unauthorized organization');
  });

  it('Rejects expired tokens (> 7 days)', async () => {
    const { rawToken, record } = await createGlassBoxTokenRecord({
      workpaperId: 'wp-lcr-01',
      entityId: 'ent-treasury',
      orgId: 'org-alpha',
    });

    // Fast-forward 8 days into the future
    const eightDaysLater = new Date(Date.now() + 8 * 24 * 60 * 60 * 1000);
    const store = [record];
    const validation = await validateGlassBoxToken(
      rawToken,
      'org-alpha',
      store,
      eightDaysLater
    );

    expect(validation.valid).toBe(false);
    expect(validation.error).toContain('expired');
  });

  it('Rejects reused tokens (single-use guarantee)', async () => {
    const { rawToken, record } = await createGlassBoxTokenRecord({
      workpaperId: 'wp-lcr-01',
      entityId: 'ent-treasury',
      orgId: 'org-alpha',
    });

    // Mark as used after first upload
    const usedRecord = { ...record, used: true, usedAt: new Date().toISOString() };
    const store = [usedRecord];

    const validation = await validateGlassBoxToken(rawToken, 'org-alpha', store);
    expect(validation.valid).toBe(false);
    expect(validation.error).toContain('already been used');
  });

  it('Enforces file extension and maximum size constraints', async () => {
    const { record } = await createGlassBoxTokenRecord({
      workpaperId: 'wp-1',
      entityId: 'ent-1',
      orgId: 'org-alpha',
      allowedExtensions: ['.pdf', '.xlsx'],
      maxSizeBytes: 5 * 1024 * 1024, // 5 MB
    });

    // Allowed extension & valid size
    expect(validateEvidenceFile('report.xlsx', 1024 * 1024, record).allowed).toBe(true);

    // Disallowed extension (.exe)
    const badExt = validateEvidenceFile('payload.exe', 1024, record);
    expect(badExt.allowed).toBe(false);
    expect(badExt.error).toContain('not permitted');

    // Oversized file (6 MB > 5 MB)
    const oversized = validateEvidenceFile('huge.pdf', 6 * 1024 * 1024, record);
    expect(oversized.allowed).toBe(false);
    expect(oversized.error).toContain('exceeds the permitted cap');
  });
});
"""
write_both('src/lib/glassbox.test.ts', glassbox_test_ts)
