import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

command_palette_tsx = """import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Folder, FileText, AlertCircle, ShieldAlert, ArrowRight } from './Icons';
import { useScopedData } from '../../hooks/useScopedData';
import { useApp } from '../../context/AppContext';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const {
    scopedEntities,
    scopedEngagements,
    scopedWorkpapers,
    scopedObservations,
    scopedIssues,
  } = useScopedData();
  const {
    setActiveTab,
    setSelectedEngagementId,
    setSelectedWorkpaperId,
    openInspector,
  } = useApp();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.trim().toLowerCase();

  const matchingEntities = q
    ? scopedEntities.filter(
        (e) => e.name.toLowerCase().includes(q) || e.code.toLowerCase().includes(q)
      )
    : scopedEntities.slice(0, 3);

  const matchingEngagements = q
    ? scopedEngagements.filter(
        (e) => e.title.toLowerCase().includes(q) || e.id.toLowerCase().includes(q)
      )
    : scopedEngagements.slice(0, 3);

  const matchingWorkpapers = q
    ? scopedWorkpapers.filter(
        (w) => w.title.toLowerCase().includes(q) || w.refCode.toLowerCase().includes(q)
      )
    : scopedWorkpapers.slice(0, 3);

  const matchingObservations = q
    ? scopedObservations.filter(
        (o) => o.title.toLowerCase().includes(q) || o.condition.toLowerCase().includes(q)
      )
    : scopedObservations.slice(0, 3);

  const matchingIssues = q
    ? scopedIssues.filter(
        (i) => i.title.toLowerCase().includes(q) || i.department.toLowerCase().includes(q)
      )
    : scopedIssues.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/40 backdrop-blur-xs"
      />

      {/* Palette Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: -10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: -10 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="relative w-full max-w-2xl bg-surface border border-hairline shadow-apple rounded-2xl overflow-hidden z-10"
      >
        {/* Input Field */}
        <div className="flex items-center px-4 py-3.5 border-b border-hairline gap-3 bg-surface">
          <Search className="w-5 h-5 text-secondary stroke-[1.5]" />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search scoped entities, engagements, workpapers, observations..."
            className="w-full bg-transparent text-apple-15 text-primary placeholder:text-tertiary outline-none border-none"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-md text-secondary hover:text-primary transition-colors"
          >
            <X className="w-4 h-4 stroke-[1.5]" />
          </button>
        </div>

        {/* Results Body */}
        <div className="max-h-96 overflow-y-auto p-3 space-y-4">
          {/* Engagements */}
          {matchingEngagements.length > 0 && (
            <div>
              <div className="px-3 py-1 text-apple-11 font-medium text-tertiary uppercase tracking-wider">
                Engagements ({matchingEngagements.length})
              </div>
              {matchingEngagements.map((eng) => (
                <button
                  key={eng.id}
                  onClick={() => {
                    setSelectedEngagementId(eng.id);
                    setActiveTab('plan');
                    onClose();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-surface-hover transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <Folder className="w-4 h-4 text-accent stroke-[1.5]" />
                    <div>
                      <div className="text-apple-13 font-medium text-primary">{eng.title}</div>
                      <div className="text-apple-11 text-secondary">
                        {eng.stage.toUpperCase()} • Due {eng.dueDate}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-tertiary group-hover:text-primary transition-colors stroke-[1.5]" />
                </button>
              ))}
            </div>
          )}

          {/* Workpapers */}
          {matchingWorkpapers.length > 0 && (
            <div>
              <div className="px-3 py-1 text-apple-11 font-medium text-tertiary uppercase tracking-wider">
                Workpapers ({matchingWorkpapers.length})
              </div>
              {matchingWorkpapers.map((wp) => (
                <button
                  key={wp.id}
                  onClick={() => {
                    setSelectedWorkpaperId(wp.id);
                    setActiveTab('workbench');
                    onClose();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-surface-hover transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-secondary stroke-[1.5]" />
                    <div>
                      <div className="text-apple-13 font-medium text-primary">
                        {wp.refCode}: {wp.title}
                      </div>
                      <div className="text-apple-11 text-secondary">
                        {wp.status.replace('_', ' ').toUpperCase()} • {wp.sampleCount} samples
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-tertiary group-hover:text-primary transition-colors stroke-[1.5]" />
                </button>
              ))}
            </div>
          )}

          {/* Observations */}
          {matchingObservations.length > 0 && (
            <div>
              <div className="px-3 py-1 text-apple-11 font-medium text-tertiary uppercase tracking-wider">
                Observations ({matchingObservations.length})
              </div>
              {matchingObservations.map((obs) => (
                <button
                  key={obs.id}
                  onClick={() => {
                    openInspector('observation', obs);
                    onClose();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl hover:bg-surface-hover transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-4 h-4 text-cinnabar stroke-[1.5]" />
                    <div>
                      <div className="text-apple-13 font-medium text-primary">{obs.title}</div>
                      <div className="text-apple-11 text-secondary">
                        {obs.severity.toUpperCase()} • Workpaper {obs.workpaperId}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-tertiary group-hover:text-primary transition-colors stroke-[1.5]" />
                </button>
              ))}
            </div>
          )}

          {/* Empty search state */}
          {q &&
            matchingEntities.length === 0 &&
            matchingEngagements.length === 0 &&
            matchingWorkpapers.length === 0 &&
            matchingObservations.length === 0 && (
              <div className="py-12 text-center text-secondary text-apple-13">
                No scoped items match "{query}" within your permissions.
              </div>
            )}
        </div>
      </motion.div>
    </div>
  );
};
"""
write_both('src/components/common/CommandPalette.tsx', command_palette_tsx)

header_bar_tsx = """import React, { useEffect, useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../context/ThemeContext';
import { useScopedData } from '../../hooks/useScopedData';
import { HeaderCalendarPanel } from '../calendar/HeaderCalendarPanel';
import {
  Calendar as CalendarIcon,
  Search,
  Sun,
  Moon,
  Laptop,
  Settings,
  Users,
  ShieldAlert,
  LogOut,
  ChevronDown,
  Building,
} from './Icons';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderBarProps {
  onOpenCommandPalette: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({ onOpenCommandPalette }) => {
  const {
    currentUser,
    setCurrentUser,
    availableUsers,
    activeTab,
    setActiveTab,
    selectedUniverseId,
    setSelectedUniverseId,
    openInspector,
    setSelectedEngagementId,
  } = useApp();
  const { theme, setTheme } = useTheme();
  const { scopedUniverses, hasMultipleUniverses } = useScopedData();

  // Floating header calendar panel state
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const calendarButtonRef = useRef<HTMLButtonElement>(null);

  // Profile menu state
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  // Close profile dropdown on outside click and Esc
  useEffect(() => {
    if (!isProfileOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        setIsProfileOpen(false);
      }
    };
    const handlePointerDown = (e: MouseEvent) => {
      if (
        profileMenuRef.current &&
        !profileMenuRef.current.contains(e.target as Node)
      ) {
        setIsProfileOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('pointerdown', handlePointerDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('pointerdown', handlePointerDown);
    };
  }, [isProfileOpen]);

  const canAccessAdmin = currentUser.role === 'admin' || currentUser.role === 'cia';

  return (
    <header className="sticky top-0 z-40 w-full h-14 bg-glass border-b border-hairline shadow-apple select-none">
      <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between gap-4">
        {/* Left: Logo & Wordmark in Serif Font */}
        <div className="flex items-center gap-5 shrink-0">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 text-left group transition-opacity hover:opacity-85"
          >
            <div className="w-8 h-8 rounded-xl bg-primary text-canvas flex items-center justify-center font-bold text-apple-15 font-serif-title shadow-xs">
              P
            </div>
            <span className="font-serif-title text-apple-20 font-bold tracking-tight text-primary">
              Provio
            </span>
          </button>

          {/* Universe Switcher: ONLY if user has access to multiple universes */}
          {hasMultipleUniverses && (
            <div className="hidden lg:flex items-center gap-1.5 pl-3 border-l border-hairline">
              <Building className="w-3.5 h-3.5 text-secondary stroke-[1.5]" />
              <select
                aria-label="Select audit universe"
                value={selectedUniverseId || ''}
                onChange={(e) => setSelectedUniverseId(e.target.value || null)}
                className="bg-transparent text-apple-12 font-medium text-secondary hover:text-primary cursor-pointer outline-none border-none py-1 pr-2"
              >
                {scopedUniverses.map((u) => (
                  <option key={u.id} value={u.id} className="bg-surface text-primary">
                    {u.name} ({u.code})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Center: Search button (280px width, "Search or jump to...", Ctrl K badge) */}
        <div className="flex-1 max-w-[280px] hidden sm:block">
          <button
            onClick={onOpenCommandPalette}
            className="w-full h-9 px-3 rounded-xl bg-surface-elevated hover:bg-surface-hover border border-hairline transition-colors flex items-center justify-between text-secondary hover:text-primary shadow-xs"
            title="Search or jump to... (Ctrl K)"
          >
            <div className="flex items-center gap-2 min-w-0">
              <Search className="w-3.5 h-3.5 stroke-[1.5] shrink-0" />
              <span className="text-apple-12 truncate">Search or jump to…</span>
            </div>
            <kbd className="px-1.5 py-0.5 text-apple-11 text-tertiary bg-surface rounded border border-hairline tabular-nums shrink-0">
              ⌘K
            </kbd>
          </button>
        </div>

        {/* Right Zone: Header Calendar Icon Button, Theme Toggle, Profile Menu */}
        <div className="flex items-center gap-2.5 shrink-0 relative">
          {/* Header Calendar Icon Button (§ 3.3) */}
          <div className="relative">
            <button
              ref={calendarButtonRef}
              onClick={() => setIsCalendarOpen(!isCalendarOpen)}
              className={`p-2 rounded-xl transition-colors border ${
                isCalendarOpen
                  ? 'bg-accent-subtle text-accent border-accent'
                  : 'bg-surface-elevated hover:bg-surface-hover text-secondary hover:text-primary border-hairline'
              }`}
              title="Audit Milestones & Calendar Quick-Panel"
              aria-label="Open Audit Calendar Quick-Panel"
            >
              <CalendarIcon className="w-4 h-4 stroke-[1.5]" />
            </button>

            {/* Floating Calendar Panel */}
            <HeaderCalendarPanel
              isOpen={isCalendarOpen}
              onClose={() => setIsCalendarOpen(false)}
              triggerRef={calendarButtonRef}
              onSelectAudit={(auditId) => {
                setSelectedEngagementId(auditId);
                setActiveTab('plan');
                setIsCalendarOpen(false);
              }}
            />
          </div>

          {/* Theme Control: System / Light / Dark */}
          <div className="flex items-center p-0.5 rounded-xl bg-surface-elevated border border-hairline">
            <button
              onClick={() => setTheme('light')}
              className={`p-1.5 rounded-lg transition-colors ${
                theme === 'light' ? 'bg-surface text-primary shadow-xs' : 'text-secondary hover:text-primary'
              }`}
              title="Light mode"
              aria-label="Light mode"
            >
              <Sun className="w-3.5 h-3.5 stroke-[1.5]" />
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`p-1.5 rounded-lg transition-colors ${
                theme === 'dark' ? 'bg-surface text-primary shadow-xs' : 'text-secondary hover:text-primary'
              }`}
              title="Dark mode"
              aria-label="Dark mode"
            >
              <Moon className="w-3.5 h-3.5 stroke-[1.5]" />
            </button>
            <button
              onClick={() => setTheme('system')}
              className={`p-1.5 rounded-lg transition-colors ${
                theme === 'system' ? 'bg-surface text-primary shadow-xs' : 'text-secondary hover:text-primary'
              }`}
              title="System default"
              aria-label="System default"
            >
              <Laptop className="w-3.5 h-3.5 stroke-[1.5]" />
            </button>
          </div>

          {/* Profile Menu Dropdown (§ 3.1) */}
          <div className="relative" ref={profileMenuRef}>
            <button
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-surface-hover transition-colors"
              title="User profile and system administration"
              aria-label="Open user profile menu"
            >
              <div className="w-7 h-7 rounded-full bg-accent-subtle text-accent font-semibold flex items-center justify-center text-apple-12">
                {currentUser.avatar}
              </div>
              <div className="text-left hidden md:block">
                <div className="text-apple-12 font-semibold text-primary leading-tight">
                  {currentUser.name}
                </div>
                <div className="text-apple-11 text-secondary uppercase font-medium">
                  {currentUser.role}
                </div>
              </div>
              <ChevronDown className="w-3 h-3 text-secondary stroke-[1.5] hidden md:block" />
            </button>

            {/* Profile Dropdown Animated with Spring Physics */}
            <AnimatePresence>
              {isProfileOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -6 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -6 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  className="absolute right-0 mt-2 w-64 bg-surface border border-hairline shadow-apple rounded-2xl p-2 z-50 text-apple-12"
                >
                  {/* User summary header */}
                  <div className="px-3 py-2.5 border-b border-hairline">
                    <div className="font-semibold text-primary">{currentUser.name}</div>
                    <div className="text-apple-11 text-secondary truncate">{currentUser.email}</div>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className="px-1.5 py-0.2 rounded text-apple-11 font-semibold uppercase text-accent bg-accent-subtle">
                        {currentUser.role}
                      </span>
                      <span className="text-apple-11 text-tertiary">
                        {currentUser.department || 'Audit'}
                      </span>
                    </div>
                  </div>

                  {/* Menu items */}
                  <div className="py-1">
                    <button
                      onClick={() => {
                        openInspector('account_settings');
                        setIsProfileOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-primary hover:bg-surface-hover transition-colors flex items-center gap-2.5"
                    >
                      <Settings className="w-4 h-4 text-secondary stroke-[1.5]" />
                      <span>Account settings</span>
                    </button>
                    <button
                      onClick={() => {
                        openInspector('people');
                        setIsProfileOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-primary hover:bg-surface-hover transition-colors flex items-center gap-2.5"
                    >
                      <Users className="w-4 h-4 text-secondary stroke-[1.5]" />
                      <span>Team & permissions</span>
                    </button>

                    {/* Admin item: LIVES ONLY in profile menu, gated by role per § 3.1 */}
                    {canAccessAdmin && (
                      <button
                        onClick={() => {
                          openInspector('people');
                          setIsProfileOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 rounded-xl text-primary hover:bg-surface-hover transition-colors flex items-center justify-between"
                      >
                        <div className="flex items-center gap-2.5">
                          <ShieldAlert className="w-4 h-4 text-accent stroke-[1.5]" />
                          <span>Admin Console</span>
                        </div>
                        <span className="text-apple-11 font-medium text-accent bg-accent-subtle px-1.5 py-0.5 rounded">
                          Gated
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Switch viewpoint / sign out */}
                  <div className="pt-1 border-t border-hairline">
                    <div className="px-3 py-1 text-apple-11 text-tertiary uppercase font-medium">
                      Simulate Viewpoint
                    </div>
                    {availableUsers.map((u) => (
                      <button
                        key={u.id}
                        onClick={() => {
                          setCurrentUser(u);
                          setIsProfileOpen(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 rounded-lg text-apple-11 transition-colors flex items-center justify-between ${
                          u.id === currentUser.id
                            ? 'bg-accent-subtle text-accent font-semibold'
                            : 'text-secondary hover:text-primary hover:bg-surface-hover'
                        }`}
                      >
                        <span>{u.name} ({u.role})</span>
                        {u.id === currentUser.id && <span>✓</span>}
                      </button>
                    ))}
                    <button
                      onClick={() => {
                        setIsProfileOpen(false);
                        setCurrentUser(availableUsers[0]);
                      }}
                      className="w-full text-left px-3 py-2 mt-1 rounded-xl text-cinnabar hover:bg-cinnabar-subtle transition-colors flex items-center gap-2.5"
                    >
                      <LogOut className="w-4 h-4 stroke-[1.5]" />
                      <span>Sign out</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  );
};
"""
write_both('src/components/common/HeaderBar.tsx', header_bar_tsx)

nav_strip_tsx = """import React, { useRef, useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import {
  LayoutDashboard,
  Calendar,
  ClipboardList,
  Network,
  AlertTriangle,
  FileBarChart,
} from './Icons';

export const NavStrip: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();
  const { currentUser } = useScopedData();
  const trackRef = useRef<HTMLDivElement>(null);

  // Tabs specified by § 3.2 (No Workbench tab; audit files open from everywhere)
  const allTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'plan', label: 'Audit Plan', icon: ClipboardList },
    { id: 'universe', label: 'Audit Universe', icon: Network },
    { id: 'issues', label: 'Issues Register', icon: AlertTriangle },
    { id: 'reports', label: 'Reports', icon: FileBarChart },
  ];

  // Filter tabs based on role capabilities
  const visibleTabs = allTabs.filter((tab) => {
    if (tab.id === 'reports' && currentUser.role === 'auditee') return false;
    return true;
  });

  const count = visibleTabs.length;
  const activeIndex = Math.max(
    0,
    visibleTabs.findIndex((t) => t.id === activeTab)
  );

  // Dragging state for draggable pill based on index arithmetic
  const [isDragging, setIsDragging] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  const calculateIndexFromPointer = (clientX: number): number => {
    if (!trackRef.current) return activeIndex;
    const rect = trackRef.current.getBoundingClientRect();
    const relativeX = (clientX - rect.left) / rect.width;
    const rawIndex = relativeX * count - 0.5;
    return Math.max(0, Math.min(count - 1, rawIndex));
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    const idx = calculateIndexFromPointer(e.clientX);
    setDragIndex(idx);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const idx = calculateIndexFromPointer(e.clientX);
    setDragIndex(idx);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    const rawIndex = calculateIndexFromPointer(e.clientX);
    const nearestIndex = Math.round(rawIndex);
    const boundedIndex = Math.max(0, Math.min(count - 1, nearestIndex));
    setDragIndex(null);
    setActiveTab(visibleTabs[boundedIndex].id);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
  };

  const currentDisplayIndex = dragIndex !== null ? dragIndex : activeIndex;
  const pillLeftPercent = (currentDisplayIndex / count) * 100;
  const pillWidthPercent = 100 / count;

  return (
    <nav
      aria-label="Navigation Strip"
      className="w-full bg-surface border-b border-hairline py-1 px-6 shadow-xs select-none"
    >
      <div className="max-w-7xl mx-auto">
        <div
          ref={trackRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={() => {
            setIsDragging(false);
            setDragIndex(null);
          }}
          className="relative grid rounded-xl p-1 bg-surface-sunken cursor-grab active:cursor-grabbing touch-none"
          style={{ gridTemplateColumns: `repeat(${count}, minmax(0, 1fr))` }}
          data-testid="nav-strip-track"
        >
          {/* DRAGGABLE Pill positioned by index arithmetic: index / count * 100% */}
          <motion.div
            data-testid="nav-draggable-pill"
            style={{
              position: 'absolute',
              top: 4,
              bottom: 4,
              left: `${pillLeftPercent}%`,
              width: `${pillWidthPercent}%`,
            }}
            animate={
              isDragging
                ? undefined
                : {
                    left: `${(activeIndex / count) * 100}%`,
                  }
            }
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 30,
            }}
            className="rounded-lg bg-surface shadow-soft border border-hairline pointer-events-none"
          >
            {/* 2px accent underline on the active tab (§ 3.2 requirement) */}
            <div className="h-[2px] bg-accent absolute bottom-0 inset-x-3 rounded-full" />
          </motion.div>

          {/* Tab Buttons (Equal-width CSS-grid columns) */}
          {visibleTabs.map((tab, idx) => {
            const Icon = tab.icon;
            const isActive = activeIndex === idx;

            return (
              <button
                key={tab.id}
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveTab(tab.id);
                }}
                className={`relative z-10 flex items-center justify-center gap-2 py-2 px-2 text-apple-13 font-medium transition-colors text-center truncate ${
                  isActive
                    ? 'text-primary font-semibold'
                    : 'text-secondary hover:text-primary'
                }`}
                title={tab.label}
              >
                <Icon className="w-4 h-4 stroke-[1.5] shrink-0" />
                {/* No horizontal scroll on narrow widths: collapse labels to icons (§ 3.2 requirement) */}
                <span className="hidden sm:inline truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
"""
write_both('src/components/common/NavStrip.tsx', nav_strip_tsx)

nav_strip_test_tsx = """import React from 'react';
import { describe, expect, it, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { NavStrip } from './NavStrip';
import { AppProvider } from '../../context/AppContext';
import { ThemeProvider } from '../../context/ThemeContext';

describe('§ 3.2 NavStrip Component & Draggable Pill', () => {
  it('renders all 6 canonical tabs without Workbench tab', () => {
    render(
      <ThemeProvider>
        <AppProvider>
          <NavStrip />
        </AppProvider>
      </ThemeProvider>
    );

    // Assert the 6 canonical tabs exist
    expect(screen.getByText('Dashboard')).toBeDefined();
    expect(screen.getByText('Calendar')).toBeDefined();
    expect(screen.getByText('Audit Plan')).toBeDefined();
    expect(screen.getByText('Audit Universe')).toBeDefined();
    expect(screen.getByText('Issues Register')).toBeDefined();
    expect(screen.getByText('Reports')).toBeDefined();

    // Verify Workbench is NOT a navigation tab (§ 3.2 requirement)
    expect(screen.queryByText('Workbench')).toBeNull();
  });

  it('renders draggable pill container with CSS grid layout and 2px accent underline', () => {
    const { container } = render(
      <ThemeProvider>
        <AppProvider>
          <NavStrip />
        </AppProvider>
      </ThemeProvider>
    );

    const track = container.querySelector('[data-testid="nav-strip-track"]');
    expect(track).toBeDefined();

    const pill = container.querySelector('[data-testid="nav-draggable-pill"]');
    expect(pill).toBeDefined();

    // Verify 2px accent underline inside pill
    const accentLine = pill?.querySelector('.bg-accent');
    expect(accentLine).toBeDefined();
  });

  it('switches active tab when a tab button is clicked', () => {
    render(
      <ThemeProvider>
        <AppProvider>
          <NavStrip />
        </AppProvider>
      </ThemeProvider>
    );

    const calendarTabButton = screen.getByTitle('Calendar');
    fireEvent.click(calendarTabButton);

    // Calendar button should now have active font class
    expect(calendarTabButton.className).toContain('text-primary');
  });
});
"""
write_both('src/components/common/NavStrip.test.tsx', nav_strip_test_tsx)

account_settings_tsx = """import React from 'react';
import { useTheme, ThemePreset } from '../../context/ThemeContext';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, Palette, Sun, Moon, Laptop, Shield } from './Icons';

interface AccountSettingsProps {
  onClose?: () => void;
}

export const AccountSettingsModal: React.FC<AccountSettingsProps> = ({ onClose }) => {
  const { theme, setTheme, preset, setPreset } = useTheme();
  const { currentUser } = useApp();

  const presets: { id: ThemePreset; name: string; description: string; colors: string[] }[] = [
    {
      id: 'ledger',
      name: 'Ledger (Original Spec Default)',
      description: 'Warm paper light / Coffee graphite dark with authentic Verdigris and Cinnabar.',
      colors: ['var(--canvas)', 'var(--surface)', 'var(--accent-verdigris)', 'var(--accent-cinnabar)'],
    },
    {
      id: 'graphite',
      name: 'Graphite',
      description: 'Cool crisp light / Deep graphite dark with precision hairline borders.',
      colors: ['var(--canvas)', 'var(--surface)', 'var(--accent-primary)', 'var(--accent-verdigris)'],
    },
    {
      id: 'ink',
      name: 'Ink (Dark-First)',
      description: 'Pure dark-first canvas with elevated surface and Verdigris accents.',
      colors: ['var(--canvas)', 'var(--surface)', 'var(--accent-verdigris)', 'var(--accent-cinnabar)'],
    },
  ];

  return (
    <div className="space-y-6">
      <div className="border-b border-hairline pb-4">
        <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
          Visual Identity &amp; System Configuration
        </span>
        <h3 className="text-apple-20 font-bold text-primary mt-1">
          Account &amp; Appearance Settings
        </h3>
        <p className="text-apple-12 text-secondary mt-1">
          Select your desired theme preset and appearance preferences.
        </p>
      </div>

      {/* Account Profile Card */}
      <div className="p-4 rounded-xl bg-surface-elevated border border-hairline flex items-center justify-between">
        <div>
          <div className="text-apple-13 font-semibold text-primary">{currentUser.name}</div>
          <div className="text-apple-12 text-secondary">{currentUser.email}</div>
          <div className="text-apple-11 text-tertiary mt-1">
            Role: <span className="uppercase font-semibold text-primary">{currentUser.role}</span> • Department: {currentUser.department}
          </div>
        </div>
        <div className="w-10 h-10 rounded-full bg-accent-subtle text-accent font-bold flex items-center justify-center text-apple-13">
          {currentUser.avatar}
        </div>
      </div>

      {/* Theme Presets Selection (Section 4 Requirement) */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-accent stroke-[1.5]" />
          <h4 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
            Curated Theme Presets
          </h4>
        </div>

        <div className="space-y-3">
          {presets.map((p) => {
            const isSelected = preset === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setPreset(p.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-4 ${
                  isSelected
                    ? 'bg-accent-subtle border-accent shadow-xs'
                    : 'bg-surface hover:bg-surface-hover border-hairline'
                }`}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-apple-13 font-semibold text-primary">{p.name}</span>
                    {p.id === 'ledger' && (
                      <span className="px-2 py-0.5 rounded text-apple-11 font-medium text-verdigris bg-verdigris-subtle border border-verdigris">
                        Source of Truth
                      </span>
                    )}
                  </div>
                  <p className="text-apple-12 text-secondary leading-relaxed">{p.description}</p>
                  {/* Swatches */}
                  <div className="flex items-center gap-2 pt-1">
                    {p.colors.map((c, i) => (
                      <span
                        key={i}
                        className="w-4 h-4 rounded-full border border-hairline shadow-xs"
                        style={{ backgroundColor: c }}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
                {isSelected && (
                  <CheckCircle2 className="w-5 h-5 text-accent stroke-[1.5] shrink-0 mt-0.5" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="space-y-2 pt-4 border-t border-hairline">
        <label className="text-apple-12 font-semibold text-secondary uppercase tracking-wider">
          Appearance Mode
        </label>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'light', label: 'Light', icon: Sun },
            { id: 'dark', label: 'Dark', icon: Moon },
            { id: 'system', label: 'System Default', icon: Laptop },
          ].map((m) => {
            const Icon = m.icon;
            const isSelected = theme === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setTheme(m.id as any)}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-apple-12 font-medium transition-colors ${
                  isSelected
                    ? 'bg-surface text-primary border-accent shadow-xs'
                    : 'bg-surface-elevated text-secondary hover:text-primary border-hairline'
                }`}
              >
                <Icon className="w-4 h-4 stroke-[1.5]" />
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/common/AccountSettingsModal.tsx', account_settings_tsx)

people_access_tsx = """import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { User, Role } from '../../types';
import { Check, Shield, User as UserIcon, Building } from './Icons';

export const PeopleAccessModal: React.FC = () => {
  const { availableUsers, currentUser, setCurrentUser, closeInspector } = useApp();
  const { scopedUniverses } = useScopedData();
  const [selectedUser, setSelectedUser] = useState<User>(currentUser);

  const handleSwitchUser = (user: User) => {
    setSelectedUser(user);
    setCurrentUser(user);
  };

  const getRoleBadge = (role: Role) => {
    switch (role) {
      case 'cia':
        return <span className="px-2 py-0.5 text-apple-11 font-semibold rounded-md bg-verdigris-subtle text-verdigris border border-verdigris">Chief Audit Executive</span>;
      case 'reviewer':
        return <span className="px-2 py-0.5 text-apple-11 font-semibold rounded-md bg-accent-subtle text-accent border border-accent">Audit Reviewer (4-Eyes)</span>;
      case 'preparer':
        return <span className="px-2 py-0.5 text-apple-11 font-semibold rounded-md bg-surface-sunken text-primary border border-hairline">Audit Preparer</span>;
      case 'auditee':
        return <span className="px-2 py-0.5 text-apple-11 font-semibold rounded-md bg-cinnabar-subtle text-cinnabar border border-cinnabar">Entity Auditee</span>;
      case 'admin':
        return <span className="px-2 py-0.5 text-apple-11 font-semibold rounded-md bg-verdigris-subtle text-verdigris border border-verdigris">System Administrator</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <Shield className="w-4 h-4 text-verdigris" />
          <span>Role-Based Access Control (RBAC) &amp; Scope Impersonation</span>
        </div>
        <p className="text-apple-12 text-secondary">
          Select an identity from the verified audit directory to simulate scoped visibility and gating permissions across the immutable ledger.
        </p>
      </div>

      <div className="space-y-3">
        <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
          Active Personnel Directory
        </h3>
        <div className="divide-y divide-hairline border border-hairline rounded-xl overflow-hidden bg-surface">
          {availableUsers.map((user) => {
            const isCurrent = user.id === currentUser.id;
            return (
              <div
                key={user.id}
                onClick={() => handleSwitchUser(user)}
                className={`p-4 flex items-center justify-between cursor-pointer transition-colors ${
                  isCurrent ? 'bg-surface-hover' : 'hover:bg-surface-hover'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full bg-surface-sunken border border-hairline flex items-center justify-center font-medium text-primary text-apple-13 shrink-0">
                    {user.avatar ? (
                      <span className="font-semibold">{user.name.split(' ').map((n) => n[0]).join('')}</span>
                    ) : (
                      <UserIcon className="w-4 h-4 text-secondary" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-apple-13 font-medium text-primary truncate">{user.name}</span>
                      {isCurrent && (
                        <span className="text-apple-11 text-verdigris font-semibold flex items-center gap-1">
                          <Check className="w-3 h-3" /> Active
                        </span>
                      )}
                    </div>
                    <div className="text-apple-11 text-secondary truncate flex items-center gap-2 mt-0.5">
                      <span>{user.email}</span>
                      {user.department && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Building className="w-3 h-3" /> {user.department}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="shrink-0 pl-3">
                  {getRoleBadge(user.role)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="pt-4 border-t border-hairline flex justify-end">
        <button
          type="button"
          onClick={closeInspector}
          className="px-4 py-2 text-apple-13 font-medium rounded-lg bg-surface border border-hairline text-primary hover:bg-surface-hover transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );
};
"""
write_both('src/components/common/PeopleAccessModal.tsx', people_access_tsx)

red_thread_tsx = """import React from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { GitCommit, ShieldCheck, ArrowRight, CheckCircle2, AlertTriangle, Layers } from './Icons';

export const RedThreadModal: React.FC = () => {
  const { inspector, closeInspector } = useApp();
  const { scopedWorkpapers, scopedEngagements, scopedObservations, scopedIssues, scopedCapItems } = useScopedData();

  const obs = inspector.data?.observation || scopedObservations[0];
  const wp = obs ? scopedWorkpapers.find((w) => w.id === obs.workpaperId) : null;
  const eng = wp ? scopedEngagements.find((e) => e.id === wp.engagementId) : null;
  const iss = obs ? scopedIssues.find((i) => i.observationId === obs.id) : null;
  const cap = iss ? scopedCapItems.find((c) => c.title.toLowerCase().includes(iss.title.toLowerCase().slice(0, 10))) : null;

  const lineageNodes = [
    {
      stage: '1. Audit Universe & Plan',
      title: eng?.title || 'Global Treasury Assurance',
      ref: eng?.id || 'ENG-2026-001',
      status: 'In Progress',
      color: 'verdigris',
    },
    {
      stage: '2. Working Paper & Test Gate',
      title: wp?.title || 'Intraday Liquidity Buffer Test',
      ref: wp?.refCode || 'WP-TREAS-01',
      status: wp?.sealed ? 'Cryptographically Sealed' : 'Verified Population',
      color: 'verdigris',
    },
    {
      stage: '3. Audit Observation',
      title: obs?.title || 'Delayed Posting in HQLA Buffer',
      ref: obs?.id || 'OBS-2026-001',
      status: `${obs?.severity?.toUpperCase() || 'HIGH'} Severity`,
      color: 'cinnabar',
    },
    {
      stage: '4. Executive Issue Register',
      title: iss?.title || 'Treasury Intraday Cash Pipeline STP Automation',
      ref: iss?.id || 'ISS-2026-001',
      status: iss?.status || 'Management Response',
      color: 'cinnabar',
    },
    {
      stage: '5. Corrective Action Plan (CAP)',
      title: cap?.title || 'Deploy automated SWIFT MT900/910 parser',
      ref: cap?.id || 'CAP-2026-001',
      status: cap?.status || 'Open',
      color: 'amber',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <GitCommit className="w-4 h-4 text-accent" />
          <span>Red Thread — Audit Lineage &amp; Proof Chain</span>
        </div>
        <p className="text-apple-12 text-secondary">
          Unbroken deterministic lineage mapping high-level universe objectives down to atomic test samples and corrective actions.
        </p>
      </div>

      <div className="relative pl-6 space-y-8 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-hairline">
        {lineageNodes.map((node, idx) => (
          <div key={idx} className="relative group">
            <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-surface border-2 border-accent flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-accent" />
            </div>
            <div className="p-4 rounded-xl bg-surface border border-hairline shadow-soft space-y-2 group-hover:bg-surface-hover transition-colors">
              <div className="flex items-center justify-between text-apple-11">
                <span className="text-secondary font-medium uppercase tracking-wider">{node.stage}</span>
                <span className="font-mono text-tertiary">{node.ref}</span>
              </div>
              <div className="text-apple-15 font-semibold text-primary">{node.title}</div>
              <div className="flex items-center gap-2 text-apple-12">
                <span className={`px-2 py-0.5 rounded text-apple-11 font-medium bg-${node.color}-subtle text-${node.color}`}>
                  {node.status}
                </span>
                <span className="text-secondary">• Deterministically Attested</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="pt-4 border-t border-hairline flex justify-end">
        <button
          type="button"
          onClick={closeInspector}
          className="px-4 py-2 text-apple-13 font-medium rounded-lg bg-surface border border-hairline text-primary hover:bg-surface-hover transition-colors"
        >
          Close Lineage
        </button>
      </div>
    </div>
  );
};
"""
write_both('src/components/common/RedThreadModal.tsx', red_thread_tsx)

glassbox_share_tsx = """import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { createGlassBoxTokenRecord } from '../../lib/glassbox';
import { Share2, Check, Clock, ShieldCheck, Lock } from './Icons';

export const GlassBoxShareModal: React.FC = () => {
  const { inspector, closeInspector, appendLedger, currentUser } = useApp();
  const workpaper = inspector.data?.workpaper;

  const [copied, setCopied] = useState(false);
  const [tokenLink, setTokenLink] = useState<string | null>(null);
  const [validityDays, setValidityDays] = useState(7);

  const handleGenerateLink = async () => {
    if (!workpaper) return;

    const { rawToken, record } = await createGlassBoxTokenRecord({
      workpaperId: workpaper.id,
      entityId: workpaper.entityId,
      orgId: 'provio-corp-tenant',
      validityDays,
    });

    const shareUrl = `${window.location.origin}/e/${rawToken}`;
    setTokenLink(shareUrl);

    // Ledger audit event
    await appendLedger({
      actorId: currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      eventType: 'evidence_drop',
      entityId: workpaper.entityId,
      recordId: workpaper.id,
      recordType: 'workpaper',
      payloadSummary: `Issued GlassBox secure upload token for WP ${workpaper.refCode} (Expires in ${validityDays} days)`,
      payloadData: { tokenHash: record.tokenHash, expiresAt: record.expiresAt },
    });
  };

  const handleCopy = () => {
    if (!tokenLink) return;
    navigator.clipboard.writeText(tokenLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <Share2 className="w-4 h-4 text-verdigris" />
          <span>GlassBox — Zero-Trust Evidence Collection Portal</span>
        </div>
        <p className="text-apple-12 text-secondary">
          Generate an ephemeral, single-use upload URL for external auditees. Uploaded files are SHA-256 hashed and attested to the ledger before storage.
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-apple-12 font-medium text-secondary mb-1">
            Target Working Paper
          </label>
          <div className="p-3 rounded-lg bg-surface border border-hairline text-apple-13 font-medium text-primary">
            {workpaper?.refCode || 'WP-TREAS-01'} • {workpaper?.title || 'Treasury Intraday Liquidity'}
          </div>
        </div>

        <div>
          <label className="block text-apple-12 font-medium text-secondary mb-1">
            Token Validity Window
          </label>
          <select
            value={validityDays}
            onChange={(e) => setValidityDays(Number(e.target.value))}
            className="w-full p-2.5 rounded-lg bg-surface border border-hairline text-apple-13 text-primary focus:outline-none"
          >
            <option value={1}>24 Hours (High Security)</option>
            <option value={7}>7 Days (Standard SLA)</option>
            <option value={14}>14 Days (Extended Audit Cycle)</option>
          </select>
        </div>

        {!tokenLink ? (
          <button
            type="button"
            onClick={handleGenerateLink}
            className="w-full py-2.5 px-4 rounded-lg bg-surface border border-hairline hover:bg-surface-hover text-apple-13 font-semibold text-primary transition-colors flex items-center justify-center gap-2"
          >
            <Lock className="w-4 h-4 text-verdigris" />
            Generate Cryptographic Upload Token
          </button>
        ) : (
          <div className="space-y-3 p-4 rounded-xl bg-surface border border-hairline">
            <div className="flex items-center justify-between text-apple-12 text-secondary">
              <span className="font-semibold text-primary flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-verdigris" />
                Active Upload Link
              </span>
              <span className="flex items-center gap-1 text-apple-11">
                <Clock className="w-3.5 h-3.5" /> Single-Use Token
              </span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={tokenLink}
                className="w-full p-2 rounded-lg bg-surface-sunken font-mono text-apple-11 text-secondary border border-hairline select-all"
              />
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-2 rounded-lg bg-surface-sunken border border-hairline text-apple-13 font-medium text-primary hover:bg-surface-hover transition-colors shrink-0"
              >
                {copied ? <Check className="w-4 h-4 text-verdigris" /> : 'Copy'}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="pt-4 border-t border-hairline flex justify-end">
        <button
          type="button"
          onClick={closeInspector}
          className="px-4 py-2 text-apple-13 font-medium rounded-lg bg-surface border border-hairline text-primary hover:bg-surface-hover transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );
};
"""
write_both('src/components/common/GlassBoxShareModal.tsx', glassbox_share_tsx)
