import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

cap_table_tsx = """import React, { useState } from 'react';
import { AuditCapItem, CapStatus, RetestStatus, Severity } from '../../types';
import { useFilterStore } from '../../context/FilterStore';
import { useApp } from '../../context/AppContext';
import { HoverPreview } from '../common/HoverPreview';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  ExternalLink,
  Filter,
  RotateCcw,
  Search,
  ShieldCheck,
} from '../common/Icons';

interface CapTableProps {
  capItems: AuditCapItem[];
}

export const CapTable: React.FC<CapTableProps> = ({ capItems }) => {
  const filter = useFilterStore();
  const { openInspector, updateCapStatus } = useApp();
  const [sortField, setSortField] = useState<keyof AuditCapItem>('agingDays');
  const [sortAsc, setSortAsc] = useState<boolean>(false);

  const handleSort = (field: keyof AuditCapItem) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false); // Default descending for audit urgency
    }
  };

  const sortedItems = [...capItems].sort((a, b) => {
    let aVal = a[sortField];
    let bVal = b[sortField];

    if (typeof aVal === 'string') {
      return sortAsc
        ? (aVal as string).localeCompare(bVal as string)
        : (bVal as string).localeCompare(aVal as string);
    }
    return sortAsc ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
  });

  const getSeverityBadge = (sev: Severity) => {
    switch (sev) {
      case 'critical':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-cinnabar-subtle text-cinnabar border border-cinnabar">
            Critical
          </span>
        );
      case 'high':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-amber-subtle text-amber border border-amber">
            High
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold uppercase bg-verdigris-subtle text-verdigris border border-verdigris">
            Medium
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-medium uppercase bg-surface-elevated text-secondary border border-hairline">
            Low
          </span>
        );
    }
  };

  const getStatusBadge = (status: CapStatus, dueDate: string) => {
    const isOverdue = status === 'Overdue' || (status !== 'Closed' && dueDate < '2026-09-30');
    if (isOverdue) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-cinnabar-subtle text-cinnabar border border-cinnabar">
          <span className="w-1.5 h-1.5 rounded-full bg-cinnabar animate-pulse" />
          Overdue
        </span>
      );
    }
    switch (status) {
      case 'Closed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-apple-11 font-medium bg-verdigris-subtle text-verdigris">
            <CheckCircle2 className="w-3 h-3 stroke-[2]" />
            Closed
          </span>
        );
      case 'Pending validation':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-apple-11 font-medium bg-accent-subtle text-accent">
            <Clock className="w-3 h-3 stroke-[2]" />
            Pending Validation
          </span>
        );
      case 'In progress':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-apple-11 font-medium bg-amber-subtle text-amber">
            In Progress
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-full text-apple-11 font-medium bg-surface-elevated text-secondary border border-hairline">
            Open
          </span>
        );
    }
  };

  const getRetestBadge = (retest: RetestStatus) => {
    switch (retest) {
      case 'Passed':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-verdigris-subtle text-verdigris">
            Passed ✓
          </span>
        );
      case 'Failed':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-cinnabar-subtle text-cinnabar">
            Failed ✗
          </span>
        );
      case 'In retest':
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 font-medium bg-amber-subtle text-amber">
            In Retest
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-apple-11 text-tertiary">
            Not Tested
          </span>
        );
    }
  };

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-6 shadow-apple space-y-4">
      {/* Header with Search and Clear Filter Chip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-apple-17 font-bold text-primary">
              Corrective Action Plans Register
            </h3>
            <span className="px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-surface-elevated text-secondary border border-hairline tabular-nums">
              {sortedItems.length} Actions
            </span>
          </div>
          <p className="text-apple-12 text-secondary mt-0.5">
            Operational remediation commitments, aging days, and independent re-test verification
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Quick Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-secondary absolute left-3 top-2.5 stroke-[1.5]" />
            <input
              type="text"
              placeholder="Search actions or owner…"
              value={filter.searchQuery}
              onChange={(e) => filter.setSearchQuery(e.target.value)}
              className="h-8 pl-8 pr-3 text-apple-12 rounded-xl bg-surface-elevated border border-hairline text-primary placeholder:text-tertiary outline-none focus:border-accent w-48 sm:w-56"
            />
          </div>

          {filter.hasActiveFilters() && (
            <button
              onClick={() => filter.clearFilters()}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-accent-subtle border border-accent text-accent text-apple-11 font-medium hover:opacity-85 transition-opacity"
            >
              <RotateCcw className="w-3 h-3 stroke-[1.5]" />
              <span>Clear filters</span>
            </button>
          )}
        </div>
      </div>

      {/* Cross-Filter Pills */}
      {filter.hasActiveFilters() && (
        <div className="flex flex-wrap items-center gap-2 pt-1 pb-2 border-b border-hairline text-apple-11">
          <span className="text-tertiary">Active criteria:</span>
          {filter.department && (
            <span className="px-2 py-0.5 rounded-lg bg-surface-elevated border border-hairline text-primary flex items-center gap-1">
              <span>Department: <strong>{filter.department}</strong></span>
              <button onClick={() => filter.setDepartment(null)} className="hover:text-cinnabar">×</button>
            </span>
          )}
          {filter.severity && (
            <span className="px-2 py-0.5 rounded-lg bg-surface-elevated border border-hairline text-primary flex items-center gap-1">
              <span>Severity: <strong>{filter.severity}</strong></span>
              <button onClick={() => filter.setSeverity(null)} className="hover:text-cinnabar">×</button>
            </span>
          )}
          {filter.status && (
            <span className="px-2 py-0.5 rounded-lg bg-surface-elevated border border-hairline text-primary flex items-center gap-1">
              <span>Status: <strong>{filter.status}</strong></span>
              <button onClick={() => filter.setStatus(null)} className="hover:text-cinnabar">×</button>
            </span>
          )}
        </div>
      )}

      {/* Table (§ 3.4 requirements: id, action, owner, department, severity, due date, aging in days, status, re-test status) */}
      <div className="overflow-x-auto rounded-xl border border-hairline">
        <table className="w-full text-left text-apple-12 border-collapse">
          <thead>
            <tr className="bg-surface-elevated border-b border-hairline text-secondary text-apple-11 font-semibold uppercase tracking-wider select-none">
              <th
                onClick={() => handleSort('id')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                ID {sortField === 'id' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('action')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Remediation Action {sortField === 'action' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('department')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Department {sortField === 'department' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('owner')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Action Owner {sortField === 'owner' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('severity')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Severity {sortField === 'severity' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('dueDate')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Due Date {sortField === 'dueDate' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('agingDays')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors text-right"
              >
                Aging (Days) {sortField === 'agingDays' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('status')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Status {sortField === 'status' && (sortAsc ? '↑' : '↓')}
              </th>
              <th
                onClick={() => handleSort('retestStatus')}
                className="py-3 px-3 cursor-pointer hover:text-primary transition-colors"
              >
                Re-Test {sortField === 'retestStatus' && (sortAsc ? '↑' : '↓')}
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-hairline">
            {sortedItems.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-8 text-center text-apple-12 text-secondary">
                  No corrective actions match the current scoped filter criteria.
                </td>
              </tr>
            ) : (
              sortedItems.map((item) => {
                const previewContent = {
                  title: `${item.id}: ${item.title}`,
                  category: `${item.department} Remediation Plan`,
                  subtitle: item.action,
                  status: item.status,
                  statusType:
                    item.status === 'Overdue' || item.dueDate < '2026-09-30'
                      ? ('cinnabar' as const)
                      : item.status === 'Closed'
                      ? ('verdigris' as const)
                      : ('amber' as const),
                  owner: item.owner,
                  dueDate: item.dueDate,
                  hint: 'Click to open full remediation inspector',
                };

                return (
                  <tr
                    key={item.id}
                    onClick={() =>
                      openInspector('cap_inspector', {
                        cap: item,
                        department: item.department,
                      })
                    }
                    className="hover:bg-surface-hover transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-3 font-mono font-medium text-accent truncate">
                      {item.id}
                    </td>
                    <td className="py-3 px-3 font-medium text-primary max-w-xs truncate">
                      <HoverPreview content={previewContent} className="inline-block truncate max-w-xs">
                        <span>{item.title}</span>
                      </HoverPreview>
                    </td>
                    <td className="py-3 px-3 text-secondary truncate">
                      {item.department}
                    </td>
                    <td className="py-3 px-3 text-primary truncate">
                      {item.owner}
                    </td>
                    <td className="py-3 px-3 shrink-0">
                      {getSeverityBadge(item.severity)}
                    </td>
                    <td className="py-3 px-3 text-secondary tabular-nums truncate">
                      {item.dueDate}
                    </td>
                    <td className="py-3 px-3 text-right font-serif-numeral font-bold text-primary tabular-nums">
                      {item.agingDays} d
                    </td>
                    <td className="py-3 px-3 shrink-0">
                      {getStatusBadge(item.status, item.dueDate)}
                    </td>
                    <td className="py-3 px-3 shrink-0">
                      {getRetestBadge(item.retestStatus)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
"""
write_both('src/components/dashboard/CapTable.tsx', cap_table_tsx)

sunburst_tsx = """import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { useFilterStore } from '../../context/FilterStore';
import { AuditIssue } from '../../types';
import { HoverPreview } from '../common/HoverPreview';

interface SunburstProps {
  deptMap: Record<string, { total: number; issues: AuditIssue[] }>;
}

interface SunburstNode {
  name: string;
  department?: string;
  severity?: string;
  value?: number;
  children?: SunburstNode[];
  color?: string;
}

export const D3Sunburst: React.FC<SunburstProps> = ({ deptMap }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const filter = useFilterStore();
  const [hoveredNode, setHoveredNode] = useState<{
    title: string;
    subtitle?: string;
    category?: string;
    status?: string;
    statusType?: 'verdigris' | 'cinnabar' | 'amber' | 'neutral';
    owner?: string;
    dueDate?: string;
    exceptionsCount?: number;
    metrics?: { label: string; value: string | number }[];
  } | null>(null);

  // Build hierarchical data
  const rootData: SunburstNode = {
    name: 'Audit Scope',
    children: Object.entries(deptMap).map(([dept, data]) => {
      const severityCounts: Record<string, number> = {};
      data.issues.forEach((iss) => {
        severityCounts[iss.severity] = (severityCounts[iss.severity] || 0) + 1;
      });

      return {
        name: dept,
        department: dept,
        children: Object.entries(severityCounts).map(([sev, count]) => ({
          name: `${dept} - ${sev.toUpperCase()}`,
          department: dept,
          severity: sev,
          value: count,
        })),
      };
    }),
  };

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 320;
    const height = 320;
    const radius = width / 2;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const g = svg
      .append('g')
      .attr('transform', `translate(${radius},${radius})`);

    const partition = (data: SunburstNode) => {
      const root = d3
        .hierarchy(data)
        .sum((d) => d.value || (d.children ? 0 : 1))
        .sort((a, b) => (b.value || 0) - (a.value || 0));
      return d3.partition<SunburstNode>().size([2 * Math.PI, radius])(root);
    };

    const root = partition(rootData);

    const arc = d3
      .arc<d3.HierarchyRectangularNode<SunburstNode>>()
      .startAngle((d) => d.x0)
      .endAngle((d) => d.x1)
      .padAngle((d) => Math.min((d.x1 - d.x0) / 2, 0.015))
      .padRadius(radius / 2)
      .innerRadius((d) => d.y0)
      .outerRadius((d) => Math.max(d.y0, d.y1 - 2));

    // Department colors mapped via Apple design token variables
    const getFill = (d: d3.HierarchyRectangularNode<SunburstNode>) => {
      if (d.depth === 0) return 'transparent';
      const isSelected = filter.department && d.data.department === filter.department;
      if (d.depth === 1) {
        // Inner ring: department
        return isSelected
          ? 'var(--accent-primary)'
          : 'var(--surface-elevated)';
      }
      // Outer ring: severity
      if (d.data.severity === 'critical') return 'var(--accent-cinnabar)';
      if (d.data.severity === 'high') return 'var(--accent-amber)';
      if (d.data.severity === 'medium') return 'var(--text-secondary)';
      return 'var(--accent-verdigris)';
    };

    const path = g
      .append('g')
      .selectAll('path')
      .data(root.descendants().filter((d) => d.depth > 0))
      .join('path')
      .attr('fill', (d) => getFill(d))
      .attr('fill-opacity', (d) => {
        if (filter.department) {
          return d.data.department === filter.department ? 0.95 : 0.25;
        }
        return d.depth === 1 ? 0.85 : 0.75;
      })
      .attr('stroke', 'var(--border-hairline)')
      .attr('stroke-width', 1)
      .attr('d', arc as any)
      .style('cursor', 'pointer')
      .style('transition', 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)');

    path
      .on('mouseenter', (event: MouseEvent, d) => {
        d3.select(event.currentTarget as SVGPathElement)
          .attr('fill-opacity', 1)
          .attr('stroke', 'var(--accent-primary)')
          .attr('stroke-width', 2);

        if (d.depth === 1) {
          const deptData = deptMap[d.data.name];
          setHoveredNode({
            title: d.data.name,
            category: 'Department Breakdown',
            subtitle: `${deptData?.issues.length || 0} Open Findings across ${deptData?.total || 0} Entities`,
            status: filter.department === d.data.name ? 'Active Filter' : 'Click to Filter',
            statusType: filter.department === d.data.name ? 'verdigris' : 'neutral',
            exceptionsCount: deptData?.issues.length || 0,
          });
        } else {
          setHoveredNode({
            title: `${d.data.department} • ${d.data.severity?.toUpperCase()} Issues`,
            category: 'Severity Slice',
            subtitle: `${d.value} Issue(s) identified`,
            status: d.data.severity?.toUpperCase(),
            statusType:
              d.data.severity === 'critical'
                ? 'cinnabar'
                : d.data.severity === 'high'
                ? 'amber'
                : 'verdigris',
            exceptionsCount: d.value,
          });
        }
      })
      .on('mouseleave', (event: MouseEvent, d) => {
        d3.select(event.currentTarget as SVGPathElement)
          .attr('fill-opacity', filter.department ? (d.data.department === filter.department ? 0.95 : 0.25) : d.depth === 1 ? 0.85 : 0.75)
          .attr('stroke', 'var(--border-hairline)')
          .attr('stroke-width', 1);
        setHoveredNode(null);
      })
      .on('click', (event, d) => {
        event.stopPropagation();
        if (d.data.department) {
          if (filter.department === d.data.department) {
            filter.setDepartment(null);
          } else {
            filter.setDepartment(d.data.department);
          }
        }
      });

    // Center circular badge
    const centerGroup = g.append('g').style('pointer-events', 'none');
    centerGroup
      .append('circle')
      .attr('r', radius * 0.32)
      .attr('fill', 'var(--surface)')
      .attr('stroke', 'var(--border-hairline)');

    centerGroup
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '-0.2em')
      .attr('class', 'text-apple-11 font-medium fill-current text-secondary')
      .text(filter.department ? 'Filtered by' : 'Total Issues');

    centerGroup
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '1em')
      .attr('class', 'text-apple-15 font-bold fill-current text-primary')
      .text(
        filter.department
          ? filter.department.substring(0, 8)
          : Object.values(deptMap).reduce((acc, v) => acc + v.issues.length, 0)
      );
  }, [deptMap, filter.department]);

  return (
    <div className="flex flex-col items-center">
      <HoverPreview content={hoveredNode}>
        <div className="relative cursor-pointer">
          <svg
            ref={svgRef}
            width={320}
            height={320}
            className="overflow-visible select-none"
          />
        </div>
      </HoverPreview>
      {/* Legend */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-apple-11 text-secondary">
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-cinnabar" /> Critical
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber" /> High
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-surface-elevated border border-hairline" /> Inner: Department
        </span>
      </div>
    </div>
  );
};
"""
write_both('src/components/dashboard/D3Sunburst.tsx', sunburst_tsx)

gantt_tsx = """import React, { useRef, useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AuditEngagement } from '../../types';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { HoverPreview } from '../common/HoverPreview';
import {
  Calendar,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  AlertCircle,
  X,
} from '../common/Icons';

interface EngagementGanttProps {
  engagements: AuditEngagement[];
  onSelectEngagement?: (id: string) => void;
}

export const EngagementGantt: React.FC<EngagementGanttProps> = ({
  engagements,
  onSelectEngagement,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const { openInspector, currentUser } = useApp();
  const { can } = useScopedData();

  // Timeline boundaries: 18 months spanning prior year, current year (2026), and forward plan (2027)
  const timelineStart = new Date('2026-01-01').getTime();
  const timelineEnd = new Date('2027-06-30').getTime();
  const totalDuration = timelineEnd - timelineStart;
  const timelineWidth = 2600; // Total horizontal canvas width in pixels

  // Simulated today: Sept 30, 2026
  const todayDate = new Date('2026-09-30').getTime();
  const todayX = ((todayDate - timelineStart) / totalDuration) * timelineWidth;

  // Inertial drag-to-pan state (§ 3.4 requirement)
  const [isPanning, setIsPanning] = useState(false);
  const [scrollLeft, setScrollLeft] = useState(0);
  const velocityRef = useRef(0);
  const lastPointerXRef = useRef(0);
  const lastTimeRef = useRef(0);
  const animationFrameRef = useRef<number | null>(null);

  // Focus card on click (§ 3.4 requirement)
  const [focusedEngagement, setFocusedEngagement] = useState<AuditEngagement | null>(null);

  // Manager date range drag along X pending change chip (§ 3.4 requirement)
  const [pendingDateChange, setPendingDateChange] = useState<{
    engagementId: string;
    title: string;
    newStart: string;
    newDue: string;
  } | null>(null);

  // Month generation
  const months: { label: string; year: number; isJan: boolean; startX: number; width: number }[] = [];
  let cur = new Date(timelineStart);
  while (cur.getTime() < timelineEnd) {
    const mYear = cur.getFullYear();
    const mMonth = cur.getMonth();
    const mStart = cur.getTime();
    const nextMonth = new Date(mYear, mMonth + 1, 1);
    const mEnd = Math.min(timelineEnd, nextMonth.getTime());
    const mStartX = ((mStart - timelineStart) / totalDuration) * timelineWidth;
    const mWidth = ((mEnd - mStart) / totalDuration) * timelineWidth;
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    months.push({
      label: monthNames[mMonth],
      year: mYear,
      isJan: mMonth === 0,
      startX: mStartX,
      width: mWidth,
    });
    cur = nextMonth;
  }

  // Smooth inertial decay loop (decay factor 0.94 per § 3.4)
  const startInertia = useCallback(() => {
    const decay = 0.94;
    const step = () => {
      if (Math.abs(velocityRef.current) > 0.1 && containerRef.current) {
        containerRef.current.scrollLeft -= velocityRef.current;
        velocityRef.current *= decay;
        setScrollLeft(containerRef.current.scrollLeft);
        animationFrameRef.current = requestAnimationFrame(step);
      } else {
        velocityRef.current = 0;
      }
    };
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    animationFrameRef.current = requestAnimationFrame(step);
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.gantt-bar-element')) return;
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    setIsPanning(true);
    lastPointerXRef.current = e.clientX;
    lastTimeRef.current = performance.now();
    velocityRef.current = 0;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPanning || !containerRef.current) return;
    const now = performance.now();
    const deltaX = e.clientX - lastPointerXRef.current;
    const dt = Math.max(1, now - lastTimeRef.current);
    containerRef.current.scrollLeft -= deltaX;
    setScrollLeft(containerRef.current.scrollLeft);
    velocityRef.current = (deltaX / dt) * 16.6; // normalized velocity
    lastPointerXRef.current = e.clientX;
    lastTimeRef.current = now;
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isPanning) return;
    setIsPanning(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    startInertia();
  };

  // Center on "Today" smooth-scroll button (§ 3.4 requirement)
  const scrollToToday = () => {
    if (!containerRef.current) return;
    const targetScroll = todayX - containerRef.current.clientWidth / 2;
    containerRef.current.scrollTo({
      left: Math.max(0, targetScroll),
      behavior: 'smooth',
    });
  };

  // Initial scroll positioning toward today on mount
  useEffect(() => {
    if (containerRef.current) {
      const targetScroll = todayX - containerRef.current.clientWidth / 2;
      containerRef.current.scrollLeft = Math.max(0, targetScroll);
      setScrollLeft(containerRef.current.scrollLeft);
    }
  }, []);

  // Compute bar state per § 3.4:
  // - concluded: solid verdigris
  // - in progress: verdigris pulsing
  // - overdue: cinnabar
  // - prior year: muted verdigris
  // - upcoming: neutral
  // - ghosted plan: outlined verdigris
  // - ad-hoc pending: pulsing cinnabar
  const getBarState = (eng: AuditEngagement) => {
    const end = new Date(eng.dueDate).getTime();
    const isPriorYear = new Date(eng.dueDate).getFullYear() < 2026;
    const isOverdue = eng.status !== 'signed_off' && eng.status !== 'closed' && end < todayDate;

    if (eng.status === 'signed_off' || eng.status === 'closed') {
      if (isPriorYear) {
        return {
          type: 'prior_year',
          label: 'Prior Year (Concluded)',
          colorClass: 'bg-verdigris-subtle border border-verdigris text-verdigris',
        };
      }
      return {
        type: 'concluded',
        label: 'Concluded & Sealed',
        colorClass: 'bg-verdigris text-canvas',
      };
    }

    if (isOverdue) {
      return {
        type: 'overdue',
        label: 'Remediation Overdue',
        colorClass: 'bg-cinnabar text-canvas shadow-xs',
      };
    }

    if (eng.stage === 'planning' && eng.completionPercent === 0) {
      return {
        type: 'ghosted_plan',
        label: 'Ghosted Plan',
        colorClass: 'border-2 border-dashed border-verdigris bg-surface-elevated text-secondary',
      };
    }

    if (eng.status === 'in_progress') {
      return {
        type: 'in_progress',
        label: 'In Progress (Active Fieldwork)',
        colorClass: 'bg-verdigris text-canvas animate-pulse shadow-soft',
      };
    }

    return {
      type: 'upcoming',
      label: 'Scheduled Execution',
      colorClass: 'bg-surface-elevated border border-hairline text-secondary',
    };
  };

  // Convert engagement dates to X coordinates
  const getBarBounds = (eng: AuditEngagement) => {
    const start = Math.max(timelineStart, new Date(eng.periodStart).getTime());
    const end = Math.min(timelineEnd, new Date(eng.dueDate).getTime());
    const leftX = ((start - timelineStart) / totalDuration) * timelineWidth;
    const barWidth = Math.max(36, ((end - start) / totalDuration) * timelineWidth);
    return { leftX, barWidth };
  };

  // Depth scale and opacity falloff while dragging (§ 3.4 requirement)
  const getDynamicStyle = (leftX: number, barWidth: number) => {
    if (!containerRef.current || !isPanning) {
      return { opacity: 1, transform: 'scale(1)' };
    }
    const viewportCenter = scrollLeft + containerRef.current.clientWidth / 2;
    const barCenter = leftX + barWidth / 2;
    const distFromCenter = Math.abs(viewportCenter - barCenter);
    const maxDist = containerRef.current.clientWidth / 1.2;
    const factor = Math.max(0, Math.min(1, distFromCenter / maxDist));
    const opacity = 1 - factor * 0.45;
    const scale = 1 - factor * 0.04;
    return {
      opacity,
      transform: `scale(${scale})`,
      transition: 'opacity 80ms linear, transform 80ms linear',
    };
  };

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-6 shadow-apple space-y-4 select-none">
      {/* Header controls: Title, Legend, and "Today" smooth scroll */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-hairline">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-apple-11 font-semibold text-accent uppercase tracking-wider">
              Assurance Flight Plan &amp; Velocity
            </span>
            <span className="px-2 py-0.5 rounded-full text-apple-11 font-medium bg-surface-elevated text-secondary border border-hairline">
              18-Month Continuous Scope
            </span>
          </div>
          <h3 className="text-apple-17 font-bold text-primary mt-1">
            Engagement Gantt &amp; Horizon Warp
          </h3>
          <p className="text-apple-12 text-secondary mt-0.5">
            Pan with natural velocity decay (0.94) • Click for focus card • Double-click to launch audit file
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Legend Chips */}
          <div className="hidden lg:flex items-center gap-2 text-apple-11 text-secondary">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-verdigris" /> Concluded
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-verdigris animate-pulse" /> Active
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-cinnabar" /> Overdue
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm border border-dashed border-verdigris" /> Plan
            </span>
          </div>

          {/* "Today" Smooth Scroll Button (§ 3.4 requirement) */}
          <button
            onClick={scrollToToday}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-accent-subtle hover:bg-accent-hover text-accent text-apple-12 font-semibold transition-colors shadow-xs"
            title="Jump viewport to today (Sep 30, 2026)"
          >
            <Calendar className="w-3.5 h-3.5 stroke-[1.5]" />
            <span>Today</span>
          </button>
        </div>
      </div>

      {/* Pending Date Range Chip for Managers (§ 3.4 requirement) */}
      <AnimatePresence>
        {pendingDateChange && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="flex items-center justify-between p-3 rounded-xl bg-accent-subtle border border-accent text-apple-12 text-accent"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 stroke-[1.5]" />
              <span>
                Pending milestone change for <strong>{pendingDateChange.title}</strong>: {pendingDateChange.newStart} → {pendingDateChange.newDue}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPendingDateChange(null)}
                className="px-2.5 py-1 rounded-lg bg-surface border border-hairline text-secondary hover:text-primary text-apple-11"
              >
                Dismiss
              </button>
              <button
                onClick={() => {
                  setPendingDateChange(null);
                }}
                className="px-2.5 py-1 rounded-lg bg-accent text-canvas font-semibold text-apple-11 shadow-xs"
              >
                Approve Shift
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Timeline Scrollable Viewport with Inertial Drag */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={() => setIsPanning(false)}
        className="w-full overflow-x-auto relative rounded-xl border border-hairline bg-surface-sunken cursor-grab active:cursor-grabbing select-none scrollbar-none"
      >
        <div
          ref={trackRef}
          style={{ width: `${timelineWidth}px` }}
          className="relative min-h-[380px] py-4"
        >
          {/* Parallax Weekly Grid (0.4x relative background scroll per § 3.4) */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              backgroundSize: '40px 100%',
              backgroundImage: 'linear-gradient(to right, var(--border-hairline) 1px, transparent 1px)',
              opacity: 0.35,
              transform: `translateX(${-scrollLeft * 0.4}px)`,
              pointerEvents: 'none',
            }}
          />

          {/* Month Ruler Header (§ 3.4: Jan emphasized with year) */}
          <div className="relative border-b border-hairline pb-2 mb-4 h-9">
            {months.map((m, idx) => (
              <div
                key={`${m.year}-${m.label}-${idx}`}
                style={{ left: `${m.startX}px`, width: `${m.width}px` }}
                className={`absolute top-0 text-center font-medium ${
                  m.isJan
                    ? 'text-apple-13 font-serif-title font-bold text-primary border-l-2 border-accent pl-1'
                    : 'text-apple-11 text-tertiary border-l border-hairline'
                }`}
              >
                {m.label} {m.isJan && <span className="text-accent">{m.year}</span>}
              </div>
            ))}
          </div>

          {/* TODAY Marker (§ 3.4 requirement) */}
          <div
            style={{ left: `${todayX}px` }}
            className="absolute top-0 bottom-0 w-[2px] bg-accent z-20 pointer-events-none"
          >
            <div className="absolute top-0 -translate-x-1/2 px-2 py-0.5 bg-accent text-canvas rounded-full text-apple-11 font-bold shadow-xs whitespace-nowrap">
              TODAY (SEP 30)
            </div>
          </div>

          {/* Engagement Gantt Bars Rows */}
          <div className="space-y-3.5 pt-2">
            {engagements.map((eng) => {
              const { leftX, barWidth } = getBarBounds(eng);
              const state = getBarState(eng);
              const dynamicStyle = getDynamicStyle(leftX, barWidth);

              const previewData = {
                title: eng.title,
                category: `Fieldwork Stage: ${eng.stage.toUpperCase()}`,
                subtitle: `${eng.completionPercent}% execution completed • Lead: ${eng.leadAuditorId}`,
                status: state.label,
                statusType:
                  state.type === 'concluded'
                    ? ('verdigris' as const)
                    : state.type === 'overdue'
                    ? ('cinnabar' as const)
                    : ('amber' as const),
                dueDate: eng.dueDate,
                hint: 'Double-click to open permanent audit file • Click for focus card',
              };

              return (
                <div key={eng.id} className="relative h-10 flex items-center">
                  {/* Subtle track lane */}
                  <div className="absolute inset-x-0 h-8 rounded-lg bg-surface border border-hairline opacity-40 pointer-events-none" />

                  {/* Gantt Bar Element with Universal Frosted Hover Preview */}
                  <HoverPreview content={previewData} className="contents">
                    <div
                      style={{
                        position: 'absolute',
                        left: `${leftX}px`,
                        width: `${barWidth}px`,
                        ...dynamicStyle,
                      }}
                      onClick={() => {
                        setFocusedEngagement(eng);
                        if (onSelectEngagement) onSelectEngagement(eng.id);
                      }}
                      onDoubleClick={() => {
                        openInspector('audit_file', { engagement: eng });
                      }}
                      className={`gantt-bar-element h-8 px-3 rounded-lg flex items-center justify-between text-apple-12 font-medium cursor-pointer transition-all hover:brightness-105 active:scale-95 shadow-xs overflow-hidden z-10 ${state.colorClass}`}
                    >
                      <span className="truncate pr-2">{eng.title}</span>
                      <span className="text-apple-11 font-semibold tabular-nums shrink-0 opacity-90">
                        {eng.completionPercent}%
                      </span>
                    </div>
                  </HoverPreview>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Morphing Focus Card on Click (§ 3.4 requirement) */}
      <AnimatePresence>
        {focusedEngagement && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="p-4 rounded-xl bg-surface-elevated border border-hairline shadow-apple flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-apple-11 font-mono uppercase font-semibold text-accent">
                  {focusedEngagement.id}
                </span>
                <span className="px-2 py-0.2 rounded text-apple-11 font-semibold uppercase bg-accent-subtle text-accent">
                  {focusedEngagement.stage}
                </span>
                {focusedEngagement.signedOffAt && (
                  <span className="flex items-center gap-1 text-apple-11 text-verdigris font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 stroke-[2]" />
                    Sealed
                  </span>
                )}
              </div>
              <h4 className="text-apple-15 font-bold text-primary">
                {focusedEngagement.title}
              </h4>
              <p className="text-apple-12 text-secondary">
                Period: {focusedEngagement.periodStart} → {focusedEngagement.dueDate} • Progress: {focusedEngagement.completionPercent}%
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setFocusedEngagement(null)}
                className="p-2 rounded-xl text-secondary hover:text-primary hover:bg-surface-hover transition-colors"
                title="Dismiss focus card"
              >
                <X className="w-4 h-4 stroke-[1.5]" />
              </button>
              <button
                onClick={() => {
                  openInspector('audit_file', { engagement: focusedEngagement });
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary text-canvas font-semibold text-apple-12 hover:opacity-90 transition-opacity shadow-xs"
              >
                <span>Open Audit File</span>
                <ExternalLink className="w-3.5 h-3.5 stroke-[1.5]" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
"""
write_both('src/components/dashboard/EngagementGantt.tsx', gantt_tsx)

dashboard_tab_tsx = """import React from 'react';
import { useScopedData } from '../../hooks/useScopedData';
import { useFilterStore } from '../../context/FilterStore';
import { useApp } from '../../context/AppContext';
import { CapRadialTracker } from './CapRadialTracker';
import { CapTable } from './CapTable';
import { EngagementGantt } from './EngagementGantt';
import { LedgerScrubBar } from './LedgerScrubBar';
import { HoverPreview } from '../common/HoverPreview';
import {
  Folder,
  ShieldCheck,
  AlertTriangle,
  FileCheck,
  Filter,
  RotateCcw,
} from '../common/Icons';

export const ExecutiveDashboardTab: React.FC = () => {
  const {
    currentUser,
    stats,
    filteredEngagements,
    scopedEntities,
    filteredCapItems,
  } = useScopedData();
  const filter = useFilterStore();
  const { setActiveTab, setSelectedEngagementId } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-8 animate-fade-in">
      {/* Editorial Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-hairline pb-6">
        <div>
          <span className="text-apple-12 font-medium tracking-wide uppercase text-accent">
            Internal Audit &amp; Risk Governance OS
          </span>
          <h1 className="text-apple-28 font-bold text-primary tracking-tight mt-1">
            Executive Assurance Cockpit
          </h1>
          <p className="text-apple-15 text-secondary mt-1">
            Welcome back, {currentUser.name}.{' '}
            <span className="text-primary font-medium">{stats.greetingSubtitle}</span>
          </p>
        </div>

        {/* Global Filter Status & Reset */}
        {filter.hasActiveFilters() && (
          <div className="flex items-center gap-2 bg-accent-subtle border border-accent text-accent px-3 py-1.5 rounded-xl text-apple-12 shadow-xs">
            <Filter className="w-3.5 h-3.5 stroke-[1.5]" />
            <span>
              Active Filter:{' '}
              <strong>
                {filter.department || filter.status || filter.severity || filter.searchQuery}
              </strong>
            </span>
            <button
              onClick={() => filter.clearFilters()}
              className="ml-2 hover:opacity-80 transition-opacity p-0.5"
              title="Clear active filter"
            >
              <RotateCcw className="w-3 h-3 stroke-[1.5]" />
            </button>
          </div>
        )}
      </div>

      {/* 4D Ledger Scrub Bar (Task 6 Differentiator & Task 1) */}
      <LedgerScrubBar />

      {/* Metric Cards Row with Apple-tier Serif Numerals */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Scoped Entities */}
        <HoverPreview
          content={{
            title: `${stats.totalEntities} Scoped Audit Entities`,
            category: 'Audit Universe Coverage',
            subtitle: `${stats.highRiskEntities} Rated High Inherent Risk`,
            status: 'Scoped Viewpoint',
            statusType: 'neutral',
            hint: 'Click to open Universe & SIRA',
          }}
          onClick={() => setActiveTab('universe')}
        >
          <div className="p-5 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer space-y-1">
            <div className="flex items-center justify-between text-secondary text-apple-12 font-medium">
              <span>Scoped Entities</span>
              <Folder className="w-4 h-4 stroke-[1.5] text-accent" />
            </div>
            <div className="font-serif-numeral text-apple-40 font-bold text-primary tabular-nums">
              {stats.totalEntities}
            </div>
            <div className="text-apple-11 text-secondary">
              {stats.highRiskEntities} High Risk Profile
            </div>
          </div>
        </HoverPreview>

        {/* Engagements in Progress */}
        <HoverPreview
          content={{
            title: `${stats.inProgressEngagements} Engagements in Progress`,
            category: 'Fieldwork Status',
            subtitle: `${stats.completedEngagements} Completed and Signed-off`,
            status: 'Fieldwork Stage',
            statusType: 'amber',
            hint: 'Click to open Audit Plan',
          }}
          onClick={() => setActiveTab('plan')}
        >
          <div className="p-5 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer space-y-1">
            <div className="flex items-center justify-between text-secondary text-apple-12 font-medium">
              <span>In Fieldwork</span>
              <span className="w-2 h-2 rounded-full bg-accent" />
            </div>
            <div className="font-serif-numeral text-apple-40 font-bold text-primary tabular-nums">
              {stats.inProgressEngagements}
            </div>
            <div className="text-apple-11 text-secondary">
              {stats.completedEngagements} Completed / Sealed
            </div>
          </div>
        </HoverPreview>

        {/* Open Audit Issues */}
        <HoverPreview
          content={{
            title: `${stats.openIssues} Open Audit Issues`,
            category: 'Findings Register',
            subtitle: `${stats.criticalIssues} High/Critical Severity Escalations`,
            status: stats.criticalIssues > 0 ? 'Action Required' : 'On Track',
            statusType: stats.criticalIssues > 0 ? 'cinnabar' : 'verdigris',
            hint: 'Click to open Issues Register',
          }}
          onClick={() => setActiveTab('issues')}
        >
          <div className="p-5 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer space-y-1">
            <div className="flex items-center justify-between text-secondary text-apple-12 font-medium">
              <span>Open Findings</span>
              <AlertTriangle className="w-4 h-4 stroke-[1.5] text-cinnabar" />
            </div>
            <div className="font-serif-numeral text-apple-40 font-bold text-primary tabular-nums">
              {stats.openIssues}
            </div>
            <div className="text-apple-11 text-secondary">
              <span className="text-cinnabar font-semibold">{stats.criticalIssues} Critical</span>{' '}
              Escalated
            </div>
          </div>
        </HoverPreview>

        {/* Sealed Working Papers */}
        <HoverPreview
          content={{
            title: `${stats.sealedWorkpapers} Working Papers Cryptographically Sealed`,
            category: 'Ledger Hash Attestation',
            subtitle: 'Verified by reviewer four-eyes protocol',
            status: 'Ledger Attested',
            statusType: 'verdigris',
            hint: 'Click to open Workbench',
          }}
          onClick={() => setActiveTab('plan')}
        >
          <div className="p-5 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer space-y-1">
            <div className="flex items-center justify-between text-secondary text-apple-12 font-medium">
              <span>Sealed Papers</span>
              <FileCheck className="w-4 h-4 stroke-[1.5] text-verdigris" />
            </div>
            <div className="font-serif-numeral text-apple-40 font-bold text-primary tabular-nums">
              {stats.sealedWorkpapers}
            </div>
            <div className="text-apple-11 text-verdigris font-medium flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Attested on Hash-Chain</span>
            </div>
          </div>
        </HoverPreview>
      </div>

      {/* Engagement Gantt & Horizon Warp (§ 3.4: inertial pan, today marker, depth falloff, bar states) */}
      <EngagementGantt
        engagements={filteredEngagements}
        onSelectEngagement={(id) => {
          setSelectedEngagementId(id);
        }}
      />

      {/* CAP Radial Tracker (§ 3.4: replaces Sunburst with D3 radial chart, outer ring severity, overdue arc) */}
      <CapRadialTracker
        capDeptMap={stats.capDeptMap}
        totalCapCount={stats.totalCapCount}
        openCapCount={stats.openCapCount}
        overdueCapCount={stats.overdueCapCount}
      />

      {/* CAP Table below chart (§ 3.4 requirement: id, action, owner, dept, severity, due date, aging, status, retest) */}
      <CapTable capItems={filteredCapItems} />
    </div>
  );
};
"""
write_both('src/components/dashboard/ExecutiveDashboardTab.tsx', dashboard_tab_tsx)

gantt_timewarp_tsx = """import React from 'react';
import { motion } from 'motion/react';
import { AuditEngagement } from '../../types';
import { HoverPreview } from '../common/HoverPreview';
import { Calendar, CheckCircle2, Clock } from '../common/Icons';

interface GanttProps {
  engagements: AuditEngagement[];
  onSelectEngagement: (id: string) => void;
}

export const GanttTimeWarp: React.FC<GanttProps> = ({
  engagements,
  onSelectEngagement,
}) => {
  const months = ['Jul 2026', 'Aug 2026', 'Sep 2026', 'Oct 2026', 'Nov 2026', 'Dec 2026'];

  // Calculate horizontal offset and width for engagement timeline bar
  const getBarStyle = (eng: AuditEngagement) => {
    // Relative positioning between July 1 and Dec 31
    const baseDate = new Date('2026-07-01').getTime();
    const endDate = new Date('2026-12-31').getTime();
    const totalSpan = endDate - baseDate;

    const start = Math.max(baseDate, new Date(eng.periodStart).getTime());
    const due = Math.min(endDate, new Date(eng.dueDate).getTime());

    const leftPercent = Math.max(0, Math.min(100, ((start - baseDate) / totalSpan) * 100));
    const widthPercent = Math.max(12, Math.min(100 - leftPercent, ((due - start) / totalSpan) * 100));

    return {
      left: `${leftPercent}%`,
      width: `${widthPercent}%`,
    };
  };

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-5 shadow-apple space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-apple-15 font-semibold text-primary">Engagement Timeline &amp; Delivery Warp</h3>
          <p className="text-apple-12 text-secondary">
            Multi-quarter milestones, phase gates, and reviewer sign-off horizons
          </p>
        </div>
        <div className="flex items-center gap-3 text-apple-11 text-secondary">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-accent" /> In Progress
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-verdigris" /> Sealed / Signed-off
          </span>
        </div>
      </div>

      {/* Month timeline header columns */}
      <div className="grid grid-cols-6 border-b border-hairline pb-2 text-center text-apple-11 font-medium text-tertiary">
        {months.map((m) => (
          <div key={m}>{m}</div>
        ))}
      </div>

      {/* Gantt Bars List */}
      <div className="space-y-3 relative min-h-[140px]">
        {/* Background grid vertical guidelines */}
        <div className="absolute inset-0 grid grid-cols-6 pointer-events-none">
          {months.map((m, idx) => (
            <div
              key={idx}
              className={`h-full ${idx > 0 ? 'border-l border-hairline opacity-40' : ''}`}
            />
          ))}
        </div>

        {engagements.length === 0 ? (
          <div className="py-8 text-center text-apple-12 text-secondary">
            No engagements active for this scoped filter.
          </div>
        ) : (
          engagements.map((eng) => {
            const barPos = getBarStyle(eng);
            const isSigned = eng.status === 'signed_off';
            const previewData = {
              title: eng.title,
              category: `Stage: ${eng.stage.toUpperCase()}`,
              subtitle: `Progress: ${eng.completionPercent}% complete`,
              status: isSigned ? 'Signed-off & Sealed' : 'In Fieldwork',
              statusType: isSigned ? ('verdigris' as const) : ('amber' as const),
              dueDate: eng.dueDate,
              metrics: [
                { label: 'Start', value: eng.periodStart },
                { label: 'Due', value: eng.dueDate },
              ],
              hint: 'Click to open audit plan and workpapers',
            };

            return (
              <div key={eng.id} className="relative z-10">
                <HoverPreview content={previewData}>
                  <div
                    onClick={() => onSelectEngagement(eng.id)}
                    className="relative w-full h-11 bg-surface-elevated/40 hover:bg-surface-elevated/80 rounded-xl transition-colors cursor-pointer flex items-center px-2"
                  >
                    {/* The colored timeline pill */}
                    <motion.div
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                      style={{
                        position: 'absolute',
                        left: barPos.left,
                        width: barPos.width,
                        transformOrigin: 'left center',
                      }}
                      className={`h-8 rounded-lg px-3 flex items-center justify-between text-apple-11 font-medium transition-shadow shadow-xs ${
                        isSigned
                          ? 'bg-verdigris-subtle text-verdigris border border-verdigris'
                          : 'bg-accent-subtle text-accent border border-accent'
                      }`}
                    >
                      <span className="truncate pr-2 font-medium">{eng.title}</span>
                      <span className="tabular-nums shrink-0 font-semibold">
                        {eng.completionPercent}%
                      </span>
                    </motion.div>
                  </div>
                </HoverPreview>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
"""
write_both('src/components/dashboard/GanttTimeWarp.tsx', gantt_timewarp_tsx)

ledger_scrub_tsx = """import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { verifyChain } from '../../lib/ledger';
import { History, ShieldCheck, ShieldAlert, RotateCcw } from '../common/Icons';

export const LedgerScrubBar: React.FC = () => {
  const { ledger, ledgerAsOf, setLedgerAsOf } = useApp();
  const [chainStatus, setChainStatus] = useState<{ valid: boolean; brokenSeq?: number }>({
    valid: true,
  });

  const maxSeq = ledger.length;
  const currentSeq = ledgerAsOf !== null ? ledgerAsOf : maxSeq;

  useEffect(() => {
    verifyChain(ledger).then((res) => {
      setChainStatus(res);
    });
  }, [ledger]);

  if (maxSeq === 0) return null;

  const currentEntry = ledger.find((e) => e.seq === currentSeq) || ledger[ledger.length - 1];

  return (
    <div className="w-full bg-surface border border-hairline rounded-2xl p-4 shadow-apple">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-accent stroke-[1.5]" />
          <span className="text-apple-13 font-semibold text-primary">
            4D Cryptographic Ledger Scrub
          </span>
          <span className="px-2 py-0.5 rounded text-apple-11 font-medium bg-surface-elevated border border-hairline text-secondary tabular-nums">
            Block {currentSeq} of {maxSeq}
          </span>
          {ledgerAsOf !== null && (
            <span className="px-2 py-0.5 rounded text-apple-11 font-medium bg-amber-subtle text-amber">
              Historical As-Of Mode
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Chain Integrity verification badge */}
          {chainStatus.valid ? (
            <span className="flex items-center gap-1.5 text-apple-11 font-medium text-verdigris bg-verdigris-subtle px-2 py-0.5 rounded border border-verdigris">
              <ShieldCheck className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Chain Sealed &amp; Intact ✓</span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-apple-11 font-medium text-cinnabar bg-cinnabar-subtle px-2 py-0.5 rounded border border-cinnabar">
              <ShieldAlert className="w-3.5 h-3.5 stroke-[1.5]" />
              <span>Chain Tampered at Seq #{chainStatus.brokenSeq}</span>
            </span>
          )}

          {ledgerAsOf !== null && (
            <button
              onClick={() => setLedgerAsOf(null)}
              className="flex items-center gap-1 text-apple-11 font-medium text-accent hover:underline"
            >
              <RotateCcw className="w-3 h-3 stroke-[1.5]" />
              <span>Return to Live</span>
            </button>
          )}
        </div>
      </div>

      {/* Scrub range slider */}
      <div className="space-y-2">
        <input
          type="range"
          min={1}
          max={maxSeq}
          value={currentSeq}
          onChange={(e) => {
            const val = parseInt(e.target.value, 10);
            setLedgerAsOf(val === maxSeq ? null : val);
          }}
          className="w-full cursor-pointer h-1.5 bg-surface-hover rounded-lg appearance-none"
          style={{ accentColor: 'var(--accent-primary)' }}
        />

        {/* Current block metadata readout */}
        {currentEntry && (
          <div className="flex flex-wrap items-center justify-between text-apple-11 text-secondary pt-1 border-t border-hairline gap-2">
            <div className="flex items-center gap-2">
              <span className="font-medium text-primary">{currentEntry.eventType.toUpperCase()}</span>
              <span>•</span>
              <span>{currentEntry.actorName} ({currentEntry.actorRole})</span>
              <span>•</span>
              <span className="truncate max-w-xs">{currentEntry.payloadSummary}</span>
            </div>
            <div className="font-mono text-tertiary tabular-nums">
              Hash: {currentEntry.hash.substring(0, 16)}...
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
"""
write_both('src/components/dashboard/LedgerScrubBar.tsx', ledger_scrub_tsx)
