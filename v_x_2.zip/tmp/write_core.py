import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

types_index = """export type Role = 'admin' | 'cia' | 'reviewer' | 'preparer' | 'auditee';

export type UserScopeAssignment = {
  userId: string;
  universeIds: string[]; // empty or '*' means all universes
  entityIds: string[];   // empty or '*' means all entities within assigned universes
  role: Role;
};

export type User = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: Role;
  universeIds: string[];
  entityIds: string[];
  department?: string;
};

export type AuditUniverse = {
  id: string;
  name: string;
  code: string;
  description: string;
  totalEntities: number;
  highRiskCount: number;
  lastReviewDate: string;
};

export type RiskRating = 'low' | 'medium' | 'high' | 'critical';
export type ControlEffectiveness = 'effective' | 'needs_improvement' | 'ineffective' | 'not_tested';

export type AuditEntity = {
  id: string;
  universeId: string;
  name: string;
  code: string;
  department: string;
  headOfDepartment: string;
  inherentRisk: RiskRating;
  residualRisk: RiskRating;
  siraScore: number; // 0 - 100
  controlsCount: number;
  lastAuditDate: string;
  status: 'active' | 'in_review' | 'dormant';
};

export type EngagementStage = 'planning' | 'fieldwork' | 'review' | 'reporting' | 'closed';

export type AuditEngagement = {
  id: string;
  universeId: string;
  entityId: string;
  title: string;
  stage: EngagementStage;
  status: 'draft' | 'in_progress' | 'signed_off' | 'reopened' | 'closed';
  leadAuditorId: string;
  reviewerId: string;
  periodStart: string;
  periodEnd: string;
  dueDate: string;
  completionPercent: number;
  signedOffAt?: string;
  signedOffBy?: string;
  signedHash?: string;
  isLocked?: boolean;
  reopenJustification?: string;
};

export type AuditControl = {
  id: string;
  entityId: string;
  engagementId: string;
  code: string;
  title: string;
  description: string;
  controlType: 'preventive' | 'detective' | 'corrective';
  frequency: 'continuous' | 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annual';
  ownerId: string;
  effectiveness: ControlEffectiveness;
  sampleSize: number;
  exceptionsCount: number;
};

export type WorkpaperStatus = 'not_started' | 'in_progress' | 'completed' | 'signed_off' | 'reopened';

export type WorkingPaper = {
  id: string;
  engagementId: string;
  controlId: string;
  entityId: string;
  universeId: string;
  refCode: string;
  title: string;
  status: WorkpaperStatus;
  preparerId: string;
  reviewerId: string;
  preparedDate?: string;
  reviewedDate?: string;
  objective: string;
  scope: string;
  methodology: string;
  testSteps: {
    id: string;
    description: string;
    completed: boolean;
    resultNote?: string;
  }[];
  populationCount: number;
  populationSha256?: string;
  sampleCount: number;
  samplingSeed?: string;
  exceptionsIdentified: number;
  conclusion: string;
  conclusionStage1?: string;
  conclusionStage2?: string;
  isTwoStage?: boolean;
  sealed: boolean;
  sealedHash?: string;
  evidenceItems: {
    id: string;
    name: string;
    uploadedAt: string;
    uploadedBy: string;
    sha256: string;
    sizeBytes: number;
  }[];
};

export type Severity = 'low' | 'medium' | 'high' | 'critical';

export type AuditObservation = {
  id: string;
  workpaperId: string;
  controlId: string;
  entityId: string;
  universeId: string;
  title: string;
  condition: string;
  criteria: string;
  cause: string;
  consequence: string;
  recommendation: string;
  severity: Severity;
  status: 'draft' | 'open' | 'action_plan_agreed' | 'closed';
  ruleId?: string;
  inputRowRefs?: number[];
  createdAt: string;
  raisedBy: string;
};

export type AuditIssue = {
  id: string;
  observationId?: string;
  entityId: string;
  universeId: string;
  department: string;
  title: string;
  description: string;
  severity: Severity;
  status: 'identified' | 'management_response' | 'remediated' | 'closed' | 'overdue';
  ownerId: string;
  identifiedDate: string;
  dueDate: string;
  remediatedDate?: string;
  resolutionNotes?: string;
};

export type CapStatus = 'Open' | 'In progress' | 'Pending validation' | 'Overdue' | 'Closed';
export type RetestStatus = 'Not tested' | 'Passed' | 'Failed' | 'In retest';
export type CapApprovalStatus = 'Pending review' | 'Approved by CIA';

export type AuditCapItem = {
  id: string;
  action: string;
  title: string;
  owner: string;
  department: string;
  severity: Severity;
  dueDate: string;
  agingDays: number;
  status: CapStatus;
  retestStatus: RetestStatus;
  approvalStatus: CapApprovalStatus;
  originatingReport: string;
  engagementId: string;
  entityId: string;
  universeId: string;
};

export type ReviewComment = {
  id: string;
  workpaperId: string;
  authorId: string;
  authorName: string;
  authorRole: Role;
  text: string;
  createdAt: string;
  status: 'open' | 'addressed' | 'cleared';
  replies?: {
    id: string;
    authorName: string;
    text: string;
    createdAt: string;
  }[];
};

export type LedgerEventType = 
  | 'test_finalize'
  | 'reviewer_sign_off'
  | 'audit_sign_off'
  | 'plan_approval'
  | 'adhoc_approve'
  | 'adhoc_reject'
  | 'reopen'
  | 'evidence_drop';

export type LedgerEntry = {
  seq: number;
  prevHash: string;
  hash: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: Role;
  eventType: LedgerEventType;
  entityId: string;
  recordId: string;
  recordType: 'engagement' | 'workpaper' | 'plan' | 'control' | 'observation' | 'evidence';
  payloadSummary: string;
  payloadHash: string;
  justification?: string;
};

export type GlassBoxToken = {
  tokenHash: string; // SHA-256 of 32 random bytes token
  workpaperId: string;
  entityId: string;
  orgId: string;
  createdAt: string;
  expiresAt: string; // 7 days
  used: boolean;
  usedAt?: string;
  allowedExtensions: string[];
  maxSizeBytes: number;
};

export type AnalyticsRule = 
  | 'variance'
  | 'trend'
  | 'anomalies'
  | 'tb_check'
  | 'gl_to_tb'
  | 'fs_ratios';

export type AnalysisResultRow = {
  rowIndex: number;
  account: string;
  category: string;
  currentPeriod: number;
  priorPeriod: number;
  varianceVal: number;
  variancePct: number;
  flagged: boolean;
  flagReason?: string;
  ruleId: AnalyticsRule;
  originalRowRef: number;
};
"""

write_both('src/types/index.ts', types_index)

filter_store = """import { create } from 'zustand';

export interface FilterState {
  department: string | null;
  status: string | null;
  severity: string | null;
  dateRange: { start: string; end: string } | null;
  ownerId: string | null;
  searchQuery: string;

  setDepartment: (dept: string | null) => void;
  setStatus: (status: string | null) => void;
  setSeverity: (severity: string | null) => void;
  setDateRange: (range: { start: string; end: string } | null) => void;
  setOwnerId: (ownerId: string | null) => void;
  setSearchQuery: (query: string) => void;
  clearFilters: () => void;
  hasActiveFilters: () => boolean;
}

export const useFilterStore = create<FilterState>((set, get) => ({
  department: null,
  status: null,
  severity: null,
  dateRange: null,
  ownerId: null,
  searchQuery: '',

  setDepartment: (department) => set({ department }),
  setStatus: (status) => set({ status }),
  setSeverity: (severity) => set({ severity }),
  setDateRange: (dateRange) => set({ dateRange }),
  setOwnerId: (ownerId) => set({ ownerId }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),

  clearFilters: () =>
    set({
      department: null,
      status: null,
      severity: null,
      dateRange: null,
      ownerId: null,
      searchQuery: '',
    }),

  hasActiveFilters: () => {
    const s = get();
    return Boolean(
      s.department || s.status || s.severity || s.dateRange || s.ownerId || s.searchQuery.trim()
    );
  },
}));
"""
write_both('src/context/FilterStore.ts', filter_store)

theme_context = """import React, { createContext, useContext, useEffect, useState } from 'react';

export type ThemeMode = 'system' | 'light' | 'dark';
export type ThemePreset = 'ledger' | 'graphite' | 'ink';

interface ThemeContextType {
  theme: ThemeMode;
  resolvedTheme: 'light' | 'dark';
  preset: ThemePreset;
  setTheme: (mode: ThemeMode) => void;
  setPreset: (preset: ThemePreset) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('provio-theme');
    return (saved as ThemeMode) || 'system';
  });

  const [preset, setPresetState] = useState<ThemePreset>(() => {
    const saved = localStorage.getItem('provio-preset');
    return (saved as ThemePreset) || 'ledger'; // Default to "Ledger" per § 4
  });

  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-preset', preset);

    const applyTheme = (isDark: boolean) => {
      if (isDark || preset === 'ink') {
        root.classList.add('dark');
        setResolvedTheme('dark');
      } else {
        root.classList.remove('dark');
        setResolvedTheme('light');
      }
    };

    if (theme === 'system') {
      if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
        const media = window.matchMedia('(prefers-color-scheme: dark)');
        applyTheme(media.matches);
        const listener = (e: MediaQueryListEvent) => applyTheme(e.matches);
        media.addEventListener('change', listener);
        return () => media.removeEventListener('change', listener);
      } else {
        applyTheme(false);
      }
    } else {
      applyTheme(theme === 'dark');
    }
  }, [theme, preset]);

  const setTheme = (mode: ThemeMode) => {
    setThemeState(mode);
    localStorage.setItem('provio-theme', mode);
  };

  const setPreset = (p: ThemePreset) => {
    setPresetState(p);
    localStorage.setItem('provio-preset', p);
  };

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, preset, setTheme, setPreset }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
"""
write_both('src/context/ThemeContext.tsx', theme_context)
