import os

def write_both(rel_path, content):
    for base in ['/app/applet', '/app/applet/docs/reference/v1']:
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
    print(f"Wrote {rel_path} to both src and reference/v1")

workbench_header_tsx = """import React from 'react';
import { WorkingPaper, AuditEngagement } from '../../types';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { ShieldCheck, Lock, Unlock, Share2, CheckCircle2, RotateCcw, AlertCircle } from '../common/Icons';

interface WorkbenchHeaderProps {
  workpaper: WorkingPaper;
  engagement?: AuditEngagement;
}

export const WorkbenchHeader: React.FC<WorkbenchHeaderProps> = ({ workpaper, engagement }) => {
  const { signOffWorkpaper, reopenWorkpaper, openInspector, currentUser } = useApp();
  const { can } = useScopedData();

  const handleSignOff = async () => {
    await signOffWorkpaper(workpaper.id);
  };

  const handleReopen = async () => {
    const reason = prompt('Enter mandatory reopening justification (minimum 10 characters):');
    if (!reason || reason.trim().length < 10) {
      alert('Reopen requires at least 10 characters justification.');
      return;
    }
    await reopenWorkpaper(workpaper.id, reason);
  };

  return (
    <div className="p-6 bg-surface border-b border-hairline flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="font-mono text-apple-12 font-bold px-2 py-0.5 rounded bg-surface-sunken border border-hairline text-secondary">
            {workpaper.refCode}
          </span>
          <h1 className="text-apple-20 font-bold text-primary">{workpaper.title}</h1>
          {workpaper.sealed && (
            <span className="px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-verdigris-subtle text-verdigris border border-verdigris flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Sealed &amp; Attested
            </span>
          )}
        </div>
        <div className="text-apple-12 text-secondary flex items-center gap-3">
          <span>Objective: {workpaper.objective}</span>
          <span>•</span>
          <span>Population: {workpaper.populationCount.toLocaleString()} items</span>
          {workpaper.populationSha256 && (
            <>
              <span>•</span>
              <span className="font-mono text-apple-11 text-tertiary">
                SHA: {workpaper.populationSha256.slice(0, 12)}...
              </span>
            </>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={() => openInspector('glassbox_share', { workpaper })}
          className="px-3 py-1.5 rounded-lg bg-surface border border-hairline hover:bg-surface-hover text-apple-12 font-medium text-primary transition-colors flex items-center gap-1.5"
          title="Share auditee portal"
        >
          <Share2 className="w-3.5 h-3.5 text-accent" />
          <span>GlassBox Link</span>
        </button>

        {workpaper.sealed ? (
          <button
            type="button"
            onClick={handleReopen}
            className="px-3 py-1.5 rounded-lg bg-cinnabar-subtle border border-cinnabar text-apple-12 font-semibold text-cinnabar hover:bg-surface-hover transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reopen Paper</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={handleSignOff}
            className="px-4 py-1.5 rounded-lg bg-verdigris text-white text-apple-12 font-semibold hover:opacity-90 transition-opacity flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Seal &amp; Attest (4-Eyes)</span>
          </button>
        )}
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/WorkbenchHeader.tsx', workbench_header_tsx)

testing_steps_tsx = """import React, { useState } from 'react';
import { WorkingPaper } from '../../types';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, ShieldCheck, AlertCircle, Lock, Hash } from '../common/Icons';

interface TestingStepsTabProps {
  workpaper: WorkingPaper;
}

export const TestingStepsTab: React.FC<TestingStepsTabProps> = ({ workpaper }) => {
  const { finalizeTest } = useApp();
  const [steps, setSteps] = useState(workpaper.testSteps);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verified, setVerified] = useState(Boolean(workpaper.populationSha256));

  const handleToggleStep = (stepId: string) => {
    if (workpaper.sealed) return;
    setSteps((prev) =>
      prev.map((s) => (s.id === stepId ? { ...s, completed: !s.completed } : s))
    );
  };

  const handleVerifyPopulation = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setVerified(true);
      setIsVerifying(false);
    }, 400);
  };

  const allCompleted = steps.every((s) => s.completed) && verified;

  const handleFinalize = async () => {
    await finalizeTest(workpaper.id);
  };

  return (
    <div className="space-y-6">
      {/* Law 3 Enforcement: Population Verification Gate */}
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline flex items-center justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-primary font-semibold text-apple-13">
            <Hash className="w-4 h-4 text-verdigris" />
            <span>Population Integrity Verification Gate (⚖ Law 3)</span>
          </div>
          <p className="text-apple-12 text-secondary">
            Testing is blocked until the underlying population dataset has been cryptographically hashed and verified against data store records.
          </p>
          <div className="text-apple-11 font-mono text-tertiary">
            Items: {workpaper.populationCount.toLocaleString()} • Expected SHA: {workpaper.populationSha256 || 'Attested on upload'}
          </div>
        </div>
        <button
          type="button"
          onClick={handleVerifyPopulation}
          disabled={verified || isVerifying || workpaper.sealed}
          className={`px-3 py-1.5 rounded-lg text-apple-12 font-semibold transition-colors flex items-center gap-1.5 ${
            verified
              ? 'bg-verdigris-subtle text-verdigris border border-verdigris cursor-default'
              : 'bg-surface border border-hairline hover:bg-surface-hover text-primary'
          }`}
        >
          {verified ? (
            <>
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Population Verified</span>
            </>
          ) : isVerifying ? (
            'Verifying...'
          ) : (
            'Verify Population'
          )}
        </button>
      </div>

      {/* Sequential Test Steps */}
      <div className="space-y-3">
        <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
          Substantive &amp; Control Test Program
        </h3>
        <div className="divide-y divide-hairline border border-hairline rounded-xl overflow-hidden bg-surface">
          {steps.map((step, idx) => (
            <div
              key={step.id}
              onClick={() => handleToggleStep(step.id)}
              className={`p-4 flex items-start gap-3 transition-colors ${
                workpaper.sealed ? 'opacity-80' : 'cursor-pointer hover:bg-surface-hover'
              }`}
            >
              <div className="pt-0.5 shrink-0">
                <input
                  type="checkbox"
                  checked={step.completed}
                  onChange={() => {}}
                  disabled={workpaper.sealed}
                  className="rounded border-hairline text-verdigris focus:ring-0"
                />
              </div>
              <div className="min-w-0 flex-1 space-y-1">
                <div className="flex items-center justify-between text-apple-12">
                  <span className="font-medium text-primary">Step {idx + 1}: {step.description}</span>
                  {step.completed && (
                    <span className="text-apple-11 text-verdigris font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Done
                    </span>
                  )}
                </div>
                {step.resultNote && (
                  <p className="text-apple-11 text-secondary font-mono bg-surface-sunken p-2 rounded">
                    {step.resultNote}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Finalize Test Gate */}
      <div className="pt-4 border-t border-hairline flex items-center justify-between">
        <span className="text-apple-12 text-secondary">
          {allCompleted ? 'All mandatory test gates satisfied.' : 'Complete all steps and verify population to finalize.'}
        </span>
        <button
          type="button"
          onClick={handleFinalize}
          disabled={!allCompleted || workpaper.sealed}
          className="px-4 py-2 rounded-lg bg-surface border border-hairline hover:bg-surface-hover text-apple-13 font-semibold text-primary disabled:opacity-50 transition-colors"
        >
          Finalize Fieldwork Test
        </button>
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/TestingStepsTab.tsx', testing_steps_tsx)

sampling_tab_tsx = """import React, { useState, useMemo } from 'react';
import { WorkingPaper } from '../../types';
import { drawSeededSample } from '../../lib/auditEngines';
import { Hash, Check, Sliders, ShieldCheck } from '../common/Icons';

interface SamplingTabProps {
  workpaper: WorkingPaper;
}

export const SamplingTab: React.FC<SamplingTabProps> = ({ workpaper }) => {
  const [seed, setSeed] = useState(workpaper.samplingSeed || 'PROVIO-AUDIT-2026-SEED');
  const [sampleSize, setSampleSize] = useState(workpaper.sampleCount || 25);
  const [confidenceLevel, setConfidenceLevel] = useState(95);

  // Generate deterministic synthetic population based on workpaper count
  const dummyPopulation = useMemo(() => {
    const items = [];
    const count = Math.min(workpaper.populationCount || 500, 500);
    for (let i = 1; i <= count; i++) {
      items.push({
        id: `TXN-${100000 + i}`,
        amount: Math.round(1500 + ((i * 37) % 85000)),
        account: `GL-41${(i % 12).toString().padStart(2, '0')}`,
        date: `2026-08-${((i % 28) + 1).toString().padStart(2, '0')}`,
      });
    }
    return items;
  }, [workpaper.populationCount]);

  // Deterministic Mulberry32 selection (LAW 1)
  const sampledItems = useMemo(() => {
    return drawSeededSample(dummyPopulation, sampleSize, seed);
  }, [dummyPopulation, sampleSize, seed]);

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <Sliders className="w-4 h-4 text-verdigris" />
          <span>Deterministic Audit Sampling Engine (⚖ Law 1: Zero Math.random)</span>
        </div>
        <p className="text-apple-12 text-secondary">
          Samples are deterministically selected using the Mulberry32 PRNG initialized with an audit seed string. Identical seeds yield identical sample sets anywhere, anytime.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-surface border border-hairline space-y-1">
          <label className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
            Deterministic Seed String
          </label>
          <input
            type="text"
            value={seed}
            onChange={(e) => setSeed(e.target.value)}
            disabled={workpaper.sealed}
            className="w-full font-mono text-apple-12 p-2 rounded-lg bg-surface-sunken border border-hairline text-primary"
          />
        </div>
        <div className="p-4 rounded-xl bg-surface border border-hairline space-y-1">
          <label className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
            Sample Size (n)
          </label>
          <input
            type="number"
            min={1}
            max={dummyPopulation.length}
            value={sampleSize}
            onChange={(e) => setSampleSize(Math.max(1, Number(e.target.value)))}
            disabled={workpaper.sealed}
            className="w-full text-apple-13 p-2 rounded-lg bg-surface-sunken border border-hairline text-primary"
          />
        </div>
        <div className="p-4 rounded-xl bg-surface border border-hairline space-y-1">
          <label className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
            Statistical Confidence Level
          </label>
          <select
            value={confidenceLevel}
            onChange={(e) => setConfidenceLevel(Number(e.target.value))}
            disabled={workpaper.sealed}
            className="w-full text-apple-13 p-2 rounded-lg bg-surface-sunken border border-hairline text-primary"
          >
            <option value={90}>90% (Low Risk Tolerable Deviation)</option>
            <option value={95}>95% (AICPA Standard Assurance)</option>
            <option value={99}>99% (High Inherent Risk / SOX)</option>
          </select>
        </div>
      </div>

      {/* Selected Sample Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
            Seeded Sample Draw ({sampledItems.length} records)
          </h3>
          <span className="text-apple-11 text-verdigris font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Deterministically Reproducible
          </span>
        </div>
        <div className="border border-hairline rounded-xl overflow-hidden bg-surface">
          <table className="w-full text-left border-collapse text-apple-12">
            <thead>
              <tr className="border-b border-hairline bg-surface-sunken text-secondary">
                <th className="p-3 font-medium">Ref #</th>
                <th className="p-3 font-medium">Posting Date</th>
                <th className="p-3 font-medium">Account Code</th>
                <th className="p-3 font-medium text-right">Sample Amount (Brass)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-hairline">
              {sampledItems.map((item, idx) => (
                <tr key={idx} className="hover:bg-surface-hover transition-colors font-mono">
                  <td className="p-3 text-secondary">{item.id}</td>
                  <td className="p-3 text-secondary">{item.date}</td>
                  <td className="p-3 text-primary">{item.account}</td>
                  <td className="p-3 text-right text-primary font-serif-numeral font-bold">
                    ${item.amount.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/SamplingTab.tsx', sampling_tab_tsx)

evidence_tab_tsx = """import React, { useState } from 'react';
import { WorkingPaper } from '../../types';
import { useApp } from '../../context/AppContext';
import { computeSha256 } from '../../lib/ledger';
import { Upload, FileCheck, ShieldCheck, Download, Clock } from '../common/Icons';

interface EvidenceTabProps {
  workpaper: WorkingPaper;
}

export const EvidenceTab: React.FC<EvidenceTabProps> = ({ workpaper }) => {
  const { attachEvidenceToWorkpaper, currentUser } = useApp();
  const [evidenceList, setEvidenceList] = useState(workpaper.evidenceItems || []);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || workpaper.sealed) return;

    setIsUploading(true);
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binaryStr = '';
      for (let i = 0; i < bytes.length; i++) {
        binaryStr += String.fromCharCode(bytes[i]);
      }
      const sha256 = await computeSha256(binaryStr);

      await attachEvidenceToWorkpaper(
        workpaper.id,
        {
          name: file.name,
          sizeBytes: file.size,
          sha256,
        },
        currentUser.name
      );

      const newItem = {
        id: `ev-${Date.now()}`,
        name: file.name,
        uploadedAt: new Date().toISOString(),
        uploadedBy: currentUser.name,
        sha256,
        sizeBytes: file.size,
      };

      setEvidenceList((prev) => [newItem, ...prev]);
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <FileCheck className="w-4 h-4 text-verdigris" />
          <span>Cryptographic Evidence Vault &amp; Chain Attestation</span>
        </div>
        <p className="text-apple-12 text-secondary">
          All uploaded evidence documents are fingerprinted with SHA-256 in memory before attachment. Every file drop creates an immutable hash-chained event.
        </p>
      </div>

      {!workpaper.sealed && (
        <div className="p-6 rounded-xl border border-dashed border-hairline bg-surface hover:bg-surface-hover transition-colors text-center cursor-pointer relative">
          <input
            type="file"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
          <div className="flex flex-col items-center gap-2">
            <Upload className="w-6 h-6 text-secondary" />
            <span className="text-apple-13 font-semibold text-primary">
              {isUploading ? 'Computing SHA-256 & Attesting...' : 'Drop evidence file or click to browse'}
            </span>
            <span className="text-apple-11 text-secondary">
              PDF, XLSX, CSV, PNG up to 25MB • Auto-hashed with SHA-256
            </span>
          </div>
        </div>
      )}

      <div className="space-y-3">
        <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
          Attested Workpaper Artifacts ({evidenceList.length})
        </h3>
        <div className="divide-y divide-hairline border border-hairline rounded-xl overflow-hidden bg-surface">
          {evidenceList.map((item) => (
            <div key={item.id} className="p-4 flex items-center justify-between gap-4">
              <div className="min-w-0 space-y-1">
                <div className="flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-verdigris shrink-0" />
                  <span className="text-apple-13 font-medium text-primary truncate">{item.name}</span>
                </div>
                <div className="flex items-center gap-3 text-apple-11 text-secondary">
                  <span>{(item.sizeBytes / 1024).toFixed(1)} KB</span>
                  <span>•</span>
                  <span>Uploaded by {item.uploadedBy}</span>
                  <span>•</span>
                  <span className="font-mono text-tertiary">SHA: {item.sha256.slice(0, 16)}...</span>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-verdigris-subtle text-verdigris border border-verdigris flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Hash-Locked
                </span>
              </div>
            </div>
          ))}
          {evidenceList.length === 0 && (
            <div className="p-6 text-center text-apple-12 text-secondary">
              No evidence artifacts attached yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/EvidenceTab.tsx', evidence_tab_tsx)

analytics_tab_tsx = """import React, { useState, useMemo } from 'react';
import { WorkingPaper, AnalyticsRule } from '../../types';
import {
  runVarianceAnalysis,
  runTrialBalanceCheck,
  runAnomalyDetection,
  runGlToTbReconciliation,
  VarianceInputItem,
  TrialBalanceItem,
} from '../../lib/analytics';
import { Activity, AlertTriangle, CheckCircle2, TrendingUp, Sliders, ShieldCheck } from '../common/Icons';

interface AnalyticsTabProps {
  workpaper: WorkingPaper;
}

export const AnalyticsTab: React.FC<AnalyticsTabProps> = ({ workpaper }) => {
  const [selectedRule, setSelectedRule] = useState<AnalyticsRule>('variance');
  const [thresholdPct, setThresholdPct] = useState(10);
  const [thresholdVal, setThresholdVal] = useState(100000);

  // Synthetic deterministic testing data
  const varianceItems: VarianceInputItem[] = useMemo(
    () => [
      { account: '4010 - Corporate Treasury Revenue', category: 'Revenue', currentPeriod: 14200000, priorPeriod: 12500000, rowRef: 1 },
      { account: '5020 - FX Hedging Derivative Settlements', category: 'Expense', currentPeriod: 8900000, priorPeriod: 6200000, rowRef: 2 },
      { account: '1010 - Central Bank Cash Reserves', category: 'Asset', currentPeriod: 450000000, priorPeriod: 480000000, rowRef: 3 },
      { account: '2010 - Interbank Overnight Repo Borrowing', category: 'Liability', currentPeriod: 125000000, priorPeriod: 98000000, rowRef: 4 },
      { account: '6010 - Clearing & Custody Fees', category: 'Expense', currentPeriod: 1450000, priorPeriod: 1420000, rowRef: 5 },
    ],
    []
  );

  const tbItems: TrialBalanceItem[] = useMemo(
    () => [
      { account: '1000 - Operating Cash', debit: 45200000, credit: 0, rowRef: 10 },
      { account: '1200 - Prime Brokerage Receivables', debit: 18400000, credit: 0, rowRef: 11 },
      { account: '2000 - Repo Repurchase Obligations', debit: 0, credit: 63600000, rowRef: 12 },
    ],
    []
  );

  const anomalyItems = useMemo(
    () => [
      { account: '4010 - Wire Postings', amount: 1540000, rowRef: 20 },
      { account: '4010 - Wire Postings', amount: 1500000, rowRef: 21 },
      { account: '4010 - Wire Postings', amount: 12800000, rowRef: 22 }, // Statistical outlier
      { account: '4010 - Wire Postings', amount: 200000, rowRef: 23 }, // Exact round number anomaly
    ],
    []
  );

  // Deterministic engine runs (LAW 1)
  const results = useMemo(() => {
    switch (selectedRule) {
      case 'variance':
        return runVarianceAnalysis(varianceItems, thresholdPct, thresholdVal);
      case 'tb_check':
        return runTrialBalanceCheck(tbItems).rows;
      case 'anomalies':
        return runAnomalyDetection(anomalyItems);
      case 'gl_to_tb':
        return runGlToTbReconciliation(
          varianceItems.map((v) => ({ account: v.account, amount: v.currentPeriod, rowRef: v.rowRef })),
          varianceItems.map((v) => ({ account: v.account, balance: v.priorPeriod, rowRef: v.rowRef }))
        );
      default:
        return runVarianceAnalysis(varianceItems, thresholdPct, thresholdVal);
    }
  }, [selectedRule, varianceItems, tbItems, anomalyItems, thresholdPct, thresholdVal]);

  const flaggedCount = results.filter((r) => r.flagged).length;

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <Activity className="w-4 h-4 text-verdigris" />
          <span>Deterministic Audit Analytics Engine (⚖ Law 1: Hard-coded Math)</span>
        </div>
        <p className="text-apple-12 text-secondary">
          All financial variance, trial balance checks, and anomaly detection rules are executed locally with deterministic mathematical formulas. Zero AI involvement.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2 border-b border-hairline pb-4">
        {(['variance', 'tb_check', 'anomalies', 'gl_to_tb'] as AnalyticsRule[]).map((rule) => (
          <button
            key={rule}
            type="button"
            onClick={() => setSelectedRule(rule)}
            className={`px-3 py-1.5 rounded-lg text-apple-12 font-medium transition-colors ${
              selectedRule === rule
                ? 'bg-surface border border-hairline text-primary font-semibold shadow-soft'
                : 'text-secondary hover:text-primary hover:bg-surface-hover'
            }`}
          >
            {rule === 'variance' && 'Period Variance'}
            {rule === 'tb_check' && 'Trial Balance Balance Check'}
            {rule === 'anomalies' && 'Z-Score & Round Numbers'}
            {rule === 'gl_to_tb' && 'GL to TB Subledger Tie-out'}
          </button>
        ))}
      </div>

      {selectedRule === 'variance' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3 rounded-lg bg-surface border border-hairline space-y-1">
            <label className="text-apple-11 font-medium text-secondary uppercase">
              Variance % Threshold (Current vs Prior)
            </label>
            <input
              type="number"
              value={thresholdPct}
              onChange={(e) => setThresholdPct(Number(e.target.value))}
              className="w-full p-2 text-apple-12 rounded bg-surface-sunken border border-hairline text-primary"
            />
          </div>
          <div className="p-3 rounded-lg bg-surface border border-hairline space-y-1">
            <label className="text-apple-11 font-medium text-secondary uppercase">
              Absolute Dollar Threshold ($)
            </label>
            <input
              type="number"
              value={thresholdVal}
              onChange={(e) => setThresholdVal(Number(e.target.value))}
              className="w-full p-2 text-apple-12 rounded bg-surface-sunken border border-hairline text-primary"
            />
          </div>
        </div>
      )}

      {/* Analysis Results Table */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
            Analysis Output ({results.length} records • {flaggedCount} flagged)
          </h3>
          <span className="text-apple-11 text-verdigris font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Deterministic Verification
          </span>
        </div>
        <div className="border border-hairline rounded-xl overflow-hidden bg-surface">
          <table className="w-full text-left border-collapse text-apple-12">
            <thead>
              <tr className="border-b border-hairline bg-surface-sunken text-secondary">
                <th className="p-3 font-medium">Account Description</th>
                <th className="p-3 font-medium text-right">Current Period</th>
                <th className="p-3 font-medium text-right">Prior / Benchmark</th>
                <th className="p-3 font-medium text-right">Variance ($)</th>
                <th className="p-3 font-medium">Flag / Finding</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-hairline">
              {results.map((row) => (
                <tr
                  key={row.rowIndex}
                  className={`hover:bg-surface-hover transition-colors font-mono ${
                    row.flagged ? 'bg-cinnabar-subtle/20' : ''
                  }`}
                >
                  <td className="p-3 font-sans font-medium text-primary">{row.account}</td>
                  <td className="p-3 text-right text-primary font-bold">
                    ${Math.round(row.currentPeriod).toLocaleString()}
                  </td>
                  <td className="p-3 text-right text-secondary">
                    ${Math.round(row.priorPeriod).toLocaleString()}
                  </td>
                  <td
                    className={`p-3 text-right font-bold ${
                      row.varianceVal < 0 ? 'text-cinnabar' : 'text-primary'
                    }`}
                  >
                    {row.varianceVal >= 0 ? '+' : ''}${Math.round(row.varianceVal).toLocaleString()} ({row.variancePct.toFixed(1)}%)
                  </td>
                  <td className="p-3 font-sans">
                    {row.flagged ? (
                      <span className="inline-flex items-center gap-1 text-cinnabar text-apple-11 font-semibold">
                        <AlertTriangle className="w-3.5 h-3.5" /> {row.flagReason}
                      </span>
                    ) : (
                      <span className="text-verdigris text-apple-11 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Passed
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/AnalyticsTab.tsx', analytics_tab_tsx)

doc_review_tsx = """import React, { useState, useMemo } from 'react';
import { WorkingPaper } from '../../types';
import { runDocumentReview, DocumentReviewCheckResult } from '../../lib/analytics';
import { FileText, CheckCircle2, AlertTriangle, ShieldCheck } from '../common/Icons';

interface DocumentReviewTabProps {
  workpaper: WorkingPaper;
}

export const DocumentReviewTab: React.FC<DocumentReviewTabProps> = ({ workpaper }) => {
  const [docText, setDocText] = useState(
    `Section 1. Executive Policy Framework
Global Liquidity Risk Management Policy mandates that all intraday settlements exceeding $10,000,000 USD be posted to the general ledger within 60 minutes of Fedwire notification.

Section 2. Control Execution
[TODO: Insert final operational walkthrough narrative from APAC regional branch]

Approved by: Marcus Vance, Head of Assurance
Date: September 15, 2026`
  );

  const reviewResults = useMemo(() => {
    return runDocumentReview(docText);
  }, [docText]);

  return (
    <div className="space-y-6">
      <div className="p-4 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <FileText className="w-4 h-4 text-verdigris" />
          <span>Deterministic Document Review Engine (⚖ Law 1 &amp; Law 2)</span>
        </div>
        <p className="text-apple-12 text-secondary">
          Extracts and inspects policy text for incomplete placeholders, missing attestation signatures, invalid date ranges, and empty section bodies using deterministic AST token rules. No cloud LLM.
        </p>
      </div>

      <div className="space-y-2">
        <label className="text-apple-11 font-medium text-secondary uppercase tracking-wider">
          Policy / Governance Workpaper Text
        </label>
        <textarea
          rows={6}
          value={docText}
          onChange={(e) => setDocText(e.target.value)}
          disabled={workpaper.sealed}
          className="w-full p-3 font-mono text-apple-12 rounded-xl bg-surface border border-hairline text-primary focus:outline-none focus:ring-1 focus:ring-accent"
        />
      </div>

      <div className="space-y-3">
        <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
          Automated Governance Checks ({reviewResults.filter((r) => r.passed).length} / {reviewResults.length} Passed)
        </h3>
        <div className="divide-y divide-hairline border border-hairline rounded-xl overflow-hidden bg-surface">
          {reviewResults.map((check, idx) => (
            <div key={idx} className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-apple-13 font-semibold text-primary">{check.rule}</span>
                {check.passed ? (
                  <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-verdigris-subtle text-verdigris border border-verdigris flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Passed
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-cinnabar-subtle text-cinnabar border border-cinnabar flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Exception
                  </span>
                )}
              </div>
              <p className="text-apple-12 text-secondary">{check.message}</p>
              {check.findings.length > 0 && (
                <div className="p-3 rounded-lg bg-surface-sunken space-y-1 font-mono text-apple-11 text-cinnabar">
                  {check.findings.map((f, i) => (
                    <div key={i}>• {f}</div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/DocumentReviewTab.tsx', doc_review_tsx)

findings_tab_tsx = """import React from 'react';
import { WorkingPaper } from '../../types';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { AlertCircle, AlertTriangle, Plus, ArrowRight, GitCommit } from '../common/Icons';

interface FindingsTabProps {
  workpaper: WorkingPaper;
}

export const FindingsTab: React.FC<FindingsTabProps> = ({ workpaper }) => {
  const { openInspector } = useApp();
  const { scopedObservations } = useScopedData();

  const paperObservations = scopedObservations.filter((o) => o.workpaperId === workpaper.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-apple-15 font-semibold text-primary">
            Documented Audit Observations ({paperObservations.length})
          </h3>
          <p className="text-apple-12 text-secondary">
            Exceptions raised during substantive testing with 5C standard (Condition, Criteria, Cause, Consequence, Recommendation).
          </p>
        </div>
        {!workpaper.sealed && (
          <button
            type="button"
            onClick={() =>
              openInspector('observation', {
                workpaperId: workpaper.id,
                controlId: workpaper.controlId,
                entityId: workpaper.entityId,
                universeId: workpaper.universeId,
              })
            }
            className="px-3 py-1.5 rounded-lg bg-surface border border-hairline hover:bg-surface-hover text-apple-12 font-semibold text-primary transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Raise Finding</span>
          </button>
        )}
      </div>

      <div className="space-y-4">
        {paperObservations.map((obs) => (
          <div
            key={obs.id}
            className="p-5 rounded-xl bg-surface border border-hairline shadow-soft space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2 py-0.5 rounded text-apple-11 font-semibold ${
                    obs.severity === 'critical'
                      ? 'bg-cinnabar text-white'
                      : obs.severity === 'high'
                      ? 'bg-cinnabar-subtle text-cinnabar border border-cinnabar'
                      : 'bg-amber-subtle text-amber border border-amber'
                  }`}
                >
                  {obs.severity.toUpperCase()}
                </span>
                <span className="font-mono text-apple-12 text-secondary">{obs.id}</span>
              </div>
              <button
                type="button"
                onClick={() => openInspector('red_thread', { observation: obs })}
                className="text-apple-12 text-secondary hover:text-primary flex items-center gap-1"
              >
                <GitCommit className="w-3.5 h-3.5 text-accent" />
                <span>Lineage Trace</span>
              </button>
            </div>

            <h4 className="text-apple-14 font-semibold text-primary">{obs.title}</h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-apple-12">
              <div className="p-3 rounded-lg bg-surface-sunken space-y-1">
                <span className="font-semibold text-secondary uppercase text-apple-11">Condition</span>
                <p className="text-primary">{obs.condition}</p>
              </div>
              <div className="p-3 rounded-lg bg-surface-sunken space-y-1">
                <span className="font-semibold text-secondary uppercase text-apple-11">Criteria</span>
                <p className="text-primary">{obs.criteria}</p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-apple-11 text-secondary border-t border-hairline">
              <span>Raised by {obs.raisedBy}</span>
              <button
                type="button"
                onClick={() => openInspector('observation', { observation: obs })}
                className="text-primary font-medium hover:underline flex items-center gap-1"
              >
                <span>Edit Full 5C Analysis</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}

        {paperObservations.length === 0 && (
          <div className="p-8 text-center rounded-xl border border-dashed border-hairline text-secondary text-apple-12">
            No audit exceptions or observations recorded for this working paper.
          </div>
        )}
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/FindingsTab.tsx', findings_tab_tsx)

paper_workbench_tsx = """import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { WorkbenchHeader } from './WorkbenchHeader';
import { TestingStepsTab } from './TestingStepsTab';
import { SamplingTab } from './SamplingTab';
import { EvidenceTab } from './EvidenceTab';
import { AnalyticsTab } from './AnalyticsTab';
import { DocumentReviewTab } from './DocumentReviewTab';
import { FindingsTab } from './FindingsTab';
import { ClipboardList, Sliders, FileCheck, Activity, FileText, AlertTriangle } from '../common/Icons';

type WorkbenchSubTab = 'testing' | 'sampling' | 'evidence' | 'analytics' | 'document_review' | 'findings';

export const PaperWorkbenchModal: React.FC = () => {
  const { inspector, closeInspector } = useApp();
  const { scopedWorkpapers, scopedEngagements } = useScopedData();
  const [activeSubTab, setActiveSubTab] = useState<WorkbenchSubTab>('testing');

  const workpaperId = inspector.data?.workpaperId || inspector.data?.workpaper?.id;
  const workpaper = scopedWorkpapers.find((w) => w.id === workpaperId) || scopedWorkpapers[0];
  const engagement = workpaper ? scopedEngagements.find((e) => e.id === workpaper.engagementId) : undefined;

  if (!workpaper) {
    return (
      <div className="p-6 text-center text-secondary">
        Working paper not found or not accessible within active scope.
      </div>
    );
  }

  const tabs: { id: WorkbenchSubTab; label: string; icon: React.FC<any> }[] = [
    { id: 'testing', label: 'Test Program', icon: ClipboardList },
    { id: 'sampling', label: 'Sample Selection', icon: Sliders },
    { id: 'evidence', label: 'Evidence Vault', icon: FileCheck },
    { id: 'analytics', label: 'Deterministic Analytics', icon: Activity },
    { id: 'document_review', label: 'Policy Review', icon: FileText },
    { id: 'findings', label: 'Exceptions & Findings', icon: AlertTriangle },
  ];

  return (
    <div className="flex flex-col h-full bg-canvas -m-6">
      <WorkbenchHeader workpaper={workpaper} engagement={engagement} />

      {/* Sub-tab Navigation */}
      <div className="flex items-center gap-1 px-6 border-b border-hairline bg-surface overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2 py-3 px-3 text-apple-12 font-medium border-b-2 transition-colors whitespace-nowrap ${
                isActive
                  ? 'border-accent text-primary font-semibold'
                  : 'border-transparent text-secondary hover:text-primary'
              }`}
            >
              <Icon className="w-3.5 h-3.5 stroke-[1.3]" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-6 bg-canvas">
        {activeSubTab === 'testing' && <TestingStepsTab workpaper={workpaper} />}
        {activeSubTab === 'sampling' && <SamplingTab workpaper={workpaper} />}
        {activeSubTab === 'evidence' && <EvidenceTab workpaper={workpaper} />}
        {activeSubTab === 'analytics' && <AnalyticsTab workpaper={workpaper} />}
        {activeSubTab === 'document_review' && <DocumentReviewTab workpaper={workpaper} />}
        {activeSubTab === 'findings' && <FindingsTab workpaper={workpaper} />}
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/PaperWorkbenchModal.tsx', paper_workbench_tsx)

audit_file_tsx = """import React from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { ShieldCheck, Clock, FileText, ArrowRight, CheckCircle2, Lock } from '../common/Icons';

export const AuditFileModal: React.FC = () => {
  const { inspector, openInspector, closeInspector, signOffEngagement } = useApp();
  const { scopedEngagements, scopedWorkpapers, scopedControls } = useScopedData();

  const engagement = inspector.data?.engagement || scopedEngagements[0];
  const workpapers = engagement
    ? scopedWorkpapers.filter((w) => w.engagementId === engagement.id)
    : [];
  const controls = engagement
    ? scopedControls.filter((c) => c.engagementId === engagement.id)
    : [];

  if (!engagement) {
    return <div className="p-6 text-center text-secondary">Engagement record not found.</div>;
  }

  const allSealed = workpapers.length > 0 && workpapers.every((w) => w.sealed);

  return (
    <div className="space-y-6">
      <div className="p-5 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-mono text-apple-11 px-2 py-0.5 rounded bg-surface border border-hairline text-secondary">
              {engagement.id}
            </span>
            <span className="text-apple-11 font-semibold text-secondary uppercase">
              {engagement.stage} Stage
            </span>
          </div>
          {engagement.status === 'signed_off' && (
            <span className="px-2 py-0.5 rounded-full text-apple-11 font-semibold bg-verdigris-subtle text-verdigris border border-verdigris flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" /> Formally Signed-Off
            </span>
          )}
        </div>
        <h2 className="text-apple-17 font-bold text-primary">{engagement.title}</h2>
        <div className="flex items-center gap-4 text-apple-11 text-secondary">
          <span>Due: {engagement.dueDate}</span>
          <span>•</span>
          <span>{workpapers.length} Working Papers</span>
          <span>•</span>
          <span>{controls.length} Controls Evaluated</span>
        </div>
      </div>

      {/* Working Papers Roster */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
            Assigned Working Papers
          </h3>
          <span className="text-apple-11 text-secondary">
            {workpapers.filter((w) => w.sealed).length} of {workpapers.length} Sealed
          </span>
        </div>
        <div className="divide-y divide-hairline border border-hairline rounded-xl overflow-hidden bg-surface">
          {workpapers.map((wp) => (
            <div
              key={wp.id}
              onClick={() => openInspector('workbench', { workpaperId: wp.id })}
              className="p-4 flex items-center justify-between hover:bg-surface-hover transition-colors cursor-pointer"
            >
              <div className="min-w-0 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-apple-11 font-bold text-secondary">{wp.refCode}</span>
                  <span className="text-apple-13 font-medium text-primary truncate">{wp.title}</span>
                  {wp.sealed && (
                    <span className="px-2 py-0.5 rounded text-apple-11 font-semibold bg-verdigris-subtle text-verdigris border border-verdigris flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Sealed
                    </span>
                  )}
                </div>
                <div className="text-apple-11 text-secondary truncate">
                  Objective: {wp.objective}
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-2 pl-3">
                <span className="text-apple-11 text-secondary">Open Paper</span>
                <ArrowRight className="w-3.5 h-3.5 text-secondary" />
              </div>
            </div>
          ))}
          {workpapers.length === 0 && (
            <div className="p-6 text-center text-apple-12 text-secondary">
              No working papers assigned to this engagement yet.
            </div>
          )}
        </div>
      </div>

      {/* Engagement Final Sign-off Gate */}
      <div className="pt-4 border-t border-hairline flex items-center justify-between">
        <div className="text-apple-11 text-secondary">
          {allSealed
            ? 'All papers sealed. Ready for engagement attestation.'
            : 'All working papers must be cryptographically sealed before signing off.'}
        </div>
        {engagement.status !== 'signed_off' && (
          <button
            type="button"
            onClick={() => signOffEngagement(engagement.id)}
            disabled={!allSealed}
            className="px-4 py-2 rounded-lg bg-surface border border-hairline hover:bg-surface-hover text-apple-13 font-semibold text-primary disabled:opacity-50 transition-colors flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4 text-verdigris" />
            <span>Sign-Off Engagement File</span>
          </button>
        )}
      </div>
    </div>
  );
};
"""
write_both('src/components/audit/AuditFileModal.tsx', audit_file_tsx)

executive_pack_tsx = """import React from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { FileBarChart, ShieldCheck, Download, CheckCircle2 } from '../common/Icons';

export const ExecutivePackModal: React.FC = () => {
  const { closeInspector } = useApp();
  const { stats, scopedEngagements, scopedIssues } = useScopedData();

  const handleDownload = () => {
    alert('Executive Assurance Committee Deck export generated with cryptographic hash attestation.');
  };

  return (
    <div className="space-y-6">
      <div className="p-5 rounded-xl bg-surface-sunken border border-hairline space-y-2">
        <div className="flex items-center gap-2 text-primary font-medium text-apple-13">
          <FileBarChart className="w-4 h-4 text-verdigris" />
          <span>Executive Audit Committee Pack (Board Ready)</span>
        </div>
        <p className="text-apple-12 text-secondary">
          High-level executive assurance briefing containing cryptographic seal tallies, open high-severity findings, and CAP aging metrics.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-surface border border-hairline space-y-1">
          <span className="text-apple-11 text-secondary uppercase tracking-wider">Total Engagements</span>
          <div className="font-serif-numeral text-apple-28 font-bold text-primary">
            {scopedEngagements.length}
          </div>
        </div>
        <div className="p-4 rounded-xl bg-surface border border-hairline space-y-1">
          <span className="text-apple-11 text-secondary uppercase tracking-wider">Critical Issues</span>
          <div className="font-serif-numeral text-apple-28 font-bold text-cinnabar">
            {stats.criticalIssues}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-apple-13 font-semibold text-primary uppercase tracking-wider">
          Audit Committee Summary Points
        </h3>
        <ul className="space-y-2 text-apple-12 text-secondary">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-verdigris shrink-0 mt-0.5" />
            <span>100% of tested working papers attested on cryptographic hash-chain.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-verdigris shrink-0 mt-0.5" />
            <span>All statistical sampling conducted via deterministic Mulberry32 PRNG.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-verdigris shrink-0 mt-0.5" />
            <span>Multi-tenant scopes strictly enforced per Basel / IIA Standards.</span>
          </li>
        </ul>
      </div>

      <div className="pt-4 border-t border-hairline flex items-center justify-between">
        <button
          type="button"
          onClick={closeInspector}
          className="px-4 py-2 rounded-lg bg-surface border border-hairline text-apple-13 font-medium text-primary hover:bg-surface-hover"
        >
          Close
        </button>
        <button
          type="button"
          onClick={handleDownload}
          className="px-4 py-2 rounded-lg bg-verdigris text-white text-apple-13 font-semibold hover:opacity-90 flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          <span>Export Sealed Deck (.PDF)</span>
        </button>
      </div>
    </div>
  );
};
"""
write_both('src/components/reports/ExecutivePackModal.tsx', executive_pack_tsx)

reports_tab_tsx = """import React from 'react';
import { useApp } from '../../context/AppContext';
import { useScopedData } from '../../hooks/useScopedData';
import { FileBarChart, Download, FileText, ShieldCheck, ArrowRight } from '../common/Icons';

export const ReportsTab: React.FC = () => {
  const { openInspector } = useApp();
  const { stats, scopedEngagements } = useScopedData();

  const reportsList = [
    {
      id: 'rep-exec',
      title: 'Quarterly Audit Committee Assurance Pack',
      description: 'Comprehensive risk overview, open findings count, and CAP remediation status for the board.',
      format: 'PDF Deck',
      action: () => openInspector('account_settings'),
    },
    {
      id: 'rep-ledger',
      title: 'Cryptographic Ledger Verification Attestation',
      description: 'Full sequential hash audit trail from genesis to latest seal, signed by 4-eyes keys.',
      format: 'Cryptographic Attestation',
      action: () => alert('Ledger attestation report downloaded.'),
    },
    {
      id: 'rep-sira',
      title: 'Comprehensive SIRA Risk Heatmap & Universe Index',
      description: 'Breakdown of inherent vs residual risk scores across all business units and entities.',
      format: 'Spreadsheet',
      action: () => alert('SIRA spreadsheet generated.'),
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
      <div className="space-y-1">
        <h1 className="text-apple-28 font-serif-title font-bold text-primary">
          Audit Reports &amp; Assurance Packs
        </h1>
        <p className="text-apple-13 text-secondary">
          Export verifiable board packages and cryptographically attested ledger logs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reportsList.map((rep) => (
          <div
            key={rep.id}
            onClick={rep.action}
            className="p-6 rounded-2xl bg-surface border border-hairline shadow-apple hover:bg-surface-hover transition-colors cursor-pointer flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-surface-sunken border border-hairline flex items-center justify-center text-primary">
                <FileBarChart className="w-5 h-5 text-verdigris" />
              </div>
              <h3 className="text-apple-15 font-semibold text-primary">{rep.title}</h3>
              <p className="text-apple-12 text-secondary leading-relaxed">{rep.description}</p>
            </div>
            <div className="pt-4 border-t border-hairline flex items-center justify-between text-apple-12 font-medium text-primary">
              <span className="text-secondary">{rep.format}</span>
              <span className="flex items-center gap-1 text-verdigris font-semibold">
                Generate <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
"""
write_both('src/components/reports/ReportsTab.tsx', reports_tab_tsx)
